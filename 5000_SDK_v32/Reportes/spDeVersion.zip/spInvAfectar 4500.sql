SET DATEFIRST 7
SET ANSI_NULLS OFF
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET LOCK_TIMEOUT -1
SET QUOTED_IDENTIFIER OFF
SET ARITHABORT OFF
SET ANSI_WARNINGS OFF
GO

/**************************************************************************/
/**************************************************************************/
/***************                                            ***************/
/***************               Intelisis 4500               ***************/
/*************** Buscar el comentario CFD 3.3 para integrar ***************/
/***************                                            ***************/
/**************************************************************************/
/**************************************************************************/

/**************** spInvAfectar ****************/
if exists (select * from sysobjects where id = object_id('dbo.spInvAfectar') and type = 'P') drop procedure dbo.spInvAfectar
GO             
CREATE PROCEDURE spInvAfectar
    		   @ID                		int,
		   @Accion			char(20),
		   @Base			char(20),

    		   @Empresa	      		char(5),
    		   @Modulo	      		char(5),
    		   @Mov	  	      		char(20),
    		   @MovID             		varchar(20)	OUTPUT,
    		   @MovTipo     		char(20),
    		   @MovMoneda	      		char(10),
    		   @MovTipoCambio	 	float,
		   @FechaEmision		datetime,
    		   @FechaAfectacion    		datetime,
    		   @FechaConclusion	 	datetime,

    		   @Concepto	      		varchar(50),
    	 	   @Proyecto	      		varchar(50),
    		   @Usuario	      		char(10),
    		   @Autorizacion      		char(10),
    		   @Referencia	      		varchar(50),
    		   @DocFuente	      		int,
    		   @Observaciones     		varchar(255),
    		   @Estatus           		char(15),
		   @EstatusNuevo		char(15),
    		   @FechaRegistro     		datetime,
    		   @Ejercicio	      		int,
    		   @Periodo	      		int,

    		   @Almacen        		char(10),
                   @AlmacenTipo			char(15),
    		   @AlmacenDestino    		char(10),
                   @AlmacenDestinoTipo		char(15),
		   @VoltearAlmacen		bit, 
		   @AlmacenEspecifico		char(10), 
                   @Largo			bit,
		   @Condicion			varchar(50), 
		   @Vencimiento			datetime,
		   @Periodicidad		varchar(20), 
		   @EndosarA			varchar(10),

		   @ClienteProv			char(10),
		   @EnviarA			int,
		   @DescuentoGlobal		float,
		   @SobrePrecio			float,
		   @Agente			char(10),
		   @AnticiposFacturados		money,
    		   @ServicioArticulo		char(20),
    		   @ServicioSerie		char(20),
		   @FechaRequerida		datetime,
		   @ZonaImpuesto		varchar(50),

		   @OrigenTipo			varchar(10),
		   @Origen			varchar(20),
                   @OrigenID			varchar(20),
                   @OrigenMovTipo		varchar(20),

		   --@CfgAutoConsig		bit,
    		   @CfgFormaCosteo    		char(20),
    		   @CfgTipoCosteo     		char(20),
                   @CfgCosteoActividades	varchar(20),
		   @CfgCosteoNivelSubCuenta	bit,
                   @CfgCosteoMultipleSimultaneo bit,
                   @CfgPosiciones		bit,
		   @CfgExistenciaAlterna	bit,
		   @CfgExistenciaAlternaSerieLote bit,
                   @CfgSeriesLotesMayoreo	bit,
    		   @CfgSeriesLotesAutoCampo	char(20),
    		   @CfgSeriesLotesAutoOrden	char(20),
                   @CfgCosteoSeries		bit,
                   @CfgCosteoLotes		bit,
		   @CfgValidarLotesCostoDif	bit,
		   @CfgVentaSurtirDemas		bit,
		   @CfgCompraRecibirDemas	bit,
		   @CfgTransferirDemas		bit,
		   @CfgBackOrders		bit,
		   @CfgContX			bit,
		   @CfgContXGenerar		char(20),
                   @CfgContXFacturasPendientes  bit,
		   @CfgEmbarcar			bit,
	           @CfgImpInc			bit,
    		   @CfgVentaContratosArticulo	char(20),
    		   @CfgVentaContratosImpuesto	float,
		   @CfgVentaComisionesCobradas	bit,
		   @CfgAnticiposFacturados	bit,
		   @CfgMultiUnidades		bit,
		   @CfgMultiUnidadesNivel	char(20),
    	      	   @CfgCompraFactorDinamico 	bit,
		   @CfgInvFactorDinamico   	bit,
		   @CfgProdFactorDinamico  	bit,
		   @CfgVentaFactorDinamico 	bit,
                   @CfgCompraAutoCargos		bit,
                   @CfgVentaAutoBonif		bit,
		   @CfgVINAccesorioArt 		bit,
                   @CfgVINCostoSumaAccesorios	bit,
		   @SeguimientoMatriz		bit,
		   @CobroIntegrado		bit,
		   @CobroIntegradoCxc		bit,
                   @CobroIntegradoParcial       bit,
		   @CobrarPedido		bit,

  		   @AfectarDetalle              bit,
		   @AfectarMatando		bit,
		   @AfectarVtasMostrador	bit,
		   @FacturarVtasMostrador	bit,
		   @AfectarConsignacion		bit,
		   @AfectarAlmacenRenglon	bit,
                   @CfgVentaMultiAgente		bit,
                   @CfgVentaMultiAlmacen	bit,
                   @CfgVentaArtAlmacenEspecifico bit, 
		   @CfgTipoMerma		char(1),
                   @CfgComisionBase		char(20), 
		   @CfgLimiteRenFacturas	int,	
		   @CfgVentaRedondeoDecimales	int,
                   @CfgCompraCostosImpuestoIncluido bit,

		   @AfectarConsecutivo		bit,
		   @EsTransferencia		bit,

		   @Conexion			bit,
		   @SincroFinal			bit,
		   @Sucursal			int,
		   @SucursalDestino		int,
		   @SucursalOrigen		int,

		   @Utilizar			bit,
		   @UtilizarID			int,
		   @UtilizarMov			char(20),
		   @UtilizarSerie		char(20),
		   @UtilizarMovTipo		char(20),
		   @UtilizarMovID		varchar(20),

                   @Generar                     bit,
                   @GenerarMov                  char(20),
		   @GenerarSerie		char(20),
		   @GenerarAfectado		bit,
		   @GenerarCopia		bit,
		   @GenerarPoliza		bit,
		   @GenerarOP			bit,
		   @GenerarGasto		bit,
		   @FacturacionRapidaAgrupada	bit, 

		   @IDTransito			int	     OUTPUT,
    		   @IDGenerar		 	int	     OUTPUT,
    		   @GenerarMovID	  	varchar(20)  OUTPUT,
		   @ContID			int	     OUTPUT,

    		   @Ok                		int          OUTPUT,
    		   @OkRef             		varchar(255) OUTPUT,
		   @CfgPrecioMoneda		bit = 0
--//WITH ENCRYPTION
AS BEGIN
  DECLARE
    @Dias			int,
    @Renglon             	float,
    @RenglonSub		 	int,
    @RenglonID			int,
    @RenglonTipo		char(1),
    @Articulo	         	char(20),
    @Posicion			char(10),
    @AuxiliarAlternoSucursal	int,
    @AuxiliarAlternoAlmacen	char(10),
    @AuxiliarAlternoFactorEntrada float,
    @AuxiliarAlternoFactorSalida  float,
    @ArtTipo	         	varchar(20),
    @ArtSerieLoteInfo		bit,
    @ArtTipoOpcion		varchar(20),
    @ArtComision		varchar(50),
    @Peso			float,
    @Volumen			float,
    @Subcuenta	         	varchar(50),
    @AcumularSinDetalles	bit,
    @AcumCantidad		float,
    @Cantidad	         	float,
    @Factor			float,
    @MovUnidad			varchar(50),
    @CantidadOriginal		float,
    @CantidadObsequio		float,
    @CantidadInventario		float,
    @CantidadReservada	 	float,
    @CantidadOrdenada		float,
    @CantidadOrdenadaA		float,
    @CantidadPendiente   	float,
    @CantidadPendienteA		float,
    @CantidadA	       	 	float,
    @IDSalidaTraspaso		int,
    @IDAplica			int,
    @AplicaMov              	char(20),
    @AplicaMovID            	varchar(20),
    @AplicaMovTipo		char(20),
    @AlmacenRenglon		char(10),
    @AgenteRenglon		char(10),
    @AlmacenOrigen		char(10),
    @Costo	         	float,		-- a proposito float en lugar de money
    @CostoInv			float,		-- a proposito float en lugar de money
    @CostoInvTotal          	float,
    @Precio	         	float,
    @PrecioN	         	float,
    @PrecioTipoCambio		float,
    @DescuentoTipo	 	char(1),
    @DescuentoLinea	 	float,
    @Impuesto1		 	float,
    @Impuesto1N		 	float,
    @Impuesto2		 	float,
    @Impuesto2N		 	float,
    @Impuesto3		 	money,
    @Impuesto3N		 	money,
    @Impuesto5		 	money,
    @Impuesto5N		 	money,
    @Importe             	money,
    @ImporteNeto             	money,
    @Impuestos		 	money,
    @ImpuestosNetos		money,
    @Impuesto1Neto 		money,
    @Impuesto2Neto 		money,
    @Impuesto3Neto 		money,
    @Impuesto5Neto 		money,
    @ImporteComision		money,
    @DescuentoLineaImporte	money,
    @DescuentoGlobalImporte	money,
    @SobrePrecioImporte		money,
    @AnticipoImporte		money,
    @AnticipoImpuestos		money,
    @ImporteCx			money,
    @ImpuestosCx		money,
    @RetencionCx		money,
    @Retencion2Cx		money,
    @Retencion3Cx		money,
    @ImporteTotalCx		money,
    @CondicionCx		varchar(50),
    @VencimientoCx		datetime,
    @FacturandoRemision         bit,

    @TienePendientes		bit,
    @SumaPendiente       	float,
    @SumaReservada		float,
    @SumaOrdenada		float,
    @SumaImporte		money,
    @SumaImporteNeto	 	money,
    @SumaImpuestos	 	money,
    @SumaImpuestosNetos	 	money,
    @SumaImpuesto1Neto 	 	money,
    @SumaImpuesto2Neto 	 	money,
    @SumaImpuesto3Neto 	 	money,
    @SumaImpuesto5Neto 	 	money,
    @SumaDescuentoLinea		money,
    @SumaPrecioLinea		money,
    @SumaCostoLinea		money,
    @SumaPeso			float,
    @SumaVolumen		float,
    @SumaComision		money,
    @SumaRetencion		money,
    @SumaRetencion2		money,
    @SumaRetencion3		money,
    @SumaRetenciones		money,
    @SumaAnticiposFacturados	money, 
    @ImporteRetencion		money,
    @ImporteRetencion2		money,
    @ImporteRetencion3		money,
    @Paquetes			int,
    @ImporteTotal		float,
    @MovImpuesoSubTotal		money,
    @ImporteMatar		money,
    @FechaCancelacion		datetime,
    @ArtUnidad			varchar(50),
    @ArtCantidad		float,
    @ArtCosto	         	float,		-- a proposito float en lugar de money
    @ArtCostoInv		float,		-- a proposito float en lugar de money
    @ArtAjusteCosteo		float,
    @ArtCostoUEPS		float,    
    @ArtCostoPEPS		float,
    @ArtUltimoCosto		float,
    @ArtCostoEstandar		float,
    @ArtPrecioLista		float,
    @ArtDepartamentoDetallista	int,
    @ArtMoneda			char(10),
    @ArtFactor	 	 	float,
    @ArtTipoCambio		float,
    @ArtCostoIdentificado	bit,
    @AjustePrecioLista		money,
    @MovRetencion1		float,
    @MovRetencion2		float,
    @MovRetencion3		float,
    @ReservadoParcial		float,
    @ExplotandoRenglon		float,
    @ExplotandoSubCuenta	bit,
    @EsEntrada           	bit,
    @EsSalida		 	bit,
    @EsCargo			bit,
    @AfectarCantidad		float,
    @AfectarAlmacen		char(10),
    @AfectarAlmacenDestino	char(10),
    @AfectarSerieLote		bit,
    @AfectarCostos       	bit,
    @AfectarUnidades     	bit,
    @AfectarPiezas       	bit,
    @AfectarRama		char(5),
    @UtilizarBase		char(20),
    @UtilizarEstatus		char(15),
    @GenerarAlmacen		char(10),
    @GenerarAlmacenDestino	char(10),
    @GenerarEstatus		char(15),
    @GenerarDirecto		bit,
    @GenerarMovTipo 	 	char(20), 
    @GenerarPeriodo 	 	int, 
    @GenerarEjercicio 	 	int,
    @GenerarPolizaTemp		bit,
    @YaGeneroConsecutivo	bit,
    @CxModulo			char(5),
    @CxID			int, 
    @CxMov			char(20),
    @CxMovID			varchar(20),
    @CxMovEspecifico		varchar(20),
    @CxAgente			char(10),
    @CxMovTipo			varchar(20),
    @CxImporte			money,
    @CxAjusteID			int, 
    @CxAjusteMov		char(20),
    @CxAjusteMovID		varchar(20),
    @CxAjusteImporte		money,
    @CxConcepto			varchar(50),
    @CompraID			int,
    @Cliente			char(10),
    @DetalleTipo		varchar(20),
    @Merma			float,
    @Desperdicio		float,
    @CantidadCalcularImporte	float,

    @DestinoTipo	  	varchar(10),
    @Destino			varchar(20),
    @DestinoID			varchar(20),

    @CobroDesglosado		money,
    @CobroCambio		money,
    @CobroRedondeo		money,
    @CobroSumaEfectivo		money,
    @CobroDelEfectivo		money,
    @ValesCobrados		money,
    @TarjetasCobradas		money,		-- ETO Tarjetas 9-Feb-2007
    @DineroImporte		money,
    @DineroModulo		char(5),
    @DineroMov			char(20),
    @DineroMovID		varchar(20),
    @MovImpuesto		bit,

    @Importe1			money,
    @Importe2			money,
    @Importe3			money,
    @Importe4			money,
    @Importe5			money,
    @ImporteCambio		money,
    @FormaCobro1		varchar(50),
    @FormaCobro2		varchar(50),
    @FormaCobro3		varchar(50),
    @FormaCobro4		varchar(50),
    @FormaCobro5		varchar(50),
    @FormaCobroVales		varchar(50),
    @FormaCobroCambio	varchar(50), --MEJORA5512
    @FormaCobroTarjetas		varchar(50), 	-- ETO Tarjetas 9-Feb-2007
    @IncrementaSaldoTarjeta	bit,	     	-- ETO Tarjetas 9-Feb-2007
    @FormaPagoCambio		varchar(50),
    @Referencia1		varchar(50),
    @Referencia2		varchar(50),
    @Referencia3		varchar(50),
    @Referencia4		varchar(50),
    @Referencia5		varchar(50),
    @CtaDinero			char(10),
    @Cajero			char(10),

    @FormaMoneda		char(10),
    @FormaTipoCambio		float,
    @AlmacenEspecificoVenta	char(10),

    @MatarAntes			bit,
    @UltRenglonIDJuego		int,
    @CantidadJuego		float,
    @CantidadMinimaJuego	int,
    @AlmacenTemp		char(10),
    @AlmacenOriginal		char(10),
    @AlmacenDestinoOriginal	char(10),
    @ProdSerieLote		varchar(50),
    @VIN			varchar(20),
    @UltReservadoCantidad	float,
    @UltReservadoFecha		datetime,
    @UltAgente			char(10),
    @ComisionAcum		money,
    @ComisionImporteNeto	float,
    @ComisionFactor		float,
    @Producto			varchar(20),
    @SubProducto		varchar(50),
    @IVAFiscal			float,
    @IEPSFiscal			float,
    @AfectandoNotasSinCobro	bit,
    @Continuar			bit,
    @ArtProvCosto		float,
    @ProveedorRef 		varchar(10), 

    @CfgRetencionAlPago		bit,
    @CfgRetencionMov		char(20),
    @CfgRetencionAcreedor	char(10),
    @CfgRetencionConcepto	varchar(50),
    @CfgRetencion2Acreedor	char(10),
    @CfgRetencion2Concepto	varchar(50),
    @CfgRetencion3Acreedor	char(10),
    @CfgRetencion3Concepto	varchar(50),
    @CfgIngresoMov		char(20),
    @CfgEstadisticaAjusteMerma	char(20),
    @CfgInvAjusteCargoAgente	varchar(20),
    @CfgVentaDMultiAgenteSugerir bit,
    @CfgVentaMonedero		bit,
    @CfgVentaPuntosEnVales	bit,
    @EspacioD			varchar(10),
    @EspacioDAnterior		varchar(10),
    @Ruta			char(20), 
    @Orden			int,
    @OrdenDestino		int,
    @Centro			char(10),
    @CentroDestino		char(10),
    @Estacion			char(10),
    @EstacionDestino		char(10),
    @TiempoEstandarFijo		float,
    @TiempoEstandarVariable 	float,
    @DescuentoInverso		float,
    @SucursalAlmacen        	int,
    @SucursalAlmacenDestino 	int,
    @ProrrateoAplicaID		int, 
    @ProrrateoAplicaIDMov	varchar(20), 
    @ProrrateoAplicaIDMovID	varchar(20),
    @ArtLotesFijos		bit,
    @ArtActividades		bit,
    @SeriesLotesAutoOrden	varchar(50),
    @CostoActividad		float,
    @CotizacionID		int,
    @CotizacionEstatusNuevo	char(15),
    @Hoy			datetime,	
    @RedondeoMonetarios		int,
    @CfgDiasHabiles		varchar(20),
    @CfgABCDiasHabiles		bit,
    @CostosImpuestoIncluido 	bit,
    @BorrarRetencionCx		bit, 
    @MovImpuestoFactor		float,
    @PrecioSinImpuestos		float,
    @ModificarCosto 		float, 
    @ModificarPrecio 		float,
    @CfgAC			bit,
    @LCMetodo			int,
    @LCPorcentajeResidual	float,
    @CP				bit,
    @PPTO			bit,
    @PPTOVentas			bit,
    @WMS			bit,
    @WMSAlmacen			bit,
    @WMSMov			varchar(20),
    @TransitoSucursal		int,
    @TransitoMov 		varchar(20), 
    @TransitoMovID 		varchar(20), 
    @TransitoEstatus 		varchar(15), 
    @TraspasoExpressMov		varchar(20), 
    @TraspasoExpressMovID	varchar(20), 
    @FEA			bit,
    @FEAConsecutivo		varchar(20),
    @FEAReferencia		varchar(50),
    @FEASerie			varchar(20),
    @FEAFolio			int,
    @MovTipoConsecutivoFEA	varchar(20),
    @CantidadDif		float,
    @CfgArrastrarSerieLote	bit,
    @CfgNotasBorrador		bit,
    @NoValidarDisponible	bit,
    @IDOrigen 			int,
    @CfgVentaArtEstatus		bit,
    @CfgVentaArtSituacion	bit,
    @CfgCostearTransferencias	bit,
    @ArtEstatus			varchar(15),
    @ArtSituacion		varchar(50),
    @ArtExcento1		bit,
    @ArtExcento2		bit,
    @ArtExcento3		bit,
    @Fiscal			bit,
    @FiscalGenerarRetenciones	bit,
    @ReferenciaAplicacionAnticipo varchar(50),
    @CxEndosoMov 		varchar(20),
    @CxEndosoMovID 		varchar(20),
    @CxEndosoID 		int,
    @AutoEndosar 		varchar(20),
    @Proveedor 			varchar(20),
    @CfgMovCxpEndoso 		varchar(20),
    @CfgCompraAutoEndosoAutoCargos bit,
    @Tarima			varchar(20),
    @Seccion			int,
    @ContUso			varchar(20),
    @ContUso2			varchar(20),
    @ContUso3			varchar(20),
    @ClavePresupuestal		varchar(50),
    @ClavePresupuestalImpuesto1	varchar(50),
    @FactorMovImpto		float,
    @FechaCaducidad		datetime,	
    @GenerarOrden		bit,
    @TipoImpuesto1		varchar(10),
    @TipoImpuesto2		varchar(10),
    @TipoImpuesto3		varchar(10),
    @TipoImpuesto5		varchar(10),
    @TipoRetencion1		varchar(10),
    @TipoRetencion2		varchar(10),
    @TipoRetencion3		varchar(10),
    @CfgRetencion2BaseImpuesto1	bit,
    @Retencion1			float,
    @Retencion2			float,
    @Retencion3			float,
    @SubClave			varchar(20),
    @EsEcuador			bit,
    @EmbarqueSumaArtJuego				varchar(20),
    @ArtCostoPromedio					money,
    @ArtCostoReposicion					money,
    @VentaMovImpuestoDesdeRemision		bit,			--MEJORA1002
    @ArrastrarMovImpuestoRemision		bit,			--MEJORA1002
    @AplicaConcepto						varchar(50),	--MEJORA1002
    @AplicaFechaEmision					datetime,		--MEJORA1002
    @MovImpuestoAplicaID				int,			--MEJORA1002
	@SubCuentaExplotarInformacion		bit,
	@SAUX								bit,
    @ValuacionOtraMoneda				varchar(10), --MEJORA6230
    @ValuacionOtraMonedaTC				float,       --MEJORA6230
    @ValuacionOtraMonedaTCV				float,       --MEJORA6230
    @ValuacionOtraMonedaTCC				float,		 --MEJORA6230
    @AnticipoFacturado					bit, --ANTICIPOFACTURADO
    @AnticipoFacturadoTipoServicio		bit,
    @ReferenciaTarjetas					varchar(50),  --BUG15665
	@UnidadDetalle						varchar(50),
	@MovUnidadActual					varchar(50)
  
  SELECT @EsEcuador = EsEcuador FROM Empresa WHERE Empresa = @Empresa
  SELECT @SubClave = SubClave FROM MovTipo WHERE Mov = @Mov AND Modulo = @Modulo 
  SELECT @RedondeoMonetarios = RedondeoMonetarios, @CfgRetencion2BaseImpuesto1 = ISNULL(Retencion2BaseImpuesto1, 0) FROM Version 
  -- Inicializar Variables
  SELECT @ArtMoneda		= NULL,
         @SumaPendiente     	= 0.0,
	 @SumaReservada		= 0.0,
         @SumaOrdenada		= 0.0,
         @SumaImporte    	= 0.0,
         @SumaImporteNeto    	= 0.0,
         @SumaImpuestos	    	= 0.0,
         @SumaImpuestosNetos   	= 0.0,
         @SumaImpuesto1Neto    	= 0.0,
         @SumaImpuesto2Neto    	= 0.0,
         @SumaImpuesto3Neto    	= 0.0,
         @SumaImpuesto5Neto    	= 0.0,
	 @SumaDescuentoLinea	= 0.0,
         @SumaComision		= 0.0,
         @SumaPrecioLinea	= 0.0,
         @SumaCostoLinea	= 0.0,
    	 @SumaPeso		= 0.0,
    	 @SumaVolumen		= 0.0,
	 @SumaRetencion	 	= 0.0,
	 @SumaRetencion2 	= 0.0,
	 @SumaRetencion3 	= 0.0,
         @ComisionAcum		= 0.0,
         @ComisionImporteNeto	= 0.0,
	 @ExplotandoRenglon	= NULL,
--       @UsaCacheCostos	= 0,
--	 @UltCostoInvTotal	= 0.0,
         @YaGeneroConsecutivo   = 0,
	 @MatarAntes 		= 0,
	 @UltRenglonIDJuego	= NULL,
	 @DetalleTipo		= NULL,
         @Merma			= NULL,
         @Desperdicio	        = NULL,
         @VIN			= NULL,
         @UltAgente		= NULL,
         @Producto		= NULL,
         @SubProducto		= NULL,
         @ComisionFactor	= 1.0,
         @IVAFiscal		 = NULL,
         @IEPSFiscal		 = NULL,
         @SucursalAlmacen        = NULL,
         @SucursalAlmacenDestino = NULL,
         @ArtLotesFijos		 = 0,
         @ArtActividades	 = 0,
    	 @MovImpuesto 		 = 0,
         @CostosImpuestoIncluido = 0,
         @BorrarRetencionCx	 = 0,
         @FacturandoRemision     = 0,
	 @NoValidarDisponible	 = 0,
         @Seccion		 = NULL,
         @ClavePresupuestal	 = NULL,
         @ClavePresupuestalImpuesto1 = NULL,
         @ArrastrarMovImpuestoRemision = 0, --MEJORA1002
         @MovImpuestoAplicaID = NULL,       --MEJORA1002
         @AplicaConcepto = NULL,            --MEJORA1002
         @AplicaFechaEmision = NULL,         --MEJORA1002
         @AnticipoFacturadoTipoServicio = NULL --ANTICIPOFACTURADO

  SELECT @AlmacenOriginal = @Almacen, @AlmacenDestinoOriginal = @AlmacenDestino
  SELECT @GenerarAlmacen = @Almacen, @GenerarAlmacenDestino = @AlmacenDestino
  SELECT @Hoy = @FechaRegistro
  EXEC spExtraerFecha @Hoy OUTPUT

  SELECT @CfgDiasHabiles  = DiasHabiles, 
         @CP = ISNULL(CP, 0),
         @PPTO  = ISNULL(PPTO, 0),
         @PPTOVentas = ISNULL(PPTOVentas, 0),
         @WMS   = ISNULL(WMS, 0),
         @CfgAC = ISNULL(AC, 0),
         @FEA   = ISNULL(FEA, 0),
         @Fiscal = ISNULL(Fiscal, 0),
         @SubCuentaExplotarInformacion = ISNULL(SubCuentaExplotarInformacion, 0),
         @SAUX   = ISNULL(SAUX, 0)
    FROM EmpresaGral
   WHERE Empresa = @Empresa

  SELECT @CfgRetencionMov = CASE WHEN @MovTipo = 'COMS.D' THEN CxpDevRetencion ELSE CxpRetencion END,
         @CfgIngresoMov   = VentaIngreso,
         @CfgEstadisticaAjusteMerma = InvEstadisticaAjusteMerma
    FROM EmpresaCfgMov
   WHERE Empresa = @Empresa

  SELECT @CfgArrastrarSerieLote = ISNULL(VentaArrastrarSerieLote, 0),
         @CfgNotasBorrador = NotasBorrador,
         @CfgCompraAutoEndosoAutoCargos = ISNULL(CompraAutoEndosoAutoCargos, 0),
         @VentaMovImpuestoDesdeRemision = ISNULL(VentaMovImpuestoDesdeRemision,0) --MEJORA1002
    FROM EmpresaCfg
   WHERE Empresa = @Empresa

  IF @MovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR', 'VTAS.FM') AND @CfgNotasBorrador = 1 AND (@Estatus IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR')  OR @Accion = 'CANCELAR')
    SELECT @NoValidarDisponible = 1

  IF @Modulo = 'VTAS' SELECT @AnticipoFacturadoTipoServicio = ISNULL(AnticipoFacturadoTipoServicio,0) FROM Venta WHERE ID = @ID --ANTICIPOFACTURADO

  SELECT @CfgRetencionAlPago      = ISNULL(RetencionAlPago, 0),
         @CfgRetencionAcreedor    = NULLIF(RTRIM(GastoRetencionAcreedor), ''),
         @CfgRetencionConcepto    = ISNULL(NULLIF(NULLIF(RTRIM(GastoRetencionConcepto), ''), '(Concepto Gasto)'), @Concepto),
         @CfgRetencion2Acreedor   = NULLIF(RTRIM(GastoRetencion2Acreedor), ''),
         @CfgRetencion2Concepto   = ISNULL(NULLIF(NULLIF(RTRIM(GastoRetencion2Concepto), ''), '(Concepto Gasto)'), @Concepto),
         @CfgRetencion3Acreedor   = NULLIF(RTRIM(GastoRetencion3Acreedor), ''),
         @CfgRetencion3Concepto   = ISNULL(NULLIF(NULLIF(RTRIM(GastoRetencion3Concepto), ''), '(Concepto Gasto)'), @Concepto),
         @CfgABCDiasHabiles       = ISNULL(InvFrecuenciaABCDiasHabiles, 0),
         @CfgInvAjusteCargoAgente = UPPER(InvAjusteCargoAgente),
         @CfgVentaDMultiAgenteSugerir = ISNULL(VentaDMultiAgenteSugerir, 0),
         @CfgVentaPuntosEnVales   = ISNULL(VentaPuntosEnVales, 0),
	 @CfgVentaMonedero        = ISNULL(VentaMonedero, 0), 	-- ETO Tarjetas 9-Feb-2007
         @CfgVentaArtEstatus	  = ISNULL(VentaArtEstatus, 0),
         @CfgVentaArtSituacion	  = ISNULL(VentaArtSituacion, 0),
         @CfgCostearTransferencias= ISNULL(InvCostearTransferencias, 0),
         @FiscalGenerarRetenciones= ISNULL(FiscalGenerarRetenciones, 0),
		 @EmbarqueSumaArtJuego	  = ISNULL(EmbarqueSumaArtJuego, 'Articulo Juego'),
         @ValuacionOtraMoneda		= NULLIF(InvValuacionOtraMoneda,''), --MEJORA6230
		 @ValuacionOtraMonedaTC     = CASE WHEN InvValuacionOtraMoneda = @MovMoneda THEN @MovTipoCambio ELSE dbo.fnTipoCambio(InvValuacionOtraMoneda) END, --MEJORA6230
		 @ValuacionOtraMonedaTCV    = dbo.fnTipoCambioVenta(InvValuacionOtraMoneda), --MEJORA6230
		 @ValuacionOtraMonedaTCC    = dbo.fnTipoCambioCompra(InvValuacionOtraMoneda) --MEJORA6230
		 
    FROM EmpresaCfg2
   WHERE Empresa = @Empresa
   
  IF @SubClave = 'COMS.CE/GT' SELECT @CfgRetencionAlPago = 0

  EXEC spInvAfectarInit @Accion, @Empresa, @Sucursal, @MovTipo, @OrigenTipo, @Origen, @OrigenID, @IDOrigen OUTPUT, @Ok OUTPUT, @OkRef OUTPUT

  IF @OrigenMovTipo = 'VTAS.OP' AND @IDOrigen IS NOT NULL AND @Accion <> 'CANCELAR'
    UPDATE Venta 
      SET Estatus = 'CONCLUIDO' 
    WHERE ID = @IDOrigen

  IF @Utilizar = 1
  BEGIN
    IF @Utilizar = 1 AND @MovTipo IN ('VTAS.DC', 'VTAS.DCR') SELECT @GenerarAlmacen = @AlmacenDestino, @GenerarAlmacenDestino = @Almacen
    IF @Accion = 'GENERAR' SELECT @GenerarEstatus = 'SINAFECTAR' ELSE SELECT @GenerarEstatus = 'CANCELADO' 
    IF @UtilizarMovTipo IN ('VTAS.C','VTAS.CS','VTAS.FR','VTAS.CTO','COMS.C') SELECT @GenerarDirecto = 1 ELSE SELECT @GenerarDirecto = 0
    IF @UtilizarMovTipo = 'VTAS.CO' AND @CfgVentaContratosArticulo IS NULL SELECT @Ok = 20470
    IF @VoltearAlmacen = 1 SELECT @AlmacenTemp = @GenerarAlmacen, @GenerarAlmacen = @GenerarAlmacenDestino, @GenerarAlmacenDestino = @AlmacenTemp  
    IF @Ok IS NULL
    BEGIN
      EXEC spMovGenerar @Sucursal, @Empresa, @Modulo, @Ejercicio, @Periodo, @Usuario, @FechaRegistro, @GenerarEstatus, 
	  	        @GenerarAlmacen, @GenerarAlmacenDestino,
                        @UtilizarMov, @UtilizarMovID, @GenerarDirecto, 
                        @Mov, @UtilizarSerie, @MovID OUTPUT, @ID OUTPUT, @Ok OUTPUT, @OkRef OUTPUT

      IF @Ok IS NULL AND (@MovTipo IN ('INV.EI', 'INV.DTI', 'INV.SI', 'INV.TMA') OR (@UtilizarMovTipo IN ('VTAS.VCR', 'VTAS.P', 'VTAS.R', 'VTAS.C') AND @CfgArrastrarSerieLote = 1))
        EXEC spMovCopiarSerieLote @Sucursal, @Modulo, @UtilizarID, @ID, 1
    END
    IF @Ok IS NULL
      SELECT @YaGeneroConsecutivo = 1

    -- Copiar Detalles
    IF @Ok IS NULL
    BEGIN
      IF @MovTipo = 'VTAS.EG'
        UPDATE Venta SET AlmacenDestino = (SELECT AlmacenDestinoEntregaGarantia FROM EmpresaCfg WHERE Empresa = @Empresa) WHERE ID = @ID

      IF @UtilizarMovTipo = 'VTAS.CO'
      BEGIN
        UPDATE Venta SET Condicion = NULL, Vencimiento = NULL, Referencia = RTRIM(@UtilizarMov)+' '+LTRIM(CONVERT(CHAR, @UtilizarMovID)) WHERE ID = @ID
        SELECT @Precio = sum(Precio * (Cantidad-ISNULL(CantidadCancelada,0)) * (1-(case DescuentoTipo when '$' then (ISNULL(DescuentoLinea, 0.0)/precio)*100 else ISNULL(DescuentoLinea,0.0) end)/100))
          FROM VentaD
         WHERE ID = @UtilizarID
  
        INSERT INTO VentaD (Sucursal, ID, Renglon, Aplica, AplicaID, Articulo, Cantidad, Precio, Impuesto1, Almacen) 
                    VALUES (@Sucursal, @ID, 2048, @UtilizarMov, @UtilizarMovID, @CfgVentaContratosArticulo, 1, @Precio, @CfgVentaContratosImpuesto, @Almacen)
      END ELSE 
      BEGIN
        EXEC spInvUtilizarTodoDetalle @Sucursal, @Modulo, @Base, @UtilizarID, @UtilizarMov, @UtilizarMovID, @UtilizarMovTipo, @ID, @GenerarDirecto, @Ok OUTPUT, @Empresa = @Empresa, @MovTipo = @MovTipo
        
        --REQ7890
        IF @MovTipo IN ('COMS.EG', 'COMS.EI', 'COMS.OI', 'INV.EI', 'COMS.GX') 
          EXEC spMovCopiarGastoDiverso @Modulo, @Sucursal, @UtilizarID, @ID

        IF @MovTipo IN ('VTAS.F','VTAS.FAR') AND @CfgLimiteRenFacturas > 0
          IF @FacturacionRapidaAgrupada = 1
            EXEC spInvLimiteRenFacturasAgrupada @ID, @CfgLimiteRenFacturas
          ELSE
            EXEC spInvLimiteRenFacturas @ID, @CfgLimiteRenFacturas

        IF @UtilizarMovTipo IN ('VTAS.VC', 'VTAS.VCR') AND @MovTipo NOT IN ('VTAS.DC', 'VTAS.DCR') UPDATE VentaD  SET Almacen = @GenerarAlmacen WHERE ID = @ID ELSE
        IF @UtilizarMovTipo = 'INV.P'   UPDATE InvD SET Almacen = @GenerarAlmacenDestino WHERE ID = @ID ELSE
        IF @UtilizarMovTipo = 'INV.SM' AND @MovTipo = 'INV.CM' UPDATE InvD SET Tipo = 'Salida' WHERE ID = @ID ELSE
        IF @UtilizarMovTipo = 'PROD.O' AND @MovTipo IN ('PROD.E', 'PROD.CO')
        BEGIN
          IF @CfgTipoMerma = '#'
            UPDATE ProdD 
               SET Tipo = 'Entrada', 
                   Cantidad = Cantidad - ISNULL(a.Merma, 0) - ISNULL(a.Desperdicio, 0),
                   Merma = a.Merma,
                   Desperdicio  = a.Desperdicio
              FROM ProdD d, Art a
             WHERE d.Articulo = a.Articulo AND d.ID = @ID
          ELSE
            UPDATE ProdD 
               SET Tipo = 'Entrada', 
                   Cantidad = Cantidad - ISNULL(ROUND(d.Cantidad*(a.Merma/100), 10), 0) - ISNULL(ROUND(d.Cantidad*(a.Desperdicio/100), 10), 0),
                   Merma = ROUND(d.Cantidad*(a.Merma/100), 10),
                   Desperdicio  = ROUND(d.Cantidad*(a.Desperdicio/100), 10)                 
              FROM ProdD d, Art a
             WHERE d.Articulo = a.Articulo AND d.ID = @ID

          UPDATE ProdD SET CantidadInventario = Cantidad * Factor WHERE ID = @ID
        END
      END
      SELECT @UtilizarBase = @Base, @Base = 'TODO', @IDGenerar = @ID
    END
  END ELSE
    IF @VoltearAlmacen = 1 SELECT @AlmacenTemp = @GenerarAlmacen, @GenerarAlmacen = @GenerarAlmacenDestino, @GenerarAlmacenDestino = @AlmacenTemp  


  /* Otras Afectaciones */
  IF @Modulo = 'VTAS' AND @Accion <> 'CANCELAR' AND @Estatus = 'SINAFECTAR'
    IF EXISTS(SELECT ConVigencia FROM Venta WHERE ID = @ID AND ConVigencia = 1)
      UPDATE Cte 
         SET VigenciaDesde = v.VigenciaDesde, VigenciaHasta = v.VigenciaHasta
        FROM Venta v
       WHERE v.ID = @ID AND v.Cliente = Cte.Cliente

  IF @Accion = 'GENERAR' AND @Ok IS NULL
  BEGIN
    IF @Utilizar = 1 
    BEGIN
      -- Leer MovTipo, Periodo y Ejercicio	
      EXEC spMovTipo @Modulo, @Mov, @FechaAfectacion, @Empresa, NULL, NULL, @GenerarMovTipo OUTPUT, @GenerarPeriodo OUTPUT, @GenerarEjercicio OUTPUT, @Ok OUTPUT

      BEGIN TRANSACTION

      IF @UtilizarMovTipo IN ('VTAS.C', 'VTAS.CS', 'COMS.C')
      BEGIN
        EXEC spValidarTareas @Empresa, @Modulo, @UtilizarID, 'CONCLUIDO', @Ok OUTPUT, @OkRef OUTPUT
        IF @UtilizarMovTipo IN ('VTAS.C', 'VTAS.CS') UPDATE Venta SET Estatus = 'CONCLUIDO' WHERE ID = @UtilizarID ELSE
        IF @UtilizarMovTipo = 'COMS.C' UPDATE Compra SET Estatus = 'CONCLUIDO' WHERE ID = @UtilizarID 
        IF @@ERROR <> 0 SELECT @Ok = 1
        
        -- 6777
        --EXEC spMovFlujo @Sucursal, @Accion, @Empresa, @Modulo, @UtilizarID, @UtilizarMov, @UtilizarMovID, @Modulo, @ID, @Mov, 0, @Ok OUTPUT 
      END

      IF @UtilizarBase = 'SELECCION'
        EXEC spInvAfectarUtilizarSeleccion @Modulo, @UtilizarID, @Ok OUTPUT, @OkRef OUTPUT      
    
      IF @CfgVentaArtAlmacenEspecifico = 1 AND @Modulo = 'VTAS'
      BEGIN
        IF @CfgVentaMultiAlmacen = 0
        BEGIN
          SELECT @AlmacenEspecificoVenta = NULL
          SELECT @AlmacenEspecificoVenta = MIN(NULLIF(RTRIM(AlmacenEspecificoVenta), ''))
            FROM Art a, VentaD d
           WHERE d.ID = @ID AND d.Articulo = a.Articulo AND a.AlmacenEspecificoVentaMov = @Mov AND NULLIF(RTRIM(a.AlmacenEspecificoVenta), '') IS NOT NULL
          IF @AlmacenEspecificoVenta IS NOT NULL
            UPDATE Venta SET Almacen = @AlmacenEspecificoVenta WHERE ID = @ID
        END ELSE
          UPDATE VentaD
             SET Almacen = NULLIF(RTRIM(AlmacenEspecificoVenta), '')
            FROM VentaD d, Art a
           WHERE d.ID = @ID AND d.Articulo = a.Articulo AND a.AlmacenEspecificoVentaMov = @Mov AND NULLIF(RTRIM(a.AlmacenEspecificoVenta), '') IS NOT NULL
      END

      IF @UtilizarMovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR', 'VTAS.FM') AND @MovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR', 'VTAS.FM')
      BEGIN
        UPDATE VentaD SET Cantidad = -ABS(Cantidad), CantidadInventario = -ABS(CantidadInventario), Aplica = NULL, AplicaID = NULL WHERE ID = @ID
        UPDATE Venta  SET Directo = 1, Referencia = RTRIM(@UtilizarMov)+' '+RTRIM(@UtilizarMovID) WHERE ID = @ID
      END
      IF @UtilizarMovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR', 'VTAS.FM') AND @MovTipo = 'VTAS.SD'
      BEGIN
        UPDATE VentaD SET Aplica = NULL, AplicaID = NULL WHERE ID = @ID
        UPDATE Venta  SET Directo = 1, Referencia = RTRIM(@UtilizarMov)+' '+RTRIM(@UtilizarMovID) WHERE ID = @ID
      END

      IF @Modulo = 'VTAS' 
      BEGIN
        IF @MovTipo IN ('VTAS.N', 'VTAS.FM')
          UPDATE Venta SET Condicion = NULL, Vencimiento = NULL WHERE ID = @ID
        ELSE
        IF @MovTipo <> 'VTAS.FR' 
        BEGIN
          EXEC spCalcularVencimiento @Modulo, @Empresa, @ClienteProv, @Condicion, @Hoy, @Vencimiento OUTPUT, NULL, @Ok OUTPUT             
          UPDATE Venta SET Vencimiento = @Vencimiento WHERE ID = @ID AND Vencimiento <> @Vencimiento
        END
      END

      IF @UtilizarMovTipo = 'INV.P'
        UPDATE Inv SET Almacen = AlmacenDestino, AlmacenDestino = Almacen WHERE ID = @ID 

--COMENTARIO_0001

     IF @MovTipo IN ('PROD.A', 'PROD.R', 'PROD.E')
       EXEC spProdAvanceTiempoCentro @ID, @MovTipo, @MovMoneda, @MovTipoCambio

     IF @GenerarMovTipo = 'INV.TMA' AND (SELECT WMSSugerirEntarimado FROM EmpresaCfg WHERE Empresa = @Empresa) = 1
       EXEC spSugerirEntarimado @Modulo, @IDGenerar, @Empresa, @Sucursal, @Usuario, @Ok OUTPUT, @OkRef OUTPUT

     IF @WMS = 1 
       IF EXISTS(SELECT * FROM Alm WHERE Almacen = @Almacen AND WMS = 1 AND SugerirSurtidoTarima = 1)
         IF EXISTS(SELECT * FROM AlmSugerirSurtidoTarima WHERE Almacen = @Almacen AND Modulo = @Modulo AND Mov = @Mov)
       	   EXEC spAutoSurtirTarima @Estacion, @Empresa, @Modulo, @IDGenerar, @Mov, @MovID, @Almacen, 1, @Ok OUTPUT, @OkRef OUTPUT
   
      IF @Ok IS NULL
        EXEC xpInvAfectar @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
      	     	          @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
			  @UtilizarID, @UtilizarMovTipo,
                          @Ok OUTPUT, @OkRef OUTPUT

      EXEC spInvProdSerieLoteDesdeOrden @Sucursal,@Modulo,@UtilizarID, @ID,1, @Accion, @Ok OUTPUT, @OkRef OUTPUT  

--SELECT @Ok = 1 -- breakpoint generar
      IF @Ok IS NULL
        COMMIT TRANSACTION
      ELSE BEGIN
        ROLLBACK TRANSACTION
        EXEC spEliminarMov @Modulo, @ID
      END
    END
    RETURN
  END

  IF @MovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR') AND @Accion = 'CANCELAR' AND @Estatus = 'CONCLUIDO'
    SELECT @Ok = 60060

  IF (@EstatusNuevo IN ('PENDIENTE', 'CONCLUIDO') AND @Modulo IN ('VTAS', 'COMS') AND
     @MovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR', 'VTAS.FM', 'VTAS.F', 'VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX', 'VTAS.FB', 'VTAS.D', 'VTAS.DF', 'VTAS.B', 'COMS.F', 'COMS.FL', 'COMS.EG', 'COMS.EI', 'COMS.D', 'COMS.B', 'COMS.CC', 'COMS.DC', 'COMS.CA', 'COMS.O') )
     OR (@EstatusNuevo = 'PROCESAR' AND @MovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR'))
     OR (@EstatusNuevo = 'PENDIENTE' AND @MovTipo IN ('VTAS.VCR','VTAS.R') AND @VentaMovImpuestoDesdeRemision = 1)  --MEJORA1002
     OR (@MovTipo IN ('VTAS.DCR') AND @EstatusNuevo IN ('PENDIENTE', 'CONCLUIDO') AND @Modulo = 'VTAS' AND @VentaMovImpuestoDesdeRemision = 1) --MEJORA1002
  BEGIN    
    SELECT @MovImpuesto = 1
    CREATE TABLE #MovImpuesto (
    Renglon			float		NOT NULL,
	RenglonSub		int		NOT NULL,

	Impuesto1		float		NULL,
	Impuesto2		float		NULL,
	Impuesto3		float		NULL,
	Impuesto5		float		NULL,
	Importe1		money		NULL,
	Importe2		money		NULL,
	Importe3		money		NULL,
	Importe5		money		NULL,
	Retencion1		float		NULL,
	Retencion2		float		NULL,
	Retencion3		float		NULL,
	Excento1		bit		NULL	DEFAULT 0,
	Excento2		bit		NULL	DEFAULT 0,
	Excento3		bit		NULL	DEFAULT 0,
    TipoImpuesto1		varchar(10)	COLLATE Database_Default NULL,
    TipoImpuesto2		varchar(10)	COLLATE Database_Default NULL,
    TipoImpuesto3		varchar(10)	COLLATE Database_Default NULL,
    TipoImpuesto5		varchar(10)	COLLATE Database_Default NULL,
    TipoRetencion1		varchar(10)	COLLATE Database_Default NULL,
    TipoRetencion2		varchar(10)	COLLATE Database_Default NULL,
    TipoRetencion3		varchar(10)	COLLATE Database_Default NULL,
	SubTotal			money		NULL,
	ContUso				varchar(20)	COLLATE Database_Default NULL,
	ContUso2			varchar(20)	COLLATE Database_Default NULL,
	ContUso3			varchar(20)	COLLATE Database_Default NULL, 
	ClavePresupuestal	varchar(50)	COLLATE Database_Default NULL, 
	ClavePresupuestalImpuesto1 varchar(50)	COLLATE Database_Default NULL,  
	DescuentoGlobal				float	NULL,
	LoteFijo					varchar(20)	COLLATE Database_Default NULL,
	ImporteBruto				money		NULL,
	OrigenModulo		varchar(5)	COLLATE Database_Default NULL,			--MEJORA1002
	OrigenModuloID		int			NULL,									--MEJORA1002
	OrigenConcepto		varchar(50)	COLLATE Database_Default NULL,			--MEJORA1002
	OrigenFecha     	datetime	NULL									--MEJORA1002
	)
  END

  -- Aqui estaba spMovGenerar
  IF @CobroIntegrado = 1 AND @CfgVentaComisionesCobradas = 1 AND @CfgComisionBase = 'COBRO'
  BEGIN
    SELECT @ComisionFactor = 1-ABS(ISNULL(DelEfectivo / NULLIF((ISNULL(Importe1, 0) + ISNULL(Importe2, 0) + ISNULL(Importe3, 0) + ISNULL(Importe4, 0) + ISNULL(Importe5, 0) - ISNULL(Cambio, 0) + ISNULL(DelEfectivo, 0)), 0), 0.0))
      FROM VentaCobro
     WHERE ID = @ID
  END

  IF @MovTipo = 'INV.CP' AND @Estatus IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR') AND @Accion = 'AFECTAR'
    EXEC spAfectarCambioPresentacion @Sucursal, @ID, @Empresa, @MovMoneda, @MovTipoCambio, @CfgMultiUnidades, @CfgMultiUnidadesNivel, @CfgFormaCosteo, @CfgTipoCosteo, @Ok OUTPUT, @OkRef OUTPUT

  -- Asignar el Consecutivo al Movimiento
  IF @Ok IS NULL AND @YaGeneroConsecutivo = 0 
    EXEC spMovConsecutivo @Sucursal, @SucursalOrigen, @SucursalDestino, @Empresa, @Usuario, @Modulo, @Ejercicio, @Periodo, @ID, @Mov, NULL, @Estatus, @Concepto, @Accion, @Conexion, @SincroFinal, @MovID OUTPUT, @Ok OUTPUT, @OkRef OUTPUT
  IF @Estatus IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR') AND @Accion <> 'CANCELAR' AND @Ok IS NULL
    EXEC spMovChecarConsecutivo	@Empresa, @Modulo, @Mov, @MovID, NULL, @Ejercicio, @Periodo, @Ok OUTPUT, @OkRef OUTPUT

  IF @EstatusNuevo = 'CONFIRMAR' AND @MovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR', 'VTAS.FM') RETURN

  IF @Accion IN ('CONSECUTIVO', 'SINCRO') AND @Ok IS NULL
  BEGIN
    IF @Accion = 'SINCRO' EXEC spAsignarSucursalEstatus @ID, @Modulo, @SucursalDestino, @Accion
    SELECT @Ok = 80060, @OkRef = @MovID, @Sucursal = @SucursalDestino
    RETURN
  END

  IF @Generar = 1 AND @Ok IS NULL  -- Este bloque se movio
  BEGIN
    IF @MovTipo = 'INV.IF' SELECT @GenerarEstatus = 'SINAFECTAR' ELSE SELECT @GenerarEstatus = 'CANCELADO'
    IF @MovTipo IN ('VTAS.C','VTAS.CS','VTAS.FR') SELECT @GenerarDirecto = 1 ELSE SELECT @GenerarDirecto = 0

    EXEC spMovGenerar @Sucursal, @Empresa, @Modulo, @Ejercicio, @Periodo, @Usuario, @FechaRegistro, @GenerarEstatus, 
		      @Almacen, @AlmacenDestino,
                      @Mov, @MovID, @GenerarDirecto, 
                      @GenerarMov, @GenerarSerie, @GenerarMovID OUTPUT, @IDGenerar OUTPUT, @Ok OUTPUT, @OkRef OUTPUT
  END

  -- Si hay Error Regresar
  IF @Ok IS NOT NULL OR @AfectarConsecutivo = 1 RETURN

  IF @Conexion = 0 
    BEGIN TRANSACTION

    -- Poner el Estatus del Movimiento en "AFECTANDO"
    EXEC spMovEstatus @Modulo, 'AFECTANDO', @ID, @Generar, @IDGenerar, @GenerarAfectado, @Ok OUTPUT

    -- Actualizar Sucursal Detalle
    IF @Estatus IN ('SINAFECTAR', 'CONFIRMAR', 'BORRADOR')
    BEGIN
      IF (SELECT Sincro FROM Version) = 1
      BEGIN
        IF @Modulo = 'INV'  EXEC sp_executesql N'UPDATE InvD    SET Sucursal = @Sucursal, SincroC = 1 WHERE ID = @ID AND (Sucursal <> @Sucursal OR SincroC <> 1)', N'@Sucursal int, @ID int', @Sucursal, @ID ELSE
        IF @Modulo = 'VTAS' EXEC sp_executesql N'UPDATE VentaD  SET Sucursal = @Sucursal, SincroC = 1 WHERE ID = @ID AND (Sucursal <> @Sucursal OR SincroC <> 1)', N'@Sucursal int, @ID int', @Sucursal, @ID ELSE
        IF @Modulo = 'COMS' EXEC sp_executesql N'UPDATE CompraD SET Sucursal = @Sucursal, SincroC = 1 WHERE ID = @ID AND (Sucursal <> @Sucursal OR SincroC <> 1)', N'@Sucursal int, @ID int', @Sucursal, @ID ELSE
        IF @Modulo = 'PROD' EXEC sp_executesql N'UPDATE ProdD   SET Sucursal = @Sucursal, SincroC = 1 WHERE ID = @ID AND (Sucursal <> @Sucursal OR SincroC <> 1)', N'@Sucursal int, @ID int', @Sucursal, @ID
      END
    END

    IF @Ok IS NULL OR @Ok BETWEEN 80030 AND 81000
      EXEC xpInvAfectarAntes @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
    	     	             @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
      			     NULL, NULL,
                             @Ok OUTPUT, @OkRef OUTPUT

    IF @Accion <> 'CANCELAR' AND @Estatus <> 'PENDIENTE'
    BEGIN
      -- Registrar el Movimiento en "Mov"
      EXEC spRegistrarMovimiento @Sucursal, @Empresa, @Modulo, @Mov, @MovID, @ID, @Ejercicio, @Periodo, @FechaRegistro, @FechaEmision,
                         	 @Concepto, @Proyecto, @MovMoneda, @MovTipoCambio,
                       	         @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones,
			         @Generar, @GenerarMov, @GenerarMovID, @IDGenerar,
				 @Ok OUTPUT
    END

    IF @MovTipo IN ('PROD.A', 'PROD.R', 'PROD.E') AND @Ok IS NULL
    BEGIN
      EXEC spProdCostearAvance @Sucursal, @Accion, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio,
                               @FechaEmision, @FechaRegistro, @Usuario, @Proyecto, @Ejercicio, @Periodo, @Referencia, @Observaciones,
                               @Ok OUTPUT, @OkRef OUTPUT

      IF @Estatus = 'SINAFECTAR' OR @Accion = 'CANCELAR'
        EXEC spProdAvance @Sucursal, @Accion, @Empresa, @FechaEmision, @FechaRegistro, @Usuario, @ID, @Mov, @MovID, @MovTipo, @Ok OUTPUT, @OkRef OUTPUT 
    END

    IF @MovTipo = 'PROD.E' AND @EstatusNuevo = 'CONCLUIDO' AND @Accion <> 'CANCELAR' AND @Ok IS NULL
      EXEC spProdCostearEntrada @Empresa, @ID, @MovMoneda, @MovTipoCambio, @Ok OUTPUT, @OkRef OUTPUT

    IF @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX', 'VTAS.FB') AND @CobroIntegrado = 0 AND @FacturarVtasMostrador = 0 AND @Estatus IN ('SINAFECTAR', 'CONFIRMAR', 'BORRADOR') AND @Accion <> 'CANCELAR' AND @Ok IS NULL
      EXEC xpOtrosCargos @Empresa, @ID, @ClienteProv, @MovMoneda, @MovTipoCambio, @Ok OUTPUT, @OkRef OUTPUT

    SELECT @MovUnidadActual = @MovUnidad
    IF @Modulo = 'COMS' AND @MovTipo = 'COMS.R' BEGIN
      DECLARE crCompraDetalle CURSOR
      FOR SELECT d.Renglon, d.Articulo, a.Unidad, d.Unidad
            FROM CompraD d, Art a
           WHERE d.ID = @ID
      OPEN crCompraDetalle
      FETCH NEXT FROM crCompraDetalle INTO @Renglon, @Articulo, @ArtUnidad, @UnidadDetalle
      IF @@ERROR <> 0 SELECT @Ok = 1
      WHILE @@FETCH_STATUS <> -1 AND @Ok IS NULL BEGIN
	    SELECT @MovUnidad = @ArtUnidad
        IF @CfgMultiUnidades = 0 BEGIN
          SELECT @ArtUnidad = UnidadCompra FROM Art WHERE Articulo = @Articulo
		  IF @ArtUnidad IS NOT NULL
            SELECT @MovUnidad = @ArtUnidad 
        END

        IF NULLIF(ISNULL(@UnidadDetalle, ''), '') IS NULL BEGIN
          --select '01' Info, @MovUnidad MovUnidad, @ID ID, @Articulo Articulo, @Renglon Renglon
          UPDATE CompraD set Unidad = @MovUnidad where ID = @ID and Articulo = @Articulo and Renglon = @Renglon
		END
        FETCH NEXT FROM crCompraDetalle INTO @Renglon, @Articulo, @ArtUnidad, @UnidadDetalle
      END
	  CLOSE crCompraDetalle 
	  DEALLOCATE crCompraDetalle
    END
    SELECT @MovUnidad = @MovUnidadActual

    -- Afectar el Detalle
    IF @AfectarDetalle = 1 AND @Ok IS NULL
    BEGIN
      IF @Accion = 'CANCELAR' OR (@MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX') AND @EstatusNuevo = 'PENDIENTE') SELECT @MatarAntes = 1 ELSE SELECT @MatarAntes = 0
      IF @AfectarMatando = 1 AND @Utilizar = 0 AND @MatarAntes = 1 AND @Ok IS NULL 
        EXEC spInvMatar @Sucursal, @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
			@Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Ejercicio, @Periodo, @AfectarConsignacion, @AlmacenTipo, @AlmacenDestinoTipo,
			@CfgVentaSurtirDemas, @CfgCompraRecibirDemas, @CfgTransferirDemas, @CfgBackOrders, @CfgContX, @CfgContXGenerar, @CfgEmbarcar, @CfgImpInc, @CfgMultiUnidades, @CfgMultiUnidadesNivel,
                       	@Ok OUTPUT, @OkRef OUTPUT, 
			@CfgPrecioMoneda = @CfgPrecioMoneda

      -- Definir el Cursor del Detalle
      IF @Modulo = 'VTAS'
      BEGIN
        DECLARE crVentaDetalle CURSOR
           FOR SELECT d.Renglon, d.RenglonSub, d.RenglonID, d.RenglonTipo, ISNULL(d.Cantidad, 0.0), ISNULL(d.CantidadObsequio, 0.0), ISNULL(d.CantidadInventario, 0.0), ISNULL(d.CantidadReservada, 0.0), ISNULL(d.CantidadOrdenada, 0.0), ISNULL(d.CantidadPendiente, 0.0), ISNULL(d.CantidadA, 0.0), ISNULL(d.Factor, 0.0), NULLIF(RTRIM(d.Unidad), ''), d.Articulo, NULLIF(RTRIM(d.Subcuenta), ''), ISNULL(d.Costo, 0.0), ISNULL(d.Precio, 0.0), NULLIF(RTRIM(d.DescuentoTipo), ''), ISNULL(d.DescuentoLinea, 0.0), ISNULL(d.Impuesto1, 0.0), ISNULL(d.Impuesto2, 0.0), ISNULL(d.Impuesto3, 0.0), NULLIF(RTRIM(d.Aplica), ''), NULLIF(RTRIM(d.AplicaID), ''), d.Almacen, d.Agente, NULLIF(RTRIM(UPPER(a.Tipo)), ''), a.SerieLoteInfo, NULLIF(RTRIM(UPPER(a.TipoOpcion)), ''), ISNULL(a.Peso, 0.0), ISNULL(a.Volumen, 0.0), a.Unidad, ISNULL(d.Retencion1, 0.0), ISNULL(d.Retencion2, 0.0), ISNULL(d.Retencion3, 0.0), d.UltimoReservadoCantidad, d.UltimoReservadoFecha, NULLIF(RTRIM(a.Comision), ''), NULLIF(RTRIM(d.Espacio), ''), a.LotesFijos, a.Actividades, a.CostoIdentificado, d.CostoUEPS, d.CostoPEPS, d.UltimoCosto, d.CostoEstandar, d.PrecioLista, d.PrecioTipoCambio, NULLIF(RTRIM(d.Posicion), ''), NULLIF(RTRIM(d.Tarima), ''), 
                      a.DepartamentoDetallista, a.Estatus, a.Situacion, a.Impuesto1Excento, a.Excento2, a.Excento3, d.TipoImpuesto1, d.TipoImpuesto2, d.TipoImpuesto3, a.TipoRetencion1, a.TipoRetencion2, a.TipoRetencion3, d.ContUso, d.ContUso2, d.ContUso3,
                      d.Retencion1, d.Retencion2, d.Retencion3, ISNULL(d.AnticipoFacturado,0) --ANTICIPOFACTURADO
                 FROM VentaD d, Art a
                WHERE d.ID = @ID
                  AND d.Articulo = a.Articulo
        OPEN crVentaDetalle
        FETCH NEXT FROM crVentaDetalle  INTO @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @CantidadOriginal, @CantidadObsequio, @CantidadInventario, @CantidadReservada, @CantidadOrdenada, @CantidadPendiente, @CantidadA, @Factor, @MovUnidad, @Articulo, @Subcuenta, @Costo, @Precio, @DescuentoTipo, @DescuentoLinea, @Impuesto1, @Impuesto2, @Impuesto3, @AplicaMov, @AplicaMovID, @AlmacenRenglon, @AgenteRenglon, @ArtTipo, @ArtSerieLoteInfo, @ArtTipoOpcion, @Peso, @Volumen, @ArtUnidad, @MovRetencion1, @MovRetencion2, @MovRetencion3, @UltReservadoCantidad, @UltReservadoFecha, @ArtComision, @EspacioD, @ArtLotesFijos, @ArtActividades, @ArtCostoIdentificado, @ArtCostoUEPS, @ArtCostoPEPS, @ArtUltimoCosto, @ArtCostoEstandar, @ArtPrecioLista, @PrecioTipoCambio, @Posicion, @Tarima, @ArtDepartamentoDetallista, @ArtEstatus, @ArtSituacion, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @ContUso, @ContUso2, @ContUso3, @Retencion1, @Retencion2, @Retencion3, @AnticipoFacturado--ANTICIPOFACTURADO
        IF @@ERROR <> 0 SELECT @Ok = 1
        
      END ELSE
      IF @Modulo = 'COMS'
      BEGIN
        DECLARE crCompraDetalle CURSOR
           FOR SELECT d.Renglon, d.RenglonSub, d.RenglonID, d.RenglonTipo, ISNULL(d.Cantidad, 0.0), ISNULL(d.CantidadInventario, 0.0), d.Cantidad, d.Cantidad, ISNULL(d.CantidadPendiente, 0.0), ISNULL(d.CantidadA, 0.0), d.Factor, NULLIF(RTRIM(d.Unidad), ''), d.Articulo, NULLIF(RTRIM(d.Subcuenta), ''), ISNULL(d.Costo, 0.0), ISNULL(d.Costo, 0.0), NULLIF(RTRIM(d.DescuentoTipo), ''), ISNULL(d.DescuentoLinea, 0.0), ISNULL(d.Impuesto1, 0.0), ISNULL(d.Impuesto2, 0.0), ISNULL(d.Impuesto3, 0.0), ISNULL(d.Impuesto5, 0.0), NULLIF(RTRIM(d.Aplica), ''), NULLIF(RTRIM(d.AplicaID), ''), d.Almacen, d.ServicioArticulo, d.ServicioSerie, NULLIF(RTRIM(UPPER(a.Tipo)), ''), a.SerieLoteInfo, NULLIF(RTRIM(UPPER(a.TipoOpcion)), ''), ISNULL(a.Peso, 0.0), ISNULL(a.Volumen, 0.0), a.Unidad, ISNULL(d.Retencion1, 0.0), ISNULL(d.Retencion2, 0.0), ISNULL(d.Retencion3, 0.0), a.LotesFijos, a.Actividades, a.CostoIdentificado, d.CostoUEPS, d.CostoPEPS, d.UltimoCosto, d.CostoEstandar, d.PrecioLista, NULLIF(RTRIM(d.Posicion), ''), NULLIF(RTRIM(d.Tarima), ''), 
                      a.DepartamentoDetallista, a.Estatus, a.Situacion, a.Impuesto1Excento, a.Excento2, a.Excento3, d.TipoImpuesto1, d.TipoImpuesto2, d.TipoImpuesto3, d.TipoImpuesto5, d.TipoRetencion1, d.TipoRetencion2, d.TipoRetencion3, d.ContUso, d.ContUso2, d.ContUso3, d.ClavePresupuestal, d.FechaCaducidad,
                      d.Retencion1, d.Retencion2, d.Retencion3
                 FROM CompraD d, Art a
                WHERE d.ID = @ID
                  AND d.Articulo = a.Articulo
        OPEN crCompraDetalle
        FETCH NEXT FROM crCompraDetalle INTO @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @CantidadOriginal, @CantidadInventario, @CantidadReservada, @CantidadOrdenada, @CantidadPendiente, @CantidadA, @Factor, @MovUnidad, @Articulo, @Subcuenta, @Costo, @Precio, @DescuentoTipo, @DescuentoLinea, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5, @AplicaMov, @AplicaMovID, @AlmacenRenglon, @ServicioArticulo, @ServicioSerie, @ArtTipo, @ArtSerieLoteInfo, @ArtTipoOpcion, @Peso, @Volumen, @ArtUnidad, @MovRetencion1, @MovRetencion2, @MovRetencion3, @ArtLotesFijos, @ArtActividades, @ArtCostoIdentificado, @ArtCostoUEPS, @ArtCostoPEPS, @ArtUltimoCosto, @ArtCostoEstandar, @ArtPrecioLista, @Posicion, @Tarima, @ArtDepartamentoDetallista, @ArtEstatus, @ArtSituacion, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoImpuesto5, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @ContUso, @ContUso2, @ContUso3, @ClavePresupuestal, @FechaCaducidad, @Retencion1, @Retencion2, @Retencion3
        IF @@ERROR <> 0 SELECT @Ok = 1
      END ELSE
      IF @Modulo = 'INV'
      BEGIN
        DECLARE crInvDetalle CURSOR
           FOR SELECT d.Renglon, d.RenglonSub, d.RenglonID, d.RenglonTipo, ISNULL(d.Cantidad, 0.0), ISNULL(d.CantidadInventario, 0.0), ISNULL(d.CantidadReservada, 0.0), ISNULL(d.CantidadOrdenada, 0.0), ISNULL(d.CantidadPendiente, 0.0), ISNULL(d.CantidadA, 0.0), d.Factor, NULLIF(RTRIM(d.Unidad), ''), d.Articulo, NULLIF(RTRIM(d.Subcuenta), ''), ISNULL(d.Costo, 0.0), CONVERT(money, NULL), '$', CONVERT(money, NULL), CONVERT(float, NULL), CONVERT(float, NULL), CONVERT(money, NULL), NULLIF(RTRIM(d.Aplica), ''), NULLIF(RTRIM(d.AplicaID), ''), d.Almacen, d.ProdSerieLote, NULLIF(RTRIM(UPPER(a.Tipo)), ''), a.SerieLoteInfo, NULLIF(RTRIM(UPPER(a.TipoOpcion)), ''), ISNULL(a.Peso, 0.0), ISNULL(a.Volumen, 0.0), a.Unidad, d.UltimoReservadoCantidad, d.UltimoReservadoFecha, d.Tipo, d.Producto, d.SubProducto, a.LotesFijos, a.Actividades, a.CostoIdentificado, d.CostoUEPS, d.CostoPEPS, d.UltimoCosto, d.CostoEstandar, d.PrecioLista, NULLIF(RTRIM(d.Posicion), ''), NULLIF(RTRIM(d.Tarima), ''), 
                      a.DepartamentoDetallista, a.Estatus, a.Situacion, a.Impuesto1Excento, a.Excento2, a.Excento3, a.TipoImpuesto1, a.TipoImpuesto2, a.TipoImpuesto3, a.TipoRetencion1, a.TipoRetencion2, a.TipoRetencion3, d.Seccion, d.FechaCaducidad
                 FROM InvD d, Art a
                WHERE d.ID = @ID
                  AND d.Articulo = a.Articulo
        OPEN crInvDetalle
        FETCH NEXT FROM crInvDetalle INTO @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @CantidadOriginal, @CantidadInventario, @CantidadReservada, @CantidadOrdenada, @CantidadPendiente, @CantidadA, @Factor, @MovUnidad, @Articulo, @Subcuenta, @Costo, @Precio, @DescuentoTipo, @DescuentoLinea, @Impuesto1, @Impuesto2, @Impuesto3, @AplicaMov, @AplicaMovID, @AlmacenRenglon, @ProdSerieLote, @ArtTipo, @ArtSerieLoteInfo, @ArtTipoOpcion, @Peso, @Volumen, @ArtUnidad, @UltReservadoCantidad, @UltReservadoFecha, @DetalleTipo, @Producto, @SubProducto, @ArtLotesFijos, @ArtActividades, @ArtCostoIdentificado, @ArtCostoUEPS, @ArtCostoPEPS, @ArtUltimoCosto, @ArtCostoEstandar, @ArtPrecioLista, @Posicion, @Tarima, @ArtDepartamentoDetallista, @ArtEstatus, @ArtSituacion, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @Seccion, @FechaCaducidad
        IF @@ERROR <> 0 SELECT @Ok = 1
      END ELSE
      IF @Modulo = 'PROD'
      BEGIN
        DECLARE crProdDetalle CURSOR
           FOR SELECT d.Renglon, d.RenglonSub, d.RenglonID, d.RenglonTipo, ISNULL(d.Cantidad, 0.0), ISNULL(d.CantidadInventario, 0.0), ISNULL(d.CantidadReservada, 0.0), ISNULL(d.CantidadOrdenada, 0.0), ISNULL(d.CantidadPendiente, 0.0), ISNULL(d.CantidadA, 0.0), d.Factor, NULLIF(RTRIM(d.Unidad), ''), d.Articulo, NULLIF(RTRIM(d.Subcuenta), ''), ISNULL(d.Costo, 0.0), CONVERT(money, NULL), '$', CONVERT(money, NULL), CONVERT(float, NULL), CONVERT(float, NULL), CONVERT(money, NULL), NULLIF(RTRIM(d.Aplica), ''), NULLIF(RTRIM(d.AplicaID), ''), d.Almacen, NULLIF(RTRIM(d.ProdSerieLote), ''), NULLIF(RTRIM(UPPER(a.Tipo)), ''), a.SerieLoteInfo, NULLIF(RTRIM(UPPER(a.TipoOpcion)), ''), ISNULL(a.Peso, 0.0), ISNULL(a.Volumen, 0.0), a.Unidad, d.UltimoReservadoCantidad, d.UltimoReservadoFecha, d.Tipo, d.Merma, d.Desperdicio, d.Ruta, d.Orden, d.Centro, a.LotesFijos, a.Actividades, a.CostoIdentificado, d.CostoUEPS, d.CostoPEPS, d.UltimoCosto, d.CostoEstandar, d.PrecioLista, NULLIF(RTRIM(d.Posicion), ''), NULLIF(RTRIM(d.Tarima), ''), 
                      a.DepartamentoDetallista, a.Estatus, a.Situacion, a.Impuesto1Excento, a.Excento2, a.Excento3, a.TipoImpuesto1, a.TipoImpuesto2, a.TipoImpuesto3, a.TipoRetencion1, a.TipoRetencion2, a.TipoRetencion3
                 FROM ProdD d, Art a
                WHERE d.ID = @ID
                  AND d.Articulo = a.Articulo
        OPEN crProdDetalle
        FETCH NEXT FROM crProdDetalle INTO @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @CantidadOriginal, @CantidadInventario, @CantidadReservada, @CantidadOrdenada, @CantidadPendiente, @CantidadA, @Factor, @MovUnidad, @Articulo, @Subcuenta, @Costo, @Precio, @DescuentoTipo, @DescuentoLinea, @Impuesto1, @Impuesto2, @Impuesto3, @AplicaMov, @AplicaMovID, @AlmacenRenglon, @ProdSerieLote, @ArtTipo, @ArtSerieLoteInfo, @ArtTipoOpcion, @Peso, @Volumen, @ArtUnidad, @UltReservadoCantidad, @UltReservadoFecha, @DetalleTipo, @Merma, @Desperdicio, @Ruta, @Orden, @Centro, @ArtLotesFijos, @ArtActividades, @ArtCostoIdentificado, @ArtCostoUEPS, @ArtCostoPEPS, @ArtUltimoCosto, @ArtCostoEstandar, @ArtPrecioLista, @Posicion, @Tarima, @ArtDepartamentoDetallista, @ArtEstatus, @ArtSituacion, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3
        IF @@ERROR <> 0 SELECT @Ok = 1
      END

      WHILE @@FETCH_STATUS <> -1 AND @Ok IS NULL
      BEGIN
        EXEC xpInvAfectarDetalleAntes @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
                  	              @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
		  		      @Renglon, @RenglonSub, @Articulo, @Cantidad, @Importe, @ImporteNeto, @Impuestos, @ImpuestosNetos, 
                                      @Ok OUTPUT, @OkRef OUTPUT

	SELECT @CantidadPendienteA = @CantidadPendiente, @CantidadOrdenadaA  = @CantidadOrdenada
        IF @CfgVentaMultiAgente = 1 AND @Modulo = 'VTAS' SELECT @Agente = @AgenteRenglon
        IF @CP = 1 SELECT @ClavePresupuestalImpuesto1 = ClavePresupuestalImpuesto1 FROM Art WHERE Articulo = @Articulo        

        IF @CfgMultiUnidades = 0
        BEGIN
          IF @Modulo = 'COMS' 
            SELECT @ArtUnidad = UnidadCompra FROM Art WHERE Articulo = @Articulo
          SELECT @MovUnidad = @ArtUnidad 
        END

        -- Afectar las Comisiones
        IF @Agente <> @UltAgente AND @UltAgente IS NOT NULL AND @ComisionAcum <> 0.0 AND @Ok IS NULL AND
          (((@MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FB', 'VTAS.D', 'VTAS.DF', 'VTAS.B') AND (@Estatus = 'SINAFECTAR' OR @EstatusNuevo = 'CANCELADO')) AND (@CfgVentaComisionesCobradas = 0 OR @CobroIntegrado = 1 OR @CobrarPedido = 1)) OR @MovTipo IN ('VTAS.FM', 'VTAS.N', 'VTAS.NO', 'VTAS.NR'))
        BEGIN
           EXEC spGenerarCx @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, 'AGENT', @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio,
                            @FechaAfectacion, @Concepto, @Proyecto, @Usuario,  @Autorizacion, @Referencia, @DocFuente, @Observaciones,
                            @FechaRegistro, @Ejercicio, @Periodo, 
                            NULL, NULL, @ClienteProv, NULL, @UltAgente, NULL, NULL, NULL, 
                            @ComisionImporteNeto, NULL, NULL, @ComisionAcum, 
                            NULL, NULL, NULL, NULL, NULL, NULL,
                            @CxModulo, @CxMov, @CxMovID, @Ok OUTPUT, @OkRef  OUTPUT
          SELECT @ComisionAcum = 0.0, @ComisionImporteNeto = 0.0
        END

        SELECT @UltAgente = @Agente


        IF @Renglon = @ExplotandoRenglon SELECT @ExplotandoSubCuenta = 1 ELSE SELECT @ExplotandoSubCuenta = 0

	-- Almacenes
        SELECT @Almacen = @AlmacenOriginal, @AlmacenDestino = @AlmacenDestinoOriginal
        IF @AfectarAlmacenRenglon = 1 SELECT @Almacen = NULLIF(RTRIM(@AlmacenRenglon), '')
        IF @AlmacenEspecifico IS NOT NULL SELECT @Almacen = @AlmacenEspecifico
        IF @VoltearAlmacen = 1 SELECT @AlmacenTemp = @Almacen, @Almacen = @AlmacenDestino, @AlmacenDestino = @AlmacenTemp
        IF @EsTransferencia = 0 /*AND @MovTipo NOT IN ('INV.SI', 'INV.DTI') */SELECT @AlmacenDestino = NULL
        IF @Almacen        IS NOT NULL SELECT @AlmacenTipo        = UPPER(Tipo) FROM Alm WHERE Almacen = @AlmacenRenglon
        IF @AlmacenDestino IS NOT NULL SELECT @AlmacenDestinoTipo = UPPER(Tipo) FROM Alm WHERE Almacen = @AlmacenDestino
        SELECT @SucursalAlmacen = Sucursal, @WMSAlmacen = ISNULL(WMS, 0) FROM Alm WHERE Almacen = @Almacen
        IF @AlmacenDestino IS NOT NULL
          SELECT @SucursalAlmacenDestino = Sucursal FROM Alm WHERE Almacen = @AlmacenDestino
  
	-- si no existe la Tarima que la de de alta
        IF @WMS = 1 AND @WMSAlmacen = 1 AND NULLIF(RTRIM(@Tarima), '') IS NOT NULL
          EXEC spTarimaAlta @Empresa, @Sucursal , @Usuario, @Almacen, @FechaRegistro, @FechaCaducidad, @Tarima, @Ok OUTPUT, @OkRef OUTPUT

        SELECT @AplicaMovTipo = NULL, @IDAplica = NULL
        IF @AplicaMov <> NULL 
        BEGIN
	  SELECT @AplicaMovTipo = Clave FROM MovTipo WHERE Modulo = @Modulo AND Mov = @AplicaMov

 	  IF @Modulo = 'VTAS' SELECT @IDAplica = ID FROM Venta  WHERE Empresa = @Empresa AND Mov = @AplicaMov AND MovID = @AplicaMovID AND Estatus NOT IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR', 'CANCELADO') ELSE
 	  IF @Modulo = 'COMS' SELECT @IDAplica = ID FROM Compra WHERE Empresa = @Empresa AND Mov = @AplicaMov AND MovID = @AplicaMovID AND Estatus NOT IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR', 'CANCELADO') ELSE
 	  IF @Modulo = 'PROD' SELECT @IDAplica = ID FROM Prod   WHERE Empresa = @Empresa AND Mov = @AplicaMov AND MovID = @AplicaMovID AND Estatus NOT IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR', 'CANCELADO') ELSE
 	  IF @Modulo = 'INV'  SELECT @IDAplica = ID FROM Inv    WHERE Empresa = @Empresa AND Mov = @AplicaMov AND MovID = @AplicaMovID AND Estatus NOT IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR', 'CANCELADO') 

          IF @MovTipo = 'INV.EI' AND @IDAplica IS NOT NULL
          BEGIN
            SELECT @IDSalidaTraspaso = o.ID 
              FROM Inv i
              JOIN Inv o ON o.Empresa = i.Empresa AND o.Mov = i.Origen AND o.MovID = i.OrigenID AND o.Estatus IN ('PENDIENTE', 'CONCLUIDO')
             WHERE i.ID = @IDAplica
          END
        END

	-- Checar el Renglon
        EXEC spInvInitRenglon @Empresa, 0, @CfgMultiUnidades, @CfgMultiUnidadesNivel, @CfgCompraFactorDinamico, @CfgInvFactorDinamico, @CfgProdFactorDinamico, @CfgVentaFactorDinamico, 0,
                              0, 0, @Accion, @Base, @Modulo, @ID, @Renglon, @RenglonSub, @Estatus, @EstatusNuevo, @MovTipo, @FacturarVtasMostrador, @EsTransferencia, @AfectarConsignacion, @ExplotandoSubCuenta, @AlmacenTipo, @AlmacenDestinoTipo, 
			      @Articulo, @MovUnidad, @ArtUnidad, @ArtTipo, @RenglonTipo,
			      @AplicaMovTipo, @CantidadOriginal, @CantidadInventario, @CantidadPendiente, @CantidadA, @DetalleTipo,
                              @Cantidad OUTPUT, @CantidadCalcularImporte OUTPUT, @CantidadReservada OUTPUT, @CantidadOrdenada OUTPUT, @EsEntrada OUTPUT, @EsSalida OUTPUT, @SubCuenta OUTPUT, 
                              @AfectarPiezas OUTPUT, @AfectarCostos OUTPUT, @AfectarUnidades OUTPUT, @Factor OUTPUT,
			      @Ok OUTPUT, @OkRef OUTPUT, @Seccion = @Seccion

        -- Inicializar Variables
        SELECT @Importe		 	= 0.0,
	       @ImporteNeto	 	= 0.0,
	       @Impuestos 		= 0.0,
               @ImpuestosNetos		= 0.0,
               @Impuesto1Neto 		= 0.0,
               @Impuesto2Neto 		= 0.0,
               @Impuesto3Neto 		= 0.0,
               @Impuesto5Neto 		= 0.0,
	       @DescuentoLineaImporte	= 0.0,
	       @DescuentoGlobalImporte 	= 0.0,
	       @SobrePrecioImporte 	= 0.0,
               @ImporteComision		= 0.0,
               @CostoInvTotal	        = 0.0

        IF @@FETCH_STATUS <> -2 AND @Cantidad <> 0.0 AND @Ok IS NULL
        BEGIN
          SELECT @CostosImpuestoIncluido = 0
          IF @CfgCompraCostosImpuestoIncluido = 1 AND @AlmacenTipo <> 'ACTIVOS FIJOS' 
            SELECT @CostosImpuestoIncluido = 1

          SELECT @ArtMoneda = MonedaCosto, @SeriesLotesAutoOrden = ISNULL(NULLIF(NULLIF(RTRIM(UPPER(SeriesLotesAutoOrden)), ''), '(EMPRESA)'), @CfgSeriesLotesAutoOrden)
            FROM Art 
           WHERE Articulo = @Articulo

          IF @Generar = 0 OR @GenerarAfectado = 1 
          BEGIN
              -- Eliminar los Costos en Garantias
	      IF @Modulo = 'COMS' AND @MovTipo IN ('COMS.OG', 'COMS.IG', 'COMS.DG')
              BEGIN
		SELECT @Costo = 0.0, @Precio = 0.0
                UPDATE CompraD SET Costo = NULL WHERE CURRENT OF crCompraDetalle
	      END

              SELECT @AfectarSerieLote = 0
              IF @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX') AND @AplicaMovTipo = 'VTAS.R' SELECT @FacturandoRemision = 1 ELSE SELECT @FacturandoRemision = 0
              IF @ArtTipo IN ('SERIE', 'LOTE', 'VIN', 'PARTIDA') AND @CfgSeriesLotesMayoreo = 1 AND (@EsEntrada = 1 OR @EsSalida = 1 OR @EsTransferencia = 1 OR @MovTipo IN ('COMS.B', 'COMS.CA', 'COMS.GX')) AND @FacturarVtasMostrador = 0 AND @FacturandoRemision = 0 
              BEGIN
                SELECT @AfectarSerieLote = 1 -- a proposito el procedimiento "spSeriesLotesMayoreo" se puso despues de "spArtCosto" No hay que moverlo.
                IF @ArtSerieLoteInfo = 0 
		  EXEC spSeriesLotesSurtidoAuto @Sucursal, @Empresa, @Modulo, @EsSalida, @EsTransferencia,
					        @ID,  @RenglonID, @Almacen, @Articulo, @SubCuenta, @Cantidad, @Factor,
				                @AlmacenTipo, @SeriesLotesAutoOrden,	
                                                @Ok OUTPUT, @OkRef OUTPUT, @Tarima = @Tarima
              END
              SELECT @PrecioN = @Precio, @Impuesto1N = @Impuesto1, @Impuesto2N = @Impuesto2, @Impuesto3N = @Impuesto3, @Impuesto5N = @Impuesto5

              IF @Modulo IN ('VTAS', 'COMS') AND @Accion <> 'CANCELAR'
              BEGIN
                EXEC xpMovDPrecioImpuestos @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @Renglon, @RenglonSub, @RenglonID, @ArtTipo, @Articulo, @SubCuenta, @Almacen, @CantidadOriginal, @PrecioN OUTPUT, @Impuesto1N OUTPUT, @Impuesto2N OUTPUT, @Impuesto3N OUTPUT, @Impuesto5N OUTPUT, @Ok OUTPUT, @OkRef OUTPUT

                IF @MovImpuesto = 1
                BEGIN
                  IF @ArtTipo = 'LOTE' AND @ArtLotesFijos = 1 /*AR*/ AND @NoValidarDisponible = 0 
                    EXEC spLotesFijos @Empresa, @Sucursal, @FechaEmision, @ClienteProv, @EnviarA, @Modulo, @ID, @Mov, @MovID, @MovTipo, @Renglon, @RenglonSub, @RenglonID, @ArtTipo, @Articulo, @SubCuenta, @Almacen, @ZonaImpuesto, @CantidadOriginal, @Factor,
                                      @CfgImpInc, @EsEntrada, @Precio, @DescuentoTipo, @DescuentoLinea, @DescuentoGlobal, @SobrePrecio,
                                      @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoImpuesto5,
                                      @Impuesto1N OUTPUT, @Impuesto2N OUTPUT, @Impuesto3N OUTPUT, @Impuesto5N OUTPUT, @Ok OUTPUT, @OkRef OUTPUT, 
				      @CfgPrecioMoneda = @CfgPrecioMoneda, @MovTipoCambio = @MovTipoCambio, @PrecioTipoCambio = @PrecioTipoCambio,
				      @ContUso = @ContUso, @ContUso2 = @ContUso2, @ContUso3 = @ContUso3, @ClavePresupuestal = @ClavePresupuestal, @ClavePresupuestalImpuesto1 = @ClavePresupuestalImpuesto1,
				      @Retencion1 = @Retencion1, @Retencion2 = @Retencion2, @Retencion3 = @Retencion3
                END
              END
  
              IF @PrecioN <> @Precio OR @Impuesto1N <> @Impuesto1 OR @Impuesto2 <> @Impuesto2N OR @Impuesto3 <> @Impuesto3N OR @Impuesto5 <> @Impuesto5N
              BEGIN                  
                SELECT @Precio = @PrecioN, @Impuesto1 = @Impuesto1N, @Impuesto2 = @Impuesto2N, @Impuesto3 = @Impuesto3N, @Impuesto5 = @Impuesto5N
                IF @Modulo = 'VTAS' UPDATE VentaD  SET Precio = @Precio, Impuesto1 = @Impuesto1, Impuesto2 = @Impuesto2, Impuesto3 = @Impuesto3 WHERE CURRENT OF crVentaDetalle ELSE
                IF @Modulo = 'COMS'
                BEGIN 
                  IF @ArtTipo <> 'LOTE' AND @ArtLotesFijos <> 1 /*AR*/ AND @NoValidarDisponible <> 0 
                  BEGIN
                    SELECT @Costo = @Precio
                    UPDATE CompraD SET Costo = @Costo, Impuesto1 = @Impuesto1, Impuesto2 = @Impuesto2, Impuesto3 = @Impuesto3, Impuesto5 = @Impuesto5 WHERE CURRENT OF crCompraDetalle                  
			      END
                END
              END

              IF @ArtActividades = 1 
              BEGIN
                IF @MovTipo IN ('VTAS.P', 'VTAS.S')
                  EXEC spSugerirArtActividad @Empresa, @Sucursal, @ID, @Renglon, @RenglonSub, @Articulo, @CantidadOriginal, @Agente

               IF @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX','VTAS.FB') 
               BEGIN                 
                 UPDATE VentaDAgente
                    SET CostoActividad = a.Costo
                   FROM VentaDAgente d, Actividad a 
                  WHERE d.ID = @ID AND d.Renglon = @Renglon AND d.RenglonSub = @RenglonSub AND d.Actividad = a.Actividad

                 IF @CfgCosteoActividades = 'TIEMPO ESTANDAR'
                   SELECT @CostoActividad = SUM(CostoActividad*CantidadEstandar) FROM VentaDAgente WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub                  
                 ELSE
                   SELECT @CostoActividad = SUM(CostoActividad*(CONVERT(float, Minutos)/60)) FROM VentaDAgente WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub

                 UPDATE VentaD SET CostoActividad = @CostoActividad/NULLIF(@MovTipoCambio, 0)/NULLIF(@CantidadOriginal, 0) WHERE CURRENT OF crVentaDetalle 
               END                 
              END
	      
              -- Calcular el Importe 
              IF @Modulo IN ('VTAS', 'COMS')
              BEGIN
    	        EXEC spCalculaImporte @Accion, @Modulo, @CfgImpInc, @MovTipo, @EsEntrada, @CantidadCalcularImporte, @Precio, @DescuentoTipo, @DescuentoLinea, @DescuentoGlobal, @SobrePrecio, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5,
                                      @Importe OUTPUT, @ImporteNeto OUTPUT, @DescuentoLineaImporte OUTPUT, @DescuentoGlobalImporte OUTPUT, @SobrePrecioImporte OUTPUT, 
                                      @Impuestos OUTPUT, @ImpuestosNetos OUTPUT, @Impuesto1Neto OUTPUT, @Impuesto2Neto OUTPUT, @Impuesto3Neto OUTPUT, @Impuesto5Neto OUTPUT,  
				      @Articulo = @Articulo, @CantidadObsequio = @CantidadObsequio, @CfgPrecioMoneda = @CfgPrecioMoneda, @MovTipoCambio = @MovTipoCambio, @PrecioTipoCambio = @PrecioTipoCambio,
				      @Retencion1 = @Retencion1, @Retencion2 = @Retencion2, @Retencion3 = @Retencion3, @ID = @ID, @AnticipoFacturado = @AnticipoFacturado --ANTICIPOFACTURADO

                IF @MovImpuesto = 1 AND NOT (@ArtTipo = 'LOTE' AND @ArtLotesFijos = 1)
                BEGIN
                   IF @Modulo = 'VTAS' --MEJORA1002
                   BEGIN
                     IF EXISTS(SELECT * FROM Venta v JOIN MovTipo mt ON v.Mov = mt.Mov AND mt.Modulo = @Modulo WHERE v.Empresa = @Empresa AND v.Mov = @AplicaMov AND v.MovID = @AplicaMovID AND mt.Clave IN ('VTAS.VCR','VTAS.R')) AND @VentaMovImpuestoDesdeRemision = 1 AND @MovTipo IN ('VTAS.F','VTAS.DCR')
                     BEGIN
                       SELECT @ArrastrarMovImpuestoRemision = 1
                       SELECT @MovImpuestoAplicaID = ID, @AplicaConcepto = Concepto, @AplicaFechaEmision = FechaEmision FROM Venta WHERE Empresa = @Empresa AND Mov = @AplicaMov AND MovID = @AplicaMovID
                     END ELSE
                     BEGIN
                       SELECT @ArrastrarMovImpuestoRemision = 0, @MovImpuestoAplicaID = NULL, @AplicaConcepto = NULL, @AplicaFechaEmision = NULL
                     END  
                   END
                     
                   IF @CantidadOriginal<0.0 AND @AnticipoFacturado = 0 SELECT @MovImpuestoFactor = -1.0 ELSE SELECT @MovImpuestoFactor = 1.0 --ANTICIPOFACTURADO
                   IF @ArrastrarMovImpuestoRemision = 0 --MEJORA1002
                   BEGIN
                     INSERT #MovImpuesto (Renglon,  RenglonSub,  Retencion1,     Retencion2,     Retencion3,     Excento1,     Excento2,     Excento3,     TipoImpuesto1,  TipoImpuesto2,  TipoImpuesto3,  TipoImpuesto5,  TipoRetencion1,  TipoRetencion2,  TipoRetencion3,  Impuesto1,  Impuesto2,  Impuesto3,  Impuesto5,  Importe1,                          Importe2,                          Importe3,                          Importe5,                          SubTotal,                        ContUso,  ContUso2,  ContUso3,  ClavePresupuestal,  ClavePresupuestalImpuesto1,  DescuentoGlobal, ImporteBruto)
                                   SELECT @Renglon, @RenglonSub, @MovRetencion1, @MovRetencion2, @MovRetencion3, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoImpuesto5, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5, @Impuesto1Neto*@MovImpuestoFactor, @Impuesto2Neto*@MovImpuestoFactor, @Impuesto3Neto*@MovImpuestoFactor, @Impuesto5Neto*@MovImpuestoFactor, @ImporteNeto*@MovImpuestoFactor, @ContUso, @ContUso2, @ContUso3, @ClavePresupuestal, @ClavePresupuestalImpuesto1, @DescuentoGlobal, @Importe
                   END ELSE
                   BEGIN
                     IF @ArrastrarMovImpuestoRemision = 1 --MEJORA1002
                     BEGIN                       
                       INSERT #MovImpuesto (OrigenModulo,  OrigenModuloID,       Renglon,  RenglonSub,  Retencion1,     Retencion2,     Retencion3,     Excento1,     Excento2,     Excento3,     TipoImpuesto1,  TipoImpuesto2,  TipoImpuesto3,  TipoImpuesto5,  TipoRetencion1,  TipoRetencion2,  TipoRetencion3,  Impuesto1,  Impuesto2,  Impuesto3,  Impuesto5,  Importe1,                          Importe2,                          Importe3,                          Importe5,                          SubTotal,                        ContUso,  ContUso2,  ContUso3,  ClavePresupuestal,  ClavePresupuestalImpuesto1,  DescuentoGlobal,  ImporteBruto, OrigenConcepto,  OrigenFecha) 
                                     SELECT 'VTAS',        @MovImpuestoAplicaID, @Renglon, @RenglonSub, @MovRetencion1, @MovRetencion2, @MovRetencion3, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoImpuesto5, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5, @Impuesto1Neto*@MovImpuestoFactor, @Impuesto2Neto*@MovImpuestoFactor, @Impuesto3Neto*@MovImpuestoFactor, @Impuesto5Neto*@MovImpuestoFactor, @ImporteNeto*@MovImpuestoFactor, @ContUso, @ContUso2, @ContUso3, @ClavePresupuestal, @ClavePresupuestalImpuesto1, @DescuentoGlobal, @Importe,     @AplicaConcepto, @AplicaFechaEmision                     
                     END
                   END              
                END
                
                IF @Modulo = 'COMS'
                BEGIN
                  SELECT @Costo = @ImporteNeto / @Cantidad
                  --IF @CostosImpuestoIncluido = 1 SELECT @Costo = ROUND(@Costo, @RedondeoMonetarios)
                END
                            
                IF @@ERROR <> 0 SELECT @Ok = 1
              END

              -- Afectar la Cantidad
              SELECT @AfectarCantidad = NULL

              IF @AfectarUnidades = 1 AND @Ok IS NULL
              BEGIN
		EXEC spInvAfectarUnidades @SucursalAlmacen, @Accion, @Base, @Empresa, @Usuario, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @Estatus,
			                  @Articulo, @ArtMoneda, @ArtTipoCambio, @ArtTipo, @SubCuenta, @Almacen, @AlmacenTipo, @AlmacenDestino, @AlmacenDestinoTipo, @EsEntrada, @CantidadOriginal, @Cantidad, @Factor, 
					  @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, 
					  @FechaRegistro, @FechaAfectacion, @Ejercicio, @Periodo, @AplicaMov, @AplicaMovID, @OrigenTipo,
					  @AfectarCostos, @AfectarPiezas, @AfectarVtasMostrador, @FacturarVtasMostrador, @AfectarConsignacion, @EsTransferencia, @CfgSeriesLotesMayoreo, /*@CfgAutoConsig, */@CfgFormaCosteo, @CfgTipoCosteo, 
					  @CantidadReservada, @ReservadoParcial OUTPUT, @UltRenglonIDJuego OUTPUT, @CantidadJuego OUTPUT, @CantidadMinimaJuego OUTPUT,
					  @UltReservadoCantidad OUTPUT, @UltReservadoFecha OUTPUT, @AfectarCantidad OUTPUT, @AfectarAlmacen OUTPUT, @AfectarAlmacenDestino OUTPUT,
 		    		    	  @Ok OUTPUT, @OkRef OUTPUT, @Tarima = @Tarima
              END 
              ELSE 
                SELECT @ReservadoParcial = 0.0, @AfectarAlmacen = @Almacen, @AfectarAlmacenDestino = @AlmacenDestino

              IF @FacturandoRemision = 1 AND @Accion <> 'CANCELAR' AND @ArtTipo NOT IN ('JUEGO', 'SERVICIO')
              BEGIN
                SELECT @Costo = ISNULL(SUM(Cantidad*Costo)/NULLIF(SUM(Cantidad), 0.0), 0.0) 
                  FROM VentaD 
                 WHERE ID = @IDAplica AND Articulo = @Articulo AND ISNULL(SubCuenta,'') = ISNULL(@SubCuenta,'')

                IF @Costo = 0.0 
                  SELECT @AfectarCostos = 1 
                ELSE
                  UPDATE VentaD SET Costo = @Costo WHERE CURRENT OF crVentaDetalle 
              END

	      /** JH 25.10.2006 **/
              IF @Modulo = 'VTAS' AND @AlmacenTipo = 'GARANTIAS' AND @Accion <> 'CANCELAR'
              BEGIN
                UPDATE VentaD SET Costo = NULL WHERE CURRENT OF crVentaDetalle 
                SELECT @Costo = 0.0
              END
	      /** JH 25.10.2006 **/

              IF @EsSalida = 1 AND @Modulo IN ('VTAS', 'INV') AND @EsTransferencia = 0 AND @AlmacenTipo <> 'ACTIVOS FIJOS' AND @Accion = 'AFECTAR' AND @FacturarVtasMostrador = 0 /*AR 11/09/07 */
                EXEC spChecarConsignacion @Empresa, @SucursalAlmacen, @Usuario, @Modulo, @Mov, @MovID,
				          @FechaAfectacion, @Ejercicio, @Periodo, @ArtMoneda, @Almacen, @Tarima, @Articulo, @SubCuenta, @AfectarCantidad, 
					  @Ok OUTPUT, @OkRef OUTPUT

              IF @AfectarCostos = 1 OR @EsTransferencia = 1 OR @MovTipo IN ('COMS.CC', 'COMS.DC') AND @Ok IS NULL
              BEGIN         
	        -- Calcular el Costo del Articulo
                IF @MovTipo IN ('COMS.EG', 'COMS.EI')
                  SELECT @CostoInv = CostoInv FROM CompraD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub
                ELSE IF @MovTipo IN ('INV.EI')
                  SELECT @CostoInv = CostoInv FROM InvD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub
                ELSE IF @MovTipo NOT IN ('COMS.D') 
                  SELECT @CostoInv = @Costo

                IF @CostosImpuestoIncluido = 1
                  SELECT @CostoInv = @CostoInv + (@ImpuestosNetos / @Cantidad)

                EXEC spArtCosto @SucursalAlmacen, @Accion, @Empresa, @Modulo, @AfectarCostos,
                                @EsEntrada, @EsSalida, @EsTransferencia, @AfectarSerieLote, @CfgFormaCosteo, @CfgTipoCosteo,
                                @ArtTipo, @Articulo, @SubCuenta, @Cantidad, @MovUnidad, @Factor, @CostoInv, @Costo,
                                @Mov, @MovID, @MovTipo, @AplicaMovTipo, @FechaAfectacion, @MovMoneda, @MovTipoCambio,		
        		        @ID, @RenglonID, @Almacen, @AlmacenTipo, 0, @CfgCosteoSeries, @CfgCosteoLotes, @CfgCosteoMultipleSimultaneo, @ArtCostoIdentificado, 
                                @ArtCosto OUTPUT, @ArtAjusteCosteo OUTPUT, @ArtCostoUEPS OUTPUT, @ArtCostoPEPS OUTPUT, @ArtUltimoCosto OUTPUT, @ArtCostoEstandar OUTPUT, @ArtCostoPromedio OUTPUT, @ArtCostoReposicion, @ArtPrecioLista OUTPUT,
                                @ArtMoneda OUTPUT, @ArtFactor OUTPUT, @ArtTipoCambio OUTPUT, @Ok OUTPUT, @Renglon = @Renglon, @RenglonSub = @RenglonSub, @OtraMoneda = @ValuacionOtraMoneda, @OtraMonedaTipoCambio = @ValuacionOtraMonedaTC, @OtraMonedaTipoCambioVenta = @ValuacionOtraMonedaTCV, @OtraMonedaTipoCambioCompra = @ValuacionOtraMonedaTCC --MEJORA6230


                IF @CfgCosteoNivelSubCuenta = 1 AND @ArtTipoOpcion <> 'NO' 
                  EXEC spArtCosto @SucursalAlmacen, @Accion, @Empresa, @Modulo, @AfectarCostos,
                                  @EsEntrada, @EsSalida, @EsTransferencia, @AfectarSerieLote, @CfgFormaCosteo, @CfgTipoCosteo,
                                  @ArtTipo, @Articulo, @SubCuenta, @Cantidad, @MovUnidad, @Factor, @CostoInv, @Costo,
                                  @Mov, @MovID, @MovTipo, @AplicaMovTipo, @FechaAfectacion, @MovMoneda, @MovTipoCambio,
        		          @ID, @RenglonID, @Almacen, @AlmacenTipo, 1, @CfgCosteoSeries, @CfgCosteoLotes, @CfgCosteoMultipleSimultaneo, @ArtCostoIdentificado, 
                                  @ArtCosto OUTPUT, @ArtAjusteCosteo OUTPUT, @ArtCostoUEPS OUTPUT, @ArtCostoPEPS OUTPUT, @ArtUltimoCosto OUTPUT, @ArtCostoEstandar OUTPUT, @ArtCostoPromedio OUTPUT, @ArtCostoReposicion, @ArtPrecioLista OUTPUT,
                                  @ArtMoneda OUTPUT, @ArtFactor OUTPUT, @ArtTipoCambio OUTPUT, @Ok OUTPUT, @Renglon = @Renglon, @RenglonSub = @RenglonSub, @OtraMoneda = @ValuacionOtraMoneda, @OtraMonedaTipoCambio = @ValuacionOtraMonedaTC, @OtraMonedaTipoCambioVenta = @ValuacionOtraMonedaTCV, @OtraMonedaTipoCambioCompra = @ValuacionOtraMonedaTCC --MEJORA6230

                SELECT @ModificarCosto = @ArtCosto * @ArtFactor, @ModificarPrecio = @Precio
		EXEC xpMovModificarCostoPrecio @Accion, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @AfectarCostos, @EsEntrada, @EsSalida, @EsTransferencia, @Renglon, @RenglonSub, @Articulo, @SubCuenta, @MovUnidad, @ArtCosto, @ArtFactor, @ModificarCosto OUTPUT, @ModificarPrecio OUTPUT, @Ok OUTPUT, @OkRef OUTPUT
                IF @ModificarCosto <> @ArtCosto * @ArtFactor OR @ModificarPrecio <> @Precio
                BEGIN
                  SELECT @ArtCosto = @ModificarCosto / @ArtFactor, @Precio = @ModificarPrecio
                  IF @Modulo = 'VTAS' UPDATE VentaD SET Precio = @Precio WHERE CURRENT OF crVentaDetalle ELSE
                  IF @Modulo = 'INV'  UPDATE InvD   SET Precio = @Precio WHERE CURRENT OF crInvDetalle
    	          EXEC spCalculaImporte @Accion, @Modulo, @CfgImpInc, @MovTipo, @EsEntrada, @CantidadCalcularImporte, @Precio, @DescuentoTipo, @DescuentoLinea, @DescuentoGlobal, @SobrePrecio, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5,
                                        @Importe OUTPUT, @ImporteNeto OUTPUT, @DescuentoLineaImporte OUTPUT, @DescuentoGlobalImporte OUTPUT, @SobrePrecioImporte OUTPUT, 
                                        @Impuestos OUTPUT, @ImpuestosNetos OUTPUT, @Impuesto1Neto OUTPUT, @Impuesto2Neto OUTPUT, @Impuesto3Neto OUTPUT, @Impuesto5Neto OUTPUT, 
					@Articulo = @Articulo, @CantidadObsequio = @CantidadObsequio, @CfgPrecioMoneda = @CfgPrecioMoneda, @MovTipoCambio = @MovTipoCambio, @PrecioTipoCambio = @PrecioTipoCambio,
					@Retencion1 = @Retencion1, @Retencion2 = @Retencion2, @Retencion3 = @Retencion3, @ID = @ID, @AnticipoFacturado = @AnticipoFacturado --ANTICIPOFACTURADO
                  IF @MovImpuesto = 1 AND NOT (@ArtTipo = 'LOTE' AND @ArtLotesFijos = 1)
                  BEGIN
                    IF @Modulo = 'VTAS' --MEJORA1002
                    BEGIN
                      IF EXISTS(SELECT * FROM Venta v JOIN MovTipo mt ON v.Mov = mt.Mov AND mt.Modulo = @Modulo WHERE v.Empresa = @Empresa AND v.Mov = @AplicaMov AND v.MovID = @AplicaMovID AND mt.Clave IN ('VTAS.VCR','VTAS.R')) AND @VentaMovImpuestoDesdeRemision = 1 AND @MovTipo IN ('VTAS.F','VTAS.DCR')
                      BEGIN
                        SELECT @ArrastrarMovImpuestoRemision = 1
                        SELECT @MovImpuestoAplicaID = ID, @AplicaConcepto = Concepto, @AplicaFechaEmision = FechaEmision FROM Venta WHERE Empresa = @Empresa AND Mov = @AplicaMov AND MovID = @AplicaMovID
                      END ELSE
                      BEGIN
                        SELECT @ArrastrarMovImpuestoRemision = 0, @MovImpuestoAplicaID = NULL, @AplicaConcepto = NULL, @AplicaFechaEmision = NULL
                      END  
                   END
                                    
                   DELETE #MovImpuesto WHERE Renglon = @Renglon AND RenglonSub = @RenglonSub
                   IF @CantidadOriginal<0.0 SELECT @MovImpuestoFactor = -1.0 ELSE SELECT @MovImpuestoFactor = 1.0
                                                       
                   IF @ArrastrarMovImpuestoRemision = 0 --MEJORA1002
                   BEGIN
                     INSERT #MovImpuesto (Renglon,  RenglonSub,  Retencion1,     Retencion2,     Retencion3,     Excento1,     Excento2,     Excento3,     TipoImpuesto1,  TipoImpuesto2,  TipoImpuesto3,  TipoImpuesto5,  TipoRetencion1,  TipoRetencion2,  TipoRetencion3,  Impuesto1,  Impuesto2,  Impuesto3,  Impuesto5,  Importe1,                          Importe2,                          Importe3,                          Importe5,                          SubTotal,                        ContUso,  ContUso2,  ContUso3,  ClavePresupuestal,  ClavePresupuestalImpuesto1,  DescuentoGlobal,  ImporteBruto)
                                   SELECT @Renglon, @RenglonSub, @MovRetencion1, @MovRetencion2, @MovRetencion3, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoImpuesto5, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5, @Impuesto1Neto*@MovImpuestoFactor, @Impuesto2Neto*@MovImpuestoFactor, @Impuesto3Neto*@MovImpuestoFactor, @Impuesto5Neto*@MovImpuestoFactor, @ImporteNeto*@MovImpuestoFactor, @ContUso, @ContUso2, @ContUso3, @ClavePresupuestal, @ClavePresupuestalImpuesto1, @DescuentoGlobal, @Importe                     
                   END ELSE
                   BEGIN
                     IF @ArrastrarMovImpuestoRemision = 1 --MEJORA1002
                     BEGIN                       
                       INSERT #MovImpuesto (OrigenModulo,  OrigenModuloID,       Renglon,  RenglonSub,  Retencion1,     Retencion2,     Retencion3,     Excento1,     Excento2,     Excento3,     TipoImpuesto1,  TipoImpuesto2,  TipoImpuesto3,  TipoImpuesto5,  TipoRetencion1,  TipoRetencion2,  TipoRetencion3,  Impuesto1,  Impuesto2,  Impuesto3,  Impuesto5,  Importe1,                          Importe2,                          Importe3,                          Importe5,                          SubTotal,                        ContUso,  ContUso2,  ContUso3,  ClavePresupuestal,  ClavePresupuestalImpuesto1,  DescuentoGlobal,  ImporteBruto, OrigenConcepto,  OrigenFecha)
                                     SELECT 'VTAS',        @MovImpuestoAplicaID, @Renglon, @RenglonSub, @MovRetencion1, @MovRetencion2, @MovRetencion3, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoImpuesto5, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5, @Impuesto1Neto*@MovImpuestoFactor, @Impuesto2Neto*@MovImpuestoFactor, @Impuesto3Neto*@MovImpuestoFactor, @Impuesto5Neto*@MovImpuestoFactor, @ImporteNeto*@MovImpuestoFactor, @ContUso, @ContUso2, @ContUso3, @ClavePresupuestal, @ClavePresupuestalImpuesto1, @DescuentoGlobal, @Importe,     @AplicaConcepto, @AplicaFechaEmision                                          
                     END
                   END              
                                    
                  END
                END

                SELECT @ArtCostoInv = @ArtCosto  -- NO hay que quitar esto, porque artcosto va a cambiar
	        SELECT @CostoInvTotal = @ArtCosto * @Cantidad	
                SELECT @ArtCantidad = ISNULL(@Cantidad, 0.0)*ISNULL(@Factor, 1.0)
                IF @MovTipo IN ('COMS.EG', 'COMS.EI', 'INV.EI') SELECT @ArtCosto = @Costo / @ArtFactor
            
                /*IF @Accion <> 'CANCELAR'
                BEGIN*/
                  SELECT @PrecioSinImpuestos = dbo.fnPrecioSinImpuestos (@Empresa, @Articulo, @ArtPrecioLista)
                  -- Actualizar el Costo, en las Salidas
                  IF (@EsSalida = 1 OR @EsTransferencia = 1) AND @Accion <> 'CANCELAR' AND @Ok IS NULL
                  BEGIN
                    IF @Modulo = 'VTAS' UPDATE VentaD  SET Unidad = @MovUnidad, Costo = @ArtCosto * @ArtFactor, AjusteCosteo = @ArtAjusteCosteo * @ArtFactor, CostoUEPS = @ArtCostoUEPS * @ArtFactor, CostoPEPS = @ArtCostoPEPS * @ArtFactor, UltimoCosto = @ArtUltimoCosto * @ArtFactor, CostoEstandar = @ArtCostoEstandar * @ArtFactor, PrecioLista = @PrecioSinImpuestos, DepartamentoDetallista = @ArtDepartamentoDetallista WHERE CURRENT OF crVentaDetalle  ELSE
                    IF @Modulo = 'INV'  UPDATE InvD    SET Unidad = @MovUnidad, Costo = @ArtCosto * @ArtFactor, AjusteCosteo = @ArtAjusteCosteo * @ArtFactor, CostoUEPS = @ArtCostoUEPS * @ArtFactor, CostoPEPS = @ArtCostoPEPS * @ArtFactor, UltimoCosto = @ArtUltimoCosto * @ArtFactor, CostoEstandar = @ArtCostoEstandar * @ArtFactor, PrecioLista = @PrecioSinImpuestos, DepartamentoDetallista = @ArtDepartamentoDetallista WHERE CURRENT OF crInvDetalle    ELSE
                    IF @Modulo = 'PROD' UPDATE ProdD   SET Unidad = @MovUnidad, Costo = @ArtCosto * @ArtFactor, AjusteCosteo = @ArtAjusteCosteo * @ArtFactor, CostoUEPS = @ArtCostoUEPS * @ArtFactor, CostoPEPS = @ArtCostoPEPS * @ArtFactor, UltimoCosto = @ArtUltimoCosto * @ArtFactor, CostoEstandar = @ArtCostoEstandar * @ArtFactor, PrecioLista = @PrecioSinImpuestos, DepartamentoDetallista = @ArtDepartamentoDetallista WHERE CURRENT OF crProdDetalle   ELSE
                    IF @Modulo = 'COMS' UPDATE CompraD SET Unidad = @MovUnidad, /*Costo = @ArtCosto * @ArtFactor,*/ AjusteCosteo = @ArtAjusteCosteo * @ArtFactor, CostoUEPS = @ArtCostoUEPS * @ArtFactor, CostoPEPS = @ArtCostoPEPS * @ArtFactor, UltimoCosto = @ArtUltimoCosto * @ArtFactor, CostoEstandar = @ArtCostoEstandar * @ArtFactor, PrecioLista = @PrecioSinImpuestos, DepartamentoDetallista = @ArtDepartamentoDetallista WHERE CURRENT OF crCompraDetalle
                    IF @@ERROR <> 0 SELECT @Ok = 1
                    IF @MovTipo = 'COMS.D' UPDATE CompraD SET CostoInv = @ArtCosto  WHERE CURRENT OF crCompraDetalle 
                  END ELSE 
                  BEGIN
                    SELECT @AjustePrecioLista = NULL
                    IF @MovTipo = 'INV.EI' AND @IDSalidaTraspaso IS NOT NULL
                      SELECT @AjustePrecioLista = @PrecioSinImpuestos - (SELECT MIN(PrecioLista) FROM InvD WHERE ID = @IDSalidaTraspaso AND Articulo = @Articulo AND ISNULL(SubCuenta, '') = ISNULL(@SubCuenta, '') AND ISNULL(Unidad, '') = ISNULL(@MovUnidad, ''))

                    IF @Modulo = 'VTAS' UPDATE VentaD  SET Unidad = @MovUnidad, AjusteCosteo = @ArtAjusteCosteo * @ArtFactor, CostoUEPS = @ArtCostoUEPS * @ArtFactor, CostoPEPS = @ArtCostoPEPS * @ArtFactor, UltimoCosto = @ArtUltimoCosto * @ArtFactor, CostoEstandar = @ArtCostoEstandar * @ArtFactor, PrecioLista = @PrecioSinImpuestos, DepartamentoDetallista = @ArtDepartamentoDetallista WHERE CURRENT OF crVentaDetalle  ELSE
                    IF @Modulo = 'INV'  UPDATE InvD    SET Unidad = @MovUnidad, AjusteCosteo = @ArtAjusteCosteo * @ArtFactor, CostoUEPS = @ArtCostoUEPS * @ArtFactor, CostoPEPS = @ArtCostoPEPS * @ArtFactor, UltimoCosto = @ArtUltimoCosto * @ArtFactor, CostoEstandar = @ArtCostoEstandar * @ArtFactor, PrecioLista = @PrecioSinImpuestos, DepartamentoDetallista = @ArtDepartamentoDetallista, AjustePrecioLista = @AjustePrecioLista WHERE CURRENT OF crInvDetalle ELSE
                    IF @Modulo = 'PROD' UPDATE ProdD   SET Unidad = @MovUnidad, AjusteCosteo = @ArtAjusteCosteo * @ArtFactor, CostoUEPS = @ArtCostoUEPS * @ArtFactor, CostoPEPS = @ArtCostoPEPS * @ArtFactor, UltimoCosto = @ArtUltimoCosto * @ArtFactor, CostoEstandar = @ArtCostoEstandar * @ArtFactor, PrecioLista = @PrecioSinImpuestos, DepartamentoDetallista = @ArtDepartamentoDetallista WHERE CURRENT OF crProdDetalle   ELSE
                    IF @Modulo = 'COMS' UPDATE CompraD SET Unidad = @MovUnidad, AjusteCosteo = @ArtAjusteCosteo * @ArtFactor, CostoUEPS = @ArtCostoUEPS * @ArtFactor, CostoPEPS = @ArtCostoPEPS * @ArtFactor, UltimoCosto = @ArtUltimoCosto * @ArtFactor, CostoEstandar = @ArtCostoEstandar * @ArtFactor, PrecioLista = @PrecioSinImpuestos, DepartamentoDetallista = @ArtDepartamentoDetallista WHERE CURRENT OF crCompraDetalle 
                  END
                /*END*/

                IF @MovTipo = 'VTAS.FC' AND NULLIF(RTRIM(@ServicioSerie), '') IS NOT NULL AND @CfgVINAccesorioArt = 1 AND @CfgVINCostoSumaAccesorios = 1
                  INSERT VINAccesorio 
                         (VIN,           Tipo, Accesorio, Descripcion,    PrecioDistribuidor,  PrecioPublico,           PrecioContado,       FechaAlta,     Estatus)
                  SELECT @ServicioSerie, @Mov, @Articulo, a.Descripcion1, @ArtCosto*@Cantidad, a.PrecioLista*@Cantidad, a.Precio2*@Cantidad, @FechaEmision, 'ALTA'
                    FROM Art a
                   WHERE a.Articulo = @Articulo

 		
                IF @Modulo <> 'COMS' SELECT @Costo = @ArtCosto * @ArtFactor
--COMENTARIO_0002

                -- Afectar Saldos de la Rama 'INV'
                IF @AfectarCostos = 1 AND @ArtTipo NOT IN ('JUEGO', 'SERVICIO') /*AND NOT (@MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX') AND @AplicaMovTipo='VTAS.R')*/ AND @Ok IS NULL
                BEGIN
  		  IF @EsEntrada = 1 OR (@EsSalida = 0 AND @EsTransferencia = 1 AND @Accion <> 'CANCELAR') SELECT @EsCargo = 1 ELSE SELECT @EsCargo = 0
                  IF @MovTipo = 'COMS.B'  IF @Accion <> 'CANCELAR' SELECT @EsCargo = 0 ELSE SELECT @EsCargo = 1
                  IF @MovTipo IN ('COMS.CA', 'COMS.GX') IF @Accion <> 'CANCELAR' SELECT @EsCargo = 1 ELSE SELECT @EsCargo = 0

--COMENTARIO_0003
 		    IF @AlmacenTipo = 'ACTIVOS FIJOS' SELECT @AfectarRama = 'AF' ELSE SELECT @AfectarRama = 'INV'
                    EXEC spSaldo @SucursalAlmacen, @Accion, @Empresa, @Usuario, @AfectarRama, @ArtMoneda, @ArtTipoCambio, @Articulo, @SubCuenta, @AfectarAlmacen, @AfectarAlmacenDestino, 
                                 @Modulo, @ID, @Mov, @MovID, @EsCargo, @CostoInvTotal, @AfectarCantidad, @Factor,
                                 @FechaAfectacion, @Ejercicio, @Periodo, @AplicaMov, @AplicaMovID, 0, 0, 0,
   	  	                 @Ok OUTPUT, @OkRef OUTPUT, @Renglon = @Renglon, @RenglonSub = @RenglonSub, @RenglonID = @RenglonID, @SubGrupo = @Tarima
--COMENTARIO_0004
                END 
              END  -- Afectar Costos
              -- Afectar SeriesLotes
              IF @AfectarSerieLote = 1 AND @Ok IS NULL
              BEGIN
                EXEC spSeriesLotesMayoreo @Sucursal, @SucursalAlmacen, @SucursalAlmacenDestino, @Empresa, @Modulo, @Accion, @AfectarCostos, @EsEntrada, @EsSalida, @EsTransferencia,
                                          @ID, @RenglonID, @Almacen, @AlmacenDestino, @Articulo, @SubCuenta, @ArtTipo, @ArtSerieLoteInfo, @ArtLotesFijos, @ArtCosto, @ArtCostoInv, @Cantidad, @Factor, 
       				          @MovTipo, @AplicaMovTipo, @AlmacenTipo, @FechaEmision, @CfgCosteoSeries, @CfgCosteoLotes, @ArtCostoIdentificado, @CfgValidarLotesCostoDif, @CfgVINAccesorioArt, @CfgVINCostoSumaAccesorios,
                                          @Ok OUTPUT, @OkRef OUTPUT, @Tarima = @Tarima
                IF @ArtTipo = 'VIN' 
                BEGIN
                  IF @Modulo = 'VTAS'
	          BEGIN
  		    IF @VIN IS NOT NULL SELECT @Ok = 20630
		    SELECT @VIN = MIN(SerieLote) FROM SerieLoteMov WHERE Empresa = @Empresa AND Modulo = @Modulo AND ID = @ID AND RenglonID = @RenglonID AND Articulo  = @Articulo
                    IF @MovTipo = 'VTAS.F'
                      UPDATE Venta SET ServicioArticulo = @Articulo, ServicioSerie = @VIN WHERE ID = @ID
                  END

                  IF @Accion = 'CANCELAR' AND @Ok IS NULL
                    UPDATE VIN 
                       SET FechaMRS = NULL
                      FROM VIN v, SerieLoteMov s
		     WHERE s.Empresa = @Empresa AND s.Modulo = @Modulo AND s.ID = @ID AND s.RenglonID = @RenglonID AND s.Articulo  = @Articulo
                       AND v.VIN = s.SerieLote AND v.TieneMovimientos = 0
                  ELSE BEGIN
                    IF EXISTS(
                    SELECT v.VIN
                      FROM VIN v, SerieLoteMov s
		     WHERE s.Empresa = @Empresa AND s.Modulo = @Modulo AND s.ID = @ID AND s.RenglonID = @RenglonID AND s.Articulo  = @Articulo
                       AND v.VIN = s.SerieLote AND v.TieneMovimientos = 0)
                      UPDATE VIN 
	  	         SET TieneMovimientos = 1 
                        FROM VIN v, SerieLoteMov s
  		       WHERE s.Empresa = @Empresa AND s.Modulo = @Modulo AND s.ID = @ID AND s.RenglonID = @RenglonID AND s.Articulo  = @Articulo
                         AND v.VIN = s.SerieLote AND v.TieneMovimientos = 0

                    IF @MovTipo IN ('COMS.F', 'COMS.FL', 'COMS.EG', 'COMS.EI')
		      EXEC spVINEntrada @Empresa, @Modulo, @ID, @Mov, @RenglonID, @Articulo, @FechaEmision, @FechaRequerida, @ImporteNeto, @Impuesto1Neto, @VIN OUTPUT, @Ok OUTPUT, @OkRef OUTPUT

		    IF @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX', 'VTAS.FB') 
                      UPDATE VIN 
		         SET Cliente = @ClienteProv,
                             FechaSalida = @FechaEmision,
                             VentaID = @ID
                        FROM VIN v, SerieLoteMov s
		       WHERE s.Empresa = @Empresa AND s.Modulo = @Modulo AND s.ID = @ID AND s.RenglonID = @RenglonID AND s.Articulo  = @Articulo
                         AND v.VIN = s.SerieLote 
		  END 
                END
              END

	      -- Afectar SeriesLotes en Facturas de Mostrador 	
              IF (@MovTipo = 'VTAS.FM' AND @FacturarVtasMostrador = 1 AND @ArtTipo IN ('SERIE', 'LOTE', 'VIN', 'PARTIDA') AND @Accion <> 'CANCELAR')
              BEGIN
                SELECT @CantidadDif = @Cantidad
                SELECT @CantidadDif = @Cantidad - ISNULL(SUM(Cantidad) / @Factor, 0.0)
                  FROM SerieLoteMov
                 WHERE Empresa   = @Empresa
                   AND Modulo    = @Modulo
                   AND ID        = @ID
                   AND RenglonID = @RenglonID
                   AND Articulo  = @Articulo
                   AND ISNULL(RTRIM(SubCuenta), '') = ISNULL(@SubCuenta, '')
                IF @CantidadDif <> 0.0
                BEGIN
                  DECLARE @SerieLoteMov TABLE (Sucursal int NULL, Empresa char(5) COLLATE Database_Default NULL, Modulo char(5) COLLATE Database_Default NULL, ID int NULL, RenglonID int NULL, Articulo varchar(20) COLLATE Database_Default NULL, SubCuenta varchar(50) COLLATE Database_Default NULL, SerieLote varchar(20) COLLATE Database_Default NULL, Cantidad float NULL, CantidadAlterna float NULL, Propiedades varchar(20) COLLATE Database_Default NULL, ArtCostoInv money NULL, Cliente varchar(10) COLLATE Database_Default NULL, Localizacion varchar(10) COLLATE Database_Default NULL)
	  	  EXEC spSeriesLotesSurtidoAuto @Sucursal, @Empresa, @Modulo, @EsSalida, @EsTransferencia,
			  		        @ID,  @RenglonID, @Almacen, @Articulo, @SubCuenta, @CantidadDif, @Factor,
				                @AlmacenTipo, @SeriesLotesAutoOrden,	
                                                @Ok OUTPUT, @OkRef OUTPUT, @Temp = 1, @Tarima = @Tarima
                  EXEC spSeriesLotesMayoreo @Sucursal, @SucursalAlmacen, @SucursalAlmacenDestino, @Empresa, @Modulo, @Accion, @AfectarCostos, @EsEntrada, @EsSalida, @EsTransferencia,
                                            @ID, @RenglonID, @Almacen, @AlmacenDestino, @Articulo, @SubCuenta, @ArtTipo, @ArtSerieLoteInfo, @ArtLotesFijos, @ArtCosto, @ArtCostoInv, @CantidadDif, @Factor, 
        				    @MovTipo, @AplicaMovTipo, @AlmacenTipo, @FechaEmision, @CfgCosteoSeries, @CfgCosteoLotes, @ArtCostoIdentificado, @CfgValidarLotesCostoDif, @CfgVINAccesorioArt, @CfgVINCostoSumaAccesorios,
                                            @Ok OUTPUT, @OkRef OUTPUT, @Temp = 1, @Tarima = @Tarima
                  EXEC spSeriesLotesFusionarTemp @Ok OUTPUT, @OkRef OUTPUT

--                  DROP TABLE @SerieLoteMov 

                  SELECT @CantidadDif = @Cantidad
                  SELECT @CantidadDif = @Cantidad - ISNULL(SUM(Cantidad) / @Factor, 0.0)
                    FROM SerieLoteMov
                   WHERE Empresa   = @Empresa
                     AND Modulo    = @Modulo
                     AND ID        = @ID
                     AND RenglonID = @RenglonID
                     AND Articulo  = @Articulo
                     AND ISNULL(RTRIM(SubCuenta), '') = ISNULL(@SubCuenta, '')
                  IF @CantidadDif <> 0.0 SELECT @Ok = 20330
                END
              END
              

	      -- Recalcular Factores de Unidades
              IF @AfectarCostos = 1 AND @CfgMultiUnidades = 1 AND @CfgMultiUnidadesNivel = 'ARTICULO'
		EXEC xpArtUnidadFactorRecalc @Empresa, @Accion,	@Modulo, @ID, @Renglon, @RenglonSub, @MovTipo, @AlmacenTipo,
		    			     @Articulo, @SubCuenta, @MovUnidad, @ArtTipo, @Factor,
					     @Almacen, @Cantidad, @CantidadInventario, @EsEntrada, @EsSalida,
					     @Ok OUTPUT, @OkRef OUTPUT


              IF @Modulo IN ('COMS', 'PROD', 'INV')
              BEGIN
                IF (@CfgBackOrders = 1 AND @MovTipo IN ('COMS.F', 'COMS.FL', 'COMS.EG', 'COMS.EI', 'COMS.IG', 'INV.T', 'INV.T', 'INV.EI') OR (@MovTipo='PROD.E')) AND @Accion <> 'CANCELAR'
                BEGIN
                  SELECT @Cliente = NULL
	          SELECT @DestinoTipo = NULL, @Destino = NULL, @DestinoID = NULL

                  IF @Modulo = 'COMS' SELECT @Cliente = Cliente FROM CompraD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub ELSE
                  IF @Modulo = 'INV'  SELECT @Cliente = Cliente, @DestinoTipo = DestinoTipo, @Destino = Destino, @DestinoID = DestinoID FROM InvD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub ELSE
                  IF @Modulo = 'PROD' SELECT @Cliente = Cliente FROM ProdD   WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub 

                  IF @Modulo = 'INV' AND @Largo = 1 AND (@Cliente IS NOT NULL OR @DestinoTipo IS NOT NULL) SELECT @Ok = 20970
                  IF @Cliente IS NOT NULL
                    EXEC spInvBackOrderCliente @Sucursal, @Empresa, @Usuario, @Cliente, @Articulo, @SubCuenta, @Cantidad, @Factor, 
            	 		               @ArtMoneda, @Almacen, @FechaAfectacion, @FechaRegistro, @Ejercicio, @Periodo,
				               @Ok OUTPUT, @OkRef OUTPUT                
                END

                IF @MovTipo IN ('COMS.D', 'COMS.B', 'COMS.CA', 'COMS.GX') AND @AfectarCostos = 1 
                BEGIN
--COMENTARIO_0005
                  SELECT @DescuentoInverso = 100-ISNULL(@DescuentoGlobal, 0)
                  EXEC spR3 @DescuentoInverso, @Costo, 100, @Precio OUTPUT
      	          EXEC spCalculaImporte @Accion, @Modulo, @CfgImpInc, @MovTipo, @EsEntrada, @CantidadCalcularImporte, @Precio, NULL, NULL, @DescuentoGlobal, @SobrePrecio, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5,
                                        @Importe OUTPUT, @ImporteNeto OUTPUT, @DescuentoLineaImporte OUTPUT, @DescuentoGlobalImporte OUTPUT, @SobrePrecioImporte OUTPUT,
                                        @Impuestos OUTPUT, @ImpuestosNetos OUTPUT, @Impuesto1Neto OUTPUT, @Impuesto2Neto OUTPUT, @Impuesto3Neto OUTPUT, @Impuesto5Neto OUTPUT,  
					@Articulo = @Articulo, @CantidadObsequio = @CantidadObsequio, @CfgPrecioMoneda = @CfgPrecioMoneda, @MovTipoCambio = @MovTipoCambio, @PrecioTipoCambio = @PrecioTipoCambio,
					@Retencion1 = @Retencion1, @Retencion2 = @Retencion2, @Retencion3 = @Retencion3, @ID = @ID, @AnticipoFacturado = @AnticipoFacturado --ANTICIPOFACTURADO
                END ELSE BEGIN
                  SELECT @ImporteNeto = @Costo * @Cantidad
                END

              END
              IF @Modulo = 'PROD' SELECT @Importe = @Cantidad * @Costo

              IF @MovTipo = 'PROD.O' AND @Accion = 'AFECTAR'
              BEGIN
                EXEC spProdCentroInicial @ID, @Articulo, @SubCuenta, @ProdSerieLote, @Orden OUTPUT, @OrdenDestino OUTPUT, @Centro OUTPUT, @CentroDestino OUTPUT, @Estacion OUTPUT, @EstacionDestino OUTPUT
                UPDATE ProdD SET Centro = @Centro, Orden = @Orden, CentroDestino = @CentroDestino, OrdenDestino = @OrdenDestino, Estacion = @Estacion, EstacionDestino = @EstacionDestino WHERE CURRENT OF crProdDetalle
              END

              IF @MovTipo IN ('PROD.O', 'PROD.CO', 'PROD.E')
		EXEC spProdSerieLote @Sucursal, @Accion, @Empresa, @MovTipo, @FechaEmision, @DetalleTipo, @ProdSerieLote, @Articulo, @SubCuenta, @Cantidad, @Merma, @Desperdicio, @Factor, @Ok OUTPUT, @OkRef OUTPUT

              IF @MovTipo = 'INV.CM' AND @SubClave <> 'INV.SAUX'
                EXEC spProdSerieLoteCosto @Sucursal, @Accion, @Empresa, @Modulo, @ID, @MovTipo, @DetalleTipo, @ProdSerieLote, @Producto, @SubProducto, @CostoInvTotal, @ArtMoneda, @Mov, 0

              IF @MovTipo = 'PROD.E'
                EXEC spProdSerieLoteCosto @Sucursal, @Accion, @Empresa, @Modulo, @ID, @MovTipo, @DetalleTipo, @ProdSerieLote, @Articulo, @SubCuenta, @CostoInvTotal, @ArtMoneda, @Mov, 0

	      -- Afectar Activos Fijos
              IF @AlmacenTipo = 'ACTIVOS FIJOS' AND @ArtTipo IN ('SERIE', 'VIN') AND @CfgSeriesLotesMayoreo = 1 AND @Ok IS NULL AND
                (@EsEntrada = 1 OR @EsSalida = 1 OR @EsTransferencia = 1) AND @OrigenMovTipo <> 'COMS.CC'
                EXEC spActivoF @Sucursal, @Empresa, @Modulo, @Accion, @EsEntrada, @EsSalida, @EsTransferencia, 
                               @ID, @RenglonID, @Almacen, @AlmacenDestino, @Articulo, @ArtTipo, @Cantidad, 
			       @ArtCostoInv, @ArtMoneda, @FechaEmision, 
			       @Ok OUTPUT, @OkRef OUTPUT
              -- Afectar Estadisticas (Ventas)
              IF @Modulo = 'VTAS' AND 
                (@EstatusNuevo = 'CONCLUIDO' OR (@EstatusNuevo = 'CANCELADO' AND @Estatus <> 'PENDIENTE')) AND 
                (@MovTipo IN ('VTAS.F','VTAS.FAR','VTAS.FB', 'VTAS.D', 'VTAS.DF', 'VTAS.B') OR 
                (@MovTipo = 'VTAS.FM' AND @FacturarVtasMostrador = 1 AND @Accion <> 'CANCELAR')) AND @Ok IS NULL
              BEGIN
                IF @ArtTipo IN ('SERIE','LOTE','VIN') AND @CfgSeriesLotesMayoreo = 0 
                  SELECT @AcumularSinDetalles = 1 
                ELSE SELECT @AcumularSinDetalles = 0
		IF @MovTipo IN ('VTAS.F','VTAS.FAR','VTAS.FB','VTAS.FM') SELECT @EsCargo = 1 ELSE SELECT @EsCargo = 0

		/** 02.08.2006 **/
		/** 16.11.2006 **/
                IF @CantidadOriginal<0.0 SELECT @EsCargo = ~@EsCargo

                IF @Accion = 'CANCELAR' SELECT @EsCargo = ~@EsCargo
                IF @MovTipo = 'VTAS.B' SELECT @AcumCantidad = NULL ELSE SELECT @AcumCantidad = @Cantidad
         	EXEC spSaldo @Sucursal, @Accion, @Empresa, @Usuario, 'VTAS', @MovMoneda, NULL, @Articulo, @SubCuenta, @ClienteProv,  NULL,
                             @Modulo, @ID, @Mov, @MovID, @EsCargo, @ImporteNeto, @AcumCantidad, @Factor,
                             @FechaAfectacion, @Ejercicio, @Periodo, NULL, NULL, 0, @AcumularSinDetalles, 0,
			     @Ok OUTPUT, @OkRef OUTPUT, @Renglon = @Renglon, @RenglonSub = @RenglonSub, @RenglonID = @RenglonID
              END ELSE

              -- Afectar Estadisticas (Compra)
              IF @Modulo = 'COMS' AND (@EstatusNuevo = 'CONCLUIDO' OR (@EstatusNuevo = 'CANCELADO' AND @Estatus <> 'PENDIENTE')) AND @MovTipo IN ('COMS.F','COMS.FL','COMS.EG', 'COMS.EI','COMS.D','COMS.B','COMS.CA', 'COMS.GX') AND @Ok IS NULL
              BEGIN
                IF @ArtTipo IN ('SERIE','LOTE','VIN') AND @CfgSeriesLotesMayoreo = 0 
                  SELECT @AcumularSinDetalles = 1 
                ELSE SELECT @AcumularSinDetalles = 0
		IF @MovTipo IN ('COMS.F','COMS.FL','COMS.EG', 'COMS.EI','COMS.CA', 'COMS.GX') SELECT @EsCargo = 1 ELSE SELECT @EsCargo = 0
                IF @Accion = 'CANCELAR' SELECT @EsCargo = ~@EsCargo
                IF @MovTipo IN ('COMS.B', 'COMS.CA', 'COMS.GX') SELECT @AcumCantidad = NULL ELSE SELECT @AcumCantidad = @Cantidad
         	EXEC spSaldo @Sucursal, @Accion, @Empresa, @Usuario, 'COMS', @MovMoneda, NULL, @Articulo, @SubCuenta, @ClienteProv, NULL,
                             @Modulo, @ID, @Mov, @MovID, @EsCargo, @ImporteNeto, @AcumCantidad, @Factor,
                             @FechaAfectacion, @Ejercicio, @Periodo, NULL, NULL, 0, @AcumularSinDetalles, 0,
			     @Ok OUTPUT, @OkRef OUTPUT, @Renglon = @Renglon, @RenglonSub = @RenglonSub, @RenglonID = @RenglonID

	        -- Afectar ArtProv
                IF @MovTipo IN ('COMS.F', 'COMS.FL', 'COMS.EG', 'COMS.EI') AND @Accion <> 'CANCELAR'
                BEGIN
                  IF @MovTipo = 'COMS.EI' 
                    SELECT @ProveedorRef = ISNULL(NULLIF(RTRIM(ImportacionProveedor), ''), @ClienteProv) FROM CompraD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub
                  ELSE
                    SELECT @ProveedorRef = @ClienteProv
                  IF @CostosImpuestoIncluido = 1 SELECT @ArtProvCosto = @Costo ELSE SELECT @ArtProvCosto = @ArtCosto

                  EXEC xpArtProv @Empresa, @Accion, @Modulo, @ID, @Renglon, @RenglonSub, @MovTipo, @AlmacenTipo,
    			         @Articulo, @SubCuenta, @MovUnidad, @ArtTipo, @Factor,
				 @Almacen, @Cantidad, @CantidadInventario, @EsEntrada, @EsSalida,
                       	         @ProveedorRef, @ArtProvCosto, @FechaEmision,
				 @Ok OUTPUT, @OkRef OUTPUT
		END
              END

              IF (@CfgPosiciones = 1 OR @CfgExistenciaAlterna = 1) AND @OrigenTipo <> 'VMOS' AND @AlmacenTipo <> 'ACTIVOS FIJOS' AND @ArtTipo NOT IN ('JUEGO', 'SERVICIO') AND (@EsEntrada = 1 OR @EsSalida = 1 OR @EsTransferencia = 1 OR @MovTipo IN ('COMS.CC') OR @Mov = @CfgEstadisticaAjusteMerma) AND @Ok IS NULL
              BEGIN
                IF @CfgPosiciones = 1 AND @Posicion IS NULL 
                  SELECT @Ok = 13050
                ELSE BEGIN
                  IF @MovTipo NOT IN ('COMS.CC')
                  BEGIN
                    SELECT @AuxiliarAlternoSucursal = @SucursalAlmacen, @AuxiliarAlternoAlmacen = @Almacen
                    IF @Accion = 'CANCELAR' 
                      SELECT @AuxiliarAlternoFactorEntrada = -1.0, @AuxiliarAlternoFactorSalida = NULL
                    ELSE
                      SELECT @AuxiliarAlternoFactorEntrada = NULL, @AuxiliarAlternoFactorSalida = 1.0

                    IF @EsSalida = 1 OR @EsTransferencia = 1
                    BEGIN
                      IF @CfgExistenciaAlternaSerieLote = 1 AND @ArtTipo IN ('SERIE', 'LOTE', 'VIN', 'PARTIDA')
                        INSERT AuxiliarAlterno 
                              (Empresa,  Sucursal,                 Almacen,                 Posicion,  SerieLote, Modulo,  ID,  Renglon,  RenglonSub,  Articulo,  SubCuenta,  Unidad,     Factor,  Entrada,                                Salida)
                        SELECT @Empresa, @AuxiliarAlternoSucursal, @AuxiliarAlternoAlmacen, @Posicion, SerieLote, @Modulo, @ID, @Renglon, @RenglonSub, @Articulo, @SubCuenta, @MovUnidad, @Factor, Cantidad*@AuxiliarAlternoFactorEntrada, Cantidad*@AuxiliarAlternoFactorSalida
                          FROM SerieLoteMov
                         WHERE Empresa = @Empresa AND Modulo = @Modulo AND ID = @ID AND RenglonID = @RenglonID AND Articulo = @Articulo AND ISNULL(SubCuenta, '') = ISNULL(@SubCuenta, '')
		      ELSE
                        INSERT AuxiliarAlterno 
                              (Empresa,  Sucursal,                 Almacen,                 Posicion,  Modulo,  ID,  Renglon,  RenglonSub,  Articulo,  SubCuenta,  Unidad,     Factor,  Entrada,                                 Salida)
                        SELECT @Empresa, @AuxiliarAlternoSucursal, @AuxiliarAlternoAlmacen, @Posicion, @Modulo, @ID, @Renglon, @RenglonSub, @Articulo, @SubCuenta, @MovUnidad, @Factor, @Cantidad*@AuxiliarAlternoFactorEntrada, @Cantidad*@AuxiliarAlternoFactorSalida
                    END

                    IF @EsTransferencia = 1
                      SELECT @AuxiliarAlternoSucursal = @SucursalAlmacenDestino, @AuxiliarAlternoAlmacen = @AlmacenDestino
                    IF @Accion = 'CANCELAR' 
                      SELECT @AuxiliarAlternoFactorEntrada = NULL, @AuxiliarAlternoFactorSalida = -1.0
                    ELSE
                      SELECT @AuxiliarAlternoFactorEntrada = 1.0, @AuxiliarAlternoFactorSalida = NULL

                    IF @EsEntrada = 1 OR @EsTransferencia = 1 OR @Mov = @CfgEstadisticaAjusteMerma
                    BEGIN
                      IF @CfgExistenciaAlternaSerieLote = 1 AND @ArtTipo IN ('SERIE', 'LOTE', 'VIN', 'PARTIDA')
                        INSERT AuxiliarAlterno 
                              (Empresa,  Sucursal,                 Almacen,                 Posicion,  SerieLote, Modulo,  ID,  Renglon,  RenglonSub,  Articulo,  SubCuenta,  Unidad,     Factor,  Entrada,                                Salida)
                        SELECT @Empresa, @AuxiliarAlternoSucursal, @AuxiliarAlternoAlmacen, @Posicion, SerieLote, @Modulo, @ID, @Renglon, @RenglonSub, @Articulo, @SubCuenta, @MovUnidad, @Factor, Cantidad*@AuxiliarAlternoFactorEntrada, Cantidad*@AuxiliarAlternoFactorSalida
                          FROM SerieLoteMov
                         WHERE Empresa = @Empresa AND Modulo = @Modulo AND ID = @ID AND RenglonID = @RenglonID AND Articulo = @Articulo AND ISNULL(SubCuenta, '') = ISNULL(@SubCuenta, '')
		      ELSE
                        INSERT AuxiliarAlterno 
                              (Empresa,  Sucursal,                 Almacen,                 Posicion,  Modulo,  ID,  Renglon,  RenglonSub,  Articulo,  SubCuenta,  Unidad,     Factor,  Entrada,                                 Salida)
                        SELECT @Empresa, @AuxiliarAlternoSucursal, @AuxiliarAlternoAlmacen, @Posicion, @Modulo, @ID, @Renglon, @RenglonSub, @Articulo, @SubCuenta, @MovUnidad, @Factor, @Cantidad*@AuxiliarAlternoFactorEntrada, @Cantidad*@AuxiliarAlternoFactorSalida
                    END
                  END
                END
              END

              -- Matar el Pendiente Directamente (con Utilizar)
              IF @AfectarMatando = 1 AND @Utilizar = 1 AND @AplicaMov IS NOT NULL AND @AplicaMovID IS NOT NULL AND @Ok IS NULL
                SELECT @Ok = 71050

              -- Si afecta como pendiente generarlo y si afecta a la cantidad pendiente disminuirla
              IF (@Estatus = 'PENDIENTE' OR @EstatusNuevo = 'PENDIENTE') AND @Ok IS NULL
              BEGIN
                -- Si afecta como pendiente poner la cantidad pendiente
                IF @EstatusNuevo = 'PENDIENTE' 
                BEGIN
                  IF @Accion IN ('ASIGNAR', 'DESASIGNAR')
                    EXEC spInvAsignar @Sucursal, @Accion, @Empresa, @Modulo, @ID, @Mov, @MovID, @Almacen, @Articulo, @SubCuenta, @MovUnidad, @Cantidad OUTPUT, @Ok OUTPUT, @OkRef OUTPUT

                  IF @Accion = 'RESERVARPARCIAL' SELECT @CantidadPendiente = @Cantidad - @ReservadoParcial,  @CantidadReservada = @CantidadReservada + @ReservadoParcial ELSE
		  IF @Accion = 'RESERVAR'        SELECT @CantidadPendiente = @CantidadPendiente - @Cantidad, @CantidadReservada = @CantidadReservada + @Cantidad ELSE
		  IF @Accion = 'DESRESERVAR'  	 SELECT @CantidadPendiente = @CantidadPendiente + @Cantidad, @CantidadReservada = @CantidadReservada - @Cantidad ELSE 
		  IF @Accion = 'ASIGNAR'         SELECT @CantidadPendiente = @CantidadPendiente - @Cantidad, @CantidadOrdenada  = @CantidadOrdenada  + @Cantidad ELSE
		  IF @Accion = 'DESASIGNAR'      SELECT @CantidadPendiente = @CantidadPendiente + @Cantidad, @CantidadOrdenada  = @CantidadOrdenada  - @Cantidad ELSE
		  IF @Accion = 'CANCELAR' 
                  BEGIN
	  	    SELECT @CantidadReservada = @CantidadReservada - @Cantidad
                    IF @CantidadReservada < 0 
                      --- SELECT @CantidadPendiente = @CantidadPendiente + @CantidadReservada, @CantidadReservada = 0.0 (Bug 23531)
                      SELECT @CantidadPendiente = ROUND ((@CantidadPendiente + @CantidadReservada), 8), @CantidadReservada = 0.0
--COMENTARIO_0006
                  END ELSE SELECT @CantidadPendiente = @Cantidad
	        END 

		ELSE
		IF @EstatusNuevo = 'CANCELADO'
		  SELECT @CantidadReservada = 0.0, @CantidadPendiente = 0.0
  
 	        -- Si afecta al pendiente disminuir el pendiente
  		ELSE
                IF @Base IN ('SELECCION','PENDIENTE','TODO')
                  SELECT @CantidadPendiente = @CantidadPendiente - @Cantidad 

                IF @MovTipo IN ('VTAS.F','VTAS.FAR','VTAS.FC', 'VTAS.FG', 'VTAS.FX','VTAS.FB') AND @EstatusNuevo = 'CONCLUIDO' AND @Accion = 'AFECTAR' SELECT @CantidadPendiente = 0.0, @CantidadReservada = 0.0

		IF @Modulo NOT IN ('VTAS', 'INV', 'PROD') SELECT @CantidadOrdenada = 0.0
  	        -- Actualizar la Cantidad Pendiente del Detalle
                IF @CantidadPendiente = 0.0 SELECT @CantidadPendiente = NULL
                IF @CantidadReservada = 0.0 SELECT @CantidadReservada = NULL
                IF @CantidadOrdenada  = 0.0 SELECT @CantidadOrdenada  = NULL

                IF @Modulo = 'VTAS' UPDATE VentaD  SET CantidadCancelada = CASE WHEN @Accion = 'CANCELAR' AND @Base <> 'TODO' THEN ISNULL(CantidadCancelada, 0.0) + @Cantidad ELSE CantidadCancelada END, CantidadA = NULL, CantidadReservada = @CantidadReservada, UltimoReservadoCantidad = @UltReservadoCantidad, UltimoReservadoFecha = @UltReservadoFecha, CantidadOrdenada = @CantidadOrdenada, CantidadPendiente = @CantidadPendiente WHERE CURRENT OF crVentaDetalle ELSE
                IF @Modulo = 'INV'  UPDATE InvD    SET CantidadCancelada = CASE WHEN @Accion = 'CANCELAR' AND @Base <> 'TODO' THEN ISNULL(CantidadCancelada, 0.0) + @Cantidad ELSE CantidadCancelada END, CantidadA = NULL, CantidadReservada = @CantidadReservada, UltimoReservadoCantidad = @UltReservadoCantidad, UltimoReservadoFecha = @UltReservadoFecha, CantidadOrdenada = @CantidadOrdenada, CantidadPendiente = @CantidadPendiente WHERE CURRENT OF crInvDetalle ELSE
                IF @Modulo = 'PROD' UPDATE ProdD   SET CantidadCancelada = CASE WHEN @Accion = 'CANCELAR' AND @Base <> 'TODO' THEN ISNULL(CantidadCancelada, 0.0) + @Cantidad ELSE CantidadCancelada END, CantidadA = NULL, CantidadReservada = @CantidadReservada, UltimoReservadoCantidad = @UltReservadoCantidad, UltimoReservadoFecha = @UltReservadoFecha, CantidadOrdenada = @CantidadOrdenada, CantidadPendiente = @CantidadPendiente WHERE CURRENT OF crProdDetalle ELSE
                IF @Modulo = 'COMS' UPDATE CompraD SET CantidadCancelada = CASE WHEN @Accion = 'CANCELAR' AND @Base <> 'TODO' THEN ISNULL(CantidadCancelada, 0.0) + @Cantidad ELSE CantidadCancelada END, CantidadA = NULL, CantidadPendiente = @CantidadPendiente WHERE CURRENT OF crCompraDetalle 
                IF @@ERROR <> 0 SELECT @Ok = 1

--COMENTARIO_0007

		EXEC spArtR @Empresa, @Modulo, @Articulo, @SubCuenta, @Almacen, @MovTipo, @Factor, NULL, @CantidadPendienteA, @CantidadPendiente, NULL, @CantidadOrdenadaA, @CantidadOrdenada
              
                IF @CfgBackOrders = 1 AND @MovTipo IN ('COMS.O', 'COMS.OG', 'COMS.OI', 'PROD.O', 'INV.OT', 'INV.OI') AND @AplicaMovTipo IS NULL
                BEGIN
		   SELECT @DestinoTipo = NULL, @Destino = NULL, @DestinoID = NULL
                   IF @Modulo = 'COMS' SELECT @DestinoTipo = DestinoTipo, @Destino = Destino, @DestinoID = DestinoID FROM CompraD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub ELSE
                   IF @Modulo = 'INV'  SELECT @DestinoTipo = DestinoTipo, @Destino = Destino, @DestinoID = DestinoID FROM InvD    WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub ELSE
                   IF @Modulo = 'PROD' SELECT @DestinoTipo = DestinoTipo, @Destino = Destino, @DestinoID = DestinoID FROM ProdD   WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub 
                   IF @DestinoTipo IN (SELECT Modulo FROM Modulo) AND @Destino IS NOT NULL AND @DestinoID IS NOT NULL 
                     EXEC spInvBackOrder @Sucursal, @Accion, @Estatus, 0, @Empresa, @Usuario, @Modulo, @ID, @Mov, @MovID, 
                                         @DestinoTipo, @Destino, @DestinoID, @Articulo, @SubCuenta, @MovUnidad, @Cantidad, @Factor, @ArtMoneda, 
				  	 @Almacen, @FechaAfectacion, @FechaRegistro, @Ejercicio, @Periodo,
 				         @Ok OUTPUT, @OkRef OUTPUT, @MovTipo = @MovTipo
		END
              END
            --END -- Afectacion normal

              IF @CfgBackOrders = 1 AND @MovTipo = 'COMS.CP'
              BEGIN
                SELECT @DestinoTipo = NULL, @Destino = NULL, @DestinoID = NULL
                IF @Modulo = 'COMS' SELECT @DestinoTipo = DestinoTipo, @Destino = Destino, @DestinoID = DestinoID FROM CompraD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub 
                IF @DestinoTipo IN (SELECT Modulo FROM Modulo) AND @Destino IS NOT NULL AND @DestinoID IS NOT NULL 
                  EXEC spInvBackOrder @Sucursal, @Accion, @Estatus, 0, @Empresa, @Usuario, @Modulo, @ID, @Mov, @MovID, 
                                      @DestinoTipo, @Destino, @DestinoID, @Articulo, @SubCuenta, @MovUnidad, @Cantidad, @Factor, @ArtMoneda, 
		           	      @Almacen, @FechaAfectacion, @FechaRegistro, @Ejercicio, @Periodo,
 				      @Ok OUTPUT, @OkRef OUTPUT, @MovTipo = @MovTipo
              END
          END -- no Generar o Generar y Afectar

          IF @Generar = 1 AND @GenerarCopia = 1 AND @Ok IS NULL
          BEGIN
            -- Copiar Detalle Actual en GenerarID
            -- Ver spInvUtilizarTodoDetalle
            IF @MovTipo IN ('VTAS.C', 'VTAS.CS', 'VTAS.FR') SELECT @GenerarDirecto = 1 ELSE SELECT @GenerarDirecto = 0
            EXEC spInvGenerarDetalle @Sucursal, @Modulo, @ID, @Renglon, @RenglonSub, @IDGenerar, @GenerarDirecto, @Mov, @MovID, @Cantidad, @Ok OUTPUT

            IF @Base = 'SELECCION'
            BEGIN
              -- Limipiar la CantidadA
              IF @Modulo = 'VTAS' UPDATE VentaD  SET CantidadA = NULL WHERE CURRENT OF crVentaDetalle ELSE
              IF @Modulo = 'COMS' UPDATE CompraD SET CantidadA = NULL WHERE CURRENT OF crCompraDetalle ELSE
              IF @Modulo = 'INV'  UPDATE InvD    SET CantidadA = NULL WHERE CURRENT OF crInvDetalle ELSE
              IF @Modulo = 'PROD' UPDATE ProdD   SET CantidadA = NULL WHERE CURRENT OF crProdDetalle 
              IF @@ERROR <> 0 SELECT @Ok = 1
            END
          END

          -- Actualizar el Factor y la Unidad a NULL si Vacio y Estatus/Situacion
	  IF @Estatus IN ('SINAFECTAR', 'CONFIRMAR', 'BORRADOR') 
          BEGIN
            SELECT @TiempoEstandarFijo	   = NULL,
                   @TiempoEstandarVariable = NULL
            IF @MovTipo IN ('PROD.A', 'PROD.E')
              SELECT @TiempoEstandarFijo = ISNULL(TiempoFijo, 0), @TiempoEstandarVariable = ISNULL(TiempoVariable, 0)*@Cantidad
                FROM ProdRutaD 
               WHERE Ruta = @Ruta AND Orden = @Orden AND Centro = @Centro

	    IF @Modulo = 'VTAS' UPDATE VentaD  SET Unidad = @MovUnidad, Factor = @Factor, ArtEstatus = CASE WHEN @CfgVentaArtEstatus = 1 THEN @ArtEstatus ELSE NULL END, ArtSituacion = CASE WHEN @CfgVentaArtSituacion = 1 THEN @ArtSituacion ELSE NULL END  WHERE CURRENT OF crVentaDetalle ELSE
            IF @Modulo = 'COMS' UPDATE CompraD SET Unidad = @MovUnidad, Factor = @Factor WHERE CURRENT OF crCompraDetalle ELSE
            IF @Modulo = 'INV'  UPDATE InvD    SET Unidad = @MovUnidad, Factor = @Factor WHERE CURRENT OF crInvDetalle ELSE
            IF @Modulo = 'PROD' UPDATE ProdD   SET Unidad = @MovUnidad, Factor = @Factor, TiempoEstandarFijo = @TiempoEstandarFijo, TiempoEstandarVariable = @TiempoEstandarVariable WHERE CURRENT OF crProdDetalle 
	  END

          IF @MovTipo = 'COMS.R' 
          BEGIN
            SELECT @CompraID = NULL
            SELECT @CompraID = MAX(c.ID)
              FROM Compra c, CompraD d, MovTipo mt 
             WHERE c.Empresa = @Empresa AND c.Estatus = 'CONCLUIDO' 
               AND mt.Modulo = @Modulo AND mt.Mov = c.Mov AND mt.Clave IN ('COMS.F', 'COMS.FL', 'COMS.EG', 'COMS.EI')
               AND d.ID = c.ID AND d.Articulo = @Articulo AND ISNULL(d.SubCuenta, '') = ISNULL(@SubCuenta, '')

            IF @CompraID IS NOT NULL
              SELECT @ProveedorRef = Proveedor FROM Compra WHERE ID = @CompraID
            ELSE 
            BEGIN
              SELECT @ProveedorRef = @ClienteProv
              SELECT @ProveedorRef = ISNULL(p.Proveedor, @ClienteProv)
                FROM Art a, Prov p
               WHERE a.Articulo = @Articulo AND p.Proveedor = a.Proveedor
            END
            UPDATE CompraD SET ProveedorRef = @ProveedorRef
             WHERE CURRENT OF crCompraDetalle
          END

          IF @Modulo = 'COMS' AND @Accion IN ('AFECTAR', 'CANCELAR') AND NULLIF(RTRIM(@ServicioSerie), '') IS NOT NULL
            EXEC spSerieLoteFlujo @Sucursal, @SucursalAlmacen, @SucursalAlmacenDestino, @Accion, @Empresa, @Modulo, @ID, @ServicioArticulo, NULL, @ServicioSerie, @Almacen, @RenglonID, @Tarima = @Tarima


          IF @MovTipo IN ('VTAS.P', 'VTAS.S', 'VTAS.SD', 'VTAS.F','VTAS.FAR', 'VTAS.FB', 'VTAS.D', 'VTAS.DF', 'VTAS.B', 'VTAS.FM', 'VTAS.N', 'VTAS.NO', 'VTAS.NR', 'PROD.A', 'PROD.R', 'PROD.E') AND @FacturarVtasMostrador = 0 AND (@Estatus IN ('SINAFECTAR', 'BORRADOR') OR @Accion = 'CANCELAR') AND @Ok IS NULL
          BEGIN
            IF @Accion = 'CANCELAR' 
            BEGIN
              IF @Modulo = 'VTAS' SELECT @ImporteComision = ISNULL(Comision, 0.0) FROM VentaD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub ELSE
              IF @Modulo = 'PROD' SELECT @ImporteComision = ISNULL(Comision, 0.0) FROM ProdD  WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub 
            END ELSE BEGIN
  	      EXEC xpComisionCalcular @ID, @Accion, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
       	           	              @MovMoneda, @MovTipoCambio, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Agente, @Conexion, @SincroFinal, @Sucursal,
		  		      @Renglon, @RenglonSub, @Articulo, @Cantidad, @Importe, @ImporteNeto, @Impuestos, @ImpuestosNetos, @Costo, @ArtCosto, @ArtComision,
                                      @ImporteComision OUTPUT, @Ok OUTPUT, @OkRef OUTPUT
              IF ISNULL(@ImporteComision, 0.0) <> 0.0 AND @Ok IS NULL
              BEGIN
                IF @Modulo = 'VTAS' UPDATE VentaD SET Comision = @ImporteComision WHERE CURRENT OF crVentaDetalle ELSE
                IF @Modulo = 'PROD' UPDATE ProdD  SET Comision = @ImporteComision WHERE CURRENT OF crProdDetalle 
              END
            END
          END

          IF @MovTipo NOT IN ('COMS.R', 'COMS.C', 'COMS.O', 'COMS.OP') 
          BEGIN
            IF (SELECT TieneMovimientos FROM Art WHERE Articulo = @Articulo) = 0
              UPDATE Art SET TieneMovimientos = 1 WHERE Articulo = @Articulo
            IF NULLIF(RTRIM(@SubCuenta), '') IS NOT NULL
            BEGIN
              IF (SELECT TieneMovimientos FROM ArtSub WHERE Articulo = @Articulo AND SubCuenta = @SubCuenta) = 0
                UPDATE ArtSub SET TieneMovimientos = 1 WHERE Articulo = @Articulo AND SubCuenta = @SubCuenta
            END

            IF @MovTipo IN ('VTAS.N', 'VTAS.NO', 'VTAS.NR', 'VTAS.FM', 'VTAS.F', 'COMS.F', 'COMS.FL', 'COMS.EG', 'COMS.EI')
              EXEC spArtUlt @Articulo, @FechaEmision, @Modulo, @MovTipo, @ID
          END

          IF @EsEntrada = 1 OR @EsSalida = 1 OR @EsTransferencia = 1 
          BEGIN
            EXEC spRegistrarArtAlm @Empresa, @Articulo, @SubCuenta, @Almacen, @FechaEmision
            IF @AlmacenDestino IS NOT NULL
              EXEC spRegistrarArtAlm @Empresa, @Articulo, @SubCuenta, @AlmacenDestino, @FechaEmision
          END

          IF @MovTipo = 'PROD.O' AND @Centro IS NOT NULL
          BEGIN
            IF (SELECT TieneMovimientos FROM Centro WHERE Centro = @Centro) = 0
              UPDATE Centro SET TieneMovimientos = 1 WHERE Centro = @Centro
          END

          IF @Modulo = 'VTAS' AND @Mov = @CfgIngresoMov
          BEGIN
            IF @Accion = 'CANCELAR'
            BEGIN
              SELECT @EspacioDAnterior = NULL
              IF @AplicaMov = @CfgIngresoMov 
                 SELECT @EspacioDAnterior = MIN(d.Espacio) 
                   FROM VentaD d, Venta v 
                  WHERE v.Empresa = @Empresa AND v.Mov = @AplicaMov AND v.MovID = @AplicaMovID AND v.Estatus IN ('CONCLUIDO', 'PENDIENTE')
                    AND d.ID = v.ID AND d.Articulo = @Articulo AND d.SubCuenta = @SubCuenta AND d.Espacio IS NOT NULL
              UPDATE Cte SET Espacio = NULLIF(RTRIM(@EspacioDAnterior), '') WHERE Cliente = @ClienteProv
            END ELSE
              IF @EspacioD IS NULL 
                SELECT @Ok = 10210
              ELSE
                UPDATE Cte SET Espacio = @EspacioD WHERE Cliente = @ClienteProv
          END

          IF @MovTipo = 'INV.IF' AND @Accion = 'AFECTAR' AND @Estatus IN ('SINAFECTAR', 'CONFIRMAR', 'BORRADOR')
            EXEC spArtAlmABC @Articulo, @Almacen, @FechaEmision, @CfgDiasHabiles, @CfgABCDiasHabiles
            
          IF @Ok IS NULL
	    EXEC xpInvAfectarDetalle @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
      	         	             @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
		  		     @Renglon, @RenglonSub, @Articulo, @Cantidad, @Importe, @ImporteNeto, @Impuestos, @ImpuestosNetos, 
                                     @Ok OUTPUT, @OkRef OUTPUT

          SELECT @ImporteRetencion = 0.0, @ImporteRetencion2 = 0.0, @ImporteRetencion3 = 0.0
          IF @Modulo = 'VTAS' AND @Ok IS NULL
          BEGIN --MEJORA4648
--COMENTARIO_0008
            SELECT @ImporteRetencion  = (@ImporteNeto * (@MovRetencion1 / 100.0)),
                   @ImporteRetencion2 = (@ImporteNeto * (@MovRetencion2 / 100.0)),
                   @ImporteRetencion3 = (@ImporteNeto * (@MovRetencion3 / 100.0)) 
            IF @CfgRetencion2BaseImpuesto1 = 1 --VERIFICAR SI ESTO ES CORRECTO EN VENTAS
              SELECT @ImporteRetencion2 = (@Impuesto1Neto * (@MovRetencion2 / 100.0))                                          
            
          END
          IF @MovTipo IN ('COMS.F','COMS.FL','COMS.EG', 'COMS.EI', 'COMS.D') 
          BEGIN
            SELECT @ImporteRetencion  = (@ImporteNeto * (@MovRetencion1 / 100.0)),
                   @ImporteRetencion2 = (@ImporteNeto * (@MovRetencion2 / 100.0)),
                   @ImporteRetencion3 = (@ImporteNeto * (@MovRetencion3 / 100.0)) 
            IF @CfgRetencion2BaseImpuesto1 = 1 
              SELECT @ImporteRetencion2 = (@Impuesto1Neto * (@MovRetencion2 / 100.0))
          END
--COMENTARIO_0009

          -- Totalizadores van antes de leer el siguiente detalle
          SELECT @SumaPendiente       = @SumaPendiente 	     + ISNULL(@CantidadPendiente, 0.0), 
                 @SumaReservada	      = @SumaReservada	     + ISNULL(@CantidadReservada, 0.0),
                 @SumaOrdenada	      = @SumaOrdenada	     + ISNULL(@CantidadOrdenada, 0.0),
                 @SumaImporte         = @SumaImporte         + @Importe,
                 @SumaImporteNeto     = @SumaImporteNeto     + @ImporteNeto,
                 @ComisionImporteNeto = @ComisionImporteNeto + @ImporteNeto,
                 @SumaImpuestos       = @SumaImpuestos 	     + @Impuestos,
                 @SumaImpuestosNetos  = @SumaImpuestosNetos  + @ImpuestosNetos,
                 @SumaImpuesto1Neto   = @SumaImpuesto1Neto   + @Impuesto1Neto,
                 @SumaImpuesto2Neto   = @SumaImpuesto2Neto   + @Impuesto2Neto,
                 @SumaImpuesto3Neto   = @SumaImpuesto3Neto   + @Impuesto3Neto,
                 @SumaImpuesto5Neto   = @SumaImpuesto5Neto   + @Impuesto5Neto,
                 @SumaCostoLinea      = @SumaCostoLinea      + ROUND(@Costo * @Cantidad, @RedondeoMonetarios),
                 @SumaPrecioLinea     = @SumaPrecioLinea     + ROUND(@Precio * @Cantidad, @RedondeoMonetarios),
                 @SumaDescuentoLinea  = @SumaDescuentoLinea  + @DescuentoLineaImporte,
                 @SumaPeso	      = @SumaPeso            + (@Cantidad * @Peso * @Factor),
                 @SumaVolumen	      = @SumaVolumen         + (@Cantidad * @Volumen * @Factor),
                 @SumaComision	      = @SumaComision        + ISNULL(@ImporteComision, 0.0),
                 @ComisionAcum	      = @ComisionAcum        + ISNULL(@ImporteComision, 0.0)*@ComisionFactor,
                 @SumaRetencion	      = @SumaRetencion	     + ISNULL(@ImporteRetencion, 0.0),
                 @SumaRetencion2      = @SumaRetencion2	     + ISNULL(@ImporteRetencion2, 0.0),
                 @SumaRetencion3      = @SumaRetencion3	     + ISNULL(@ImporteRetencion3, 0.0)
        END -- fetch_status

        IF @Ok IS NOT NULL AND @OkRef IS NULL
        BEGIN
          SELECT @OkRef = 'Articulo: '+@Articulo
          IF @SubCuenta IS NOT NULL SELECT @OkRef = @OkRef+ ' ('+@SubCuenta+')'
        END

		IF @Ok IS NULL AND @SubCuentaExplotarInformacion = 1
		  EXEC spMovOpcion @Modulo, @ID, @Renglon, @RenglonSub, @Subcuenta, @Ok OUTPUT, @OkRef OUTPUT
         
        -- Siguiente Detalle
        IF @Ok IS NULL
        BEGIN

          IF @Modulo = 'VTAS' FETCH NEXT FROM crVentaDetalle  INTO @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @CantidadOriginal, @CantidadObsequio, @CantidadInventario, @CantidadReservada, @CantidadOrdenada, @CantidadPendiente, @CantidadA, @Factor, @MovUnidad, @Articulo, @Subcuenta, @Costo, @Precio, @DescuentoTipo, @DescuentoLinea, @Impuesto1, @Impuesto2, @Impuesto3, @AplicaMov, @AplicaMovID, @AlmacenRenglon, @AgenteRenglon, @ArtTipo, @ArtSerieLoteInfo, @ArtTipoOpcion, @Peso, @Volumen, @ArtUnidad, @MovRetencion1, @MovRetencion2, @MovRetencion3, @UltReservadoCantidad, @UltReservadoFecha, @ArtComision, @EspacioD, @ArtLotesFijos, @ArtActividades, @ArtCostoIdentificado, @ArtCostoUEPS, @ArtCostoPEPS, @ArtUltimoCosto, @ArtCostoEstandar, @ArtPrecioLista, @PrecioTipoCambio, @Posicion, @Tarima, @ArtDepartamentoDetallista, @ArtEstatus, @ArtSituacion, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @ContUso, @ContUso2, @ContUso3, @Retencion1, @Retencion2, @Retencion3, @AnticipoFacturado  ELSE --ANTICIPOFACTURADO
          IF @Modulo = 'COMS' FETCH NEXT FROM crCompraDetalle INTO @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @CantidadOriginal, @CantidadInventario, @CantidadReservada, @CantidadOrdenada, @CantidadPendiente, @CantidadA, @Factor, @MovUnidad, @Articulo, @Subcuenta, @Costo, @Precio, @DescuentoTipo, @DescuentoLinea, @Impuesto1, @Impuesto2, @Impuesto3, @Impuesto5, @AplicaMov, @AplicaMovID, @AlmacenRenglon, @ServicioArticulo, @ServicioSerie, @ArtTipo, @ArtSerieLoteInfo, @ArtTipoOpcion, @Peso, @Volumen, @ArtUnidad, @MovRetencion1, @MovRetencion2, @MovRetencion3, @ArtLotesFijos, @ArtActividades, @ArtCostoIdentificado, @ArtCostoUEPS, @ArtCostoPEPS, @ArtUltimoCosto, @ArtCostoEstandar, @ArtPrecioLista, @Posicion, @Tarima, @ArtDepartamentoDetallista, @ArtEstatus, @ArtSituacion, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoImpuesto5, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @ContUso, @ContUso2, @ContUso3, @ClavePresupuestal, @FechaCaducidad, @Retencion1, @Retencion2, @Retencion3 ELSE
          IF @Modulo = 'INV'  FETCH NEXT FROM crInvDetalle    INTO @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @CantidadOriginal, @CantidadInventario, @CantidadReservada, @CantidadOrdenada, @CantidadPendiente, @CantidadA, @Factor, @MovUnidad, @Articulo, @Subcuenta, @Costo, @Precio, @DescuentoTipo, @DescuentoLinea, @Impuesto1, @Impuesto2, @Impuesto3, @AplicaMov, @AplicaMovID, @AlmacenRenglon, @ProdSerieLote, @ArtTipo, @ArtSerieLoteInfo, @ArtTipoOpcion, @Peso, @Volumen, @ArtUnidad, @UltReservadoCantidad, @UltReservadoFecha, @DetalleTipo, @Producto, @SubProducto, @ArtLotesFijos, @ArtActividades, @ArtCostoIdentificado, @ArtCostoUEPS, @ArtCostoPEPS, @ArtUltimoCosto, @ArtCostoEstandar, @ArtPrecioLista, @Posicion, @Tarima, @ArtDepartamentoDetallista, @ArtEstatus, @ArtSituacion, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3, @Seccion, @FechaCaducidad ELSE
          IF @Modulo = 'PROD' FETCH NEXT FROM crProdDetalle   INTO @Renglon, @RenglonSub, @RenglonID, @RenglonTipo, @CantidadOriginal, @CantidadInventario, @CantidadReservada, @CantidadOrdenada, @CantidadPendiente, @CantidadA, @Factor, @MovUnidad, @Articulo, @Subcuenta, @Costo, @Precio, @DescuentoTipo, @DescuentoLinea, @Impuesto1, @Impuesto2, @Impuesto3, @AplicaMov, @AplicaMovID, @AlmacenRenglon, @ProdSerieLote, @ArtTipo, @ArtSerieLoteInfo, @ArtTipoOpcion, @Peso, @Volumen, @ArtUnidad, @UltReservadoCantidad, @UltReservadoFecha, @DetalleTipo, @Merma, @Desperdicio, @Ruta, @Orden, @Centro, @ArtLotesFijos, @ArtActividades, @ArtCostoIdentificado, @ArtCostoUEPS, @ArtCostoPEPS, @ArtUltimoCosto, @ArtCostoEstandar, @ArtPrecioLista, @Posicion, @Tarima, @ArtDepartamentoDetallista, @ArtEstatus, @ArtSituacion, @ArtExcento1, @ArtExcento2, @ArtExcento3, @TipoImpuesto1, @TipoImpuesto2, @TipoImpuesto3, @TipoRetencion1, @TipoRetencion2, @TipoRetencion3
          IF @@ERROR <> 0 SELECT @Ok = 1
          
        END
      END  -- While

--COMENTARIO_0010
      IF @Modulo = 'VTAS' BEGIN CLOSE crVentaDetalle  DEALLOCATE crVentaDetalle  END ELSE
      IF @Modulo = 'COMS' BEGIN CLOSE crCompraDetalle DEALLOCATE crCompraDetalle END ELSE
      IF @Modulo = 'INV'  BEGIN CLOSE crInvDetalle    DEALLOCATE crInvDetalle    END ELSE
      IF @Modulo = 'PROD' BEGIN CLOSE crProdDetalle   DEALLOCATE crProdDetalle   END 
    END -- AfectarDetalle
    
    IF @MovTipo = 'INV.T' AND @Ok IS NULL AND @CfgCostearTransferencias = 1
      EXEC spInvCostearTransferencias @Modulo, @ID, @MovTipo

--COMENTARIO_0011

    IF @Modulo = 'VTAS' AND @Ok IS NULL
      EXEC xpVentaRetencionTotalCalcular @ID, @Accion, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @ClienteProv, 
					 @SumaImpuesto1Neto, @SumaImpuesto2Neto, @SumaImpuesto3Neto,
                                         @SumaRetencion OUTPUT, @SumaRetencion2 OUTPUT, @Ok OUTPUT, @OkRef OUTPUT, @SumaRetencion3 = @SumaRetencion3 OUTPUT
--COMENTARIO_0012
    
    IF @PPTO = 1 AND @Accion <> 'CANCELAR' AND (@Modulo = 'COMS' OR (@Modulo = 'VTAS' AND @PPTOVentas = 1))
      EXEC spModuloAgregarMovPresupuesto @Modulo, @ID, @Ok OUTPUT, @OkRef OUTPUT

    IF @AfectarMatando = 1 AND @Utilizar = 0 AND @MatarAntes = 0 AND @Ok IS NULL 
      EXEC spInvMatar @Sucursal, @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
	 	      @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Ejercicio, @Periodo, @AfectarConsignacion, @AlmacenTipo, @AlmacenDestinoTipo, 
		      @CfgVentaSurtirDemas, @CfgCompraRecibirDemas, @CfgTransferirDemas, @CfgBackOrders, @CfgContX, @CfgContXGenerar, @CfgEmbarcar, @CfgImpInc, @CfgMultiUnidades, @CfgMultiUnidadesNivel,
                      @Ok OUTPUT, @OkRef OUTPUT, 
		      @CfgPrecioMoneda = @CfgPrecioMoneda

    -- 6777
    IF @Accion IN('AFECTAR', 'CANCELAR', 'RESERVARPARCIAL', 'RESERVAR') AND @OrigenMovTipo IN('VTAS.C', 'VTAS.CS', 'COMS.C')     
    BEGIN
      EXEC spMovFlujo @Sucursal, @Accion, @Empresa, @Modulo, @IDOrigen, @Origen, @OrigenID, @Modulo, @ID, @Mov, @MovID, @Ok OUTPUT
    END

    IF @Ok IS NULL
    BEGIN
      -- Calculos con Totalizadores
      SELECT @ImporteTotal = @SumaImporteNeto + @SumaImpuestosNetos 

      IF @Modulo = 'VTAS' 
      BEGIN
        --SELECT @ImporteTotal = ROUND(@ImporteTotal, @CfgVentaRedondeoDecimales)
        SELECT @SumaImporteNeto = @SumaImporteNeto - (@SumaImporteNeto + @SumaImpuestosNetos - @ImporteTotal)
      END

      IF @AnticiposFacturados > 0.0 
      BEGIN      
        SELECT @AnticipoImporte    = @SumaImporteNeto * @AnticiposFacturados / @ImporteTotal
        SELECT @AnticipoImpuestos  = @AnticiposFacturados - @AnticipoImporte
      END ELSE
        SELECT @AnticipoImporte = 0.0, @AnticipoImpuestos = 0.0

      SELECT @ImporteCx      = @SumaImporteNeto    - @AnticipoImporte,
             @ImpuestosCx    = @SumaImpuestosNetos - @AnticipoImpuestos,
	         @RetencionCx    = @SumaRetencion,
	         @Retencion2Cx   = @SumaRetencion2,
	         @Retencion3Cx   = @SumaRetencion3,
             @ImporteTotalCx = @ImporteTotal       - @AnticiposFacturados
      SELECT @SumaRetenciones = ISNULL(@SumaRetencion, 0.0) + ISNULL(@SumaRetencion2, 0.0) + ISNULL(@SumaRetencion3, 0.0)
      
      IF @ImporteTotal > 0
        SELECT @FactorMovImpto = @ImporteTotalCx / @ImporteTotal 
      ELSE
        SELECT @FactorMovImpto = 0

      IF @SubClave = 'COMS.CE/GT'
      BEGIN 
        DECLARE
          @GTImpuesto1Mov	varchar(20),
          @GTImpuesto1Acreedor	varchar(10)
        SELECT @GTImpuesto1Mov      = NULLIF(RTRIM(Impuesto1Mov), ''),
               @GTImpuesto1Acreedor = NULLIF(RTRIM(Impuesto1Acreedor), '')
         FROM EmpresaCfgGT
        WHERE Empresa = @Empresa
          
        IF @GTImpuesto1Mov IS NULL OR @GTImpuesto1Acreedor IS NULL
          SELECT @Ok = 20500, @OkRef = 'EmpresaCfgGT'
        EXEC spGenerarCx @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, NULL, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, 
                         @FechaEmision, @CfgRetencionConcepto, @Proyecto, @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones,
  	  	         @FechaRegistro, @Ejercicio, @Periodo,
		         NULL, NULL, @GTImpuesto1Acreedor, NULL, NULL, NULL, NULL, NULL,
                         @ImpuestosCx, NULL, NULL, NULL, 
                         NULL, NULL, NULL, NULL, NULL, @GTImpuesto1Mov,
		         @CxModulo OUTPUT, @CxMov OUTPUT, @CxMovID OUTPUT,
                         @Ok OUTPUT, @OkRef OUTPUT
        SELECT @ImporteCx = @ImporteCx - ISNULL(@RetencionCx, 0.0)
        SELECT @RetencionCx = NULL, @ImpuestosCx = NULL
      END

      IF @MovImpuesto = 1
      BEGIN
       --IF (SELECT dbo.fnEsPitex(Cliente) FROM Venta WHERE ID = @ID) = 1 --ANTICIPOFACTURADO
         --UPDATE #MovImpuesto SET Retencion1 = Impuesto1 --ANTICIPOFACTURADO    

        DELETE MovImpuesto WHERE Modulo = @Modulo AND ModuloID = @ID
        INSERT MovImpuesto (
               Modulo,  ModuloID,  OrigenModulo,                 OrigenModuloID,             OrigenConcepto,                   OrigenFecha,                              Retencion1, Retencion2, Retencion3, Impuesto1, Impuesto2, Impuesto3, Excento1, Excento2, Excento3, TipoImpuesto1, TipoImpuesto2, TipoImpuesto3, TipoRetencion1, TipoRetencion2, TipoRetencion3, LoteFijo, Importe1,                      Importe2,			             Importe3,			            SubTotal,                      ContUso, ContUso2, ContUso3, ClavePresupuestal, ClavePresupuestalImpuesto1, DescuentoGlobal, ImporteBruto)  --MEJORA1002
        SELECT @Modulo, @ID,       ISNULL(OrigenModulo,@Modulo), ISNULL(OrigenModuloID,@ID), ISNULL(OrigenConcepto,@Concepto), ISNULL(OrigenFecha,@FechaEmision),        Retencion1, Retencion2, Retencion3, Impuesto1, Impuesto2, Impuesto3, Excento1, Excento2, Excento3, TipoImpuesto1, TipoImpuesto2, TipoImpuesto3, TipoRetencion1, TipoRetencion2, TipoRetencion3, LoteFijo, SUM(Importe1*@FactorMovImpto), SUM(Importe2*@FactorMovImpto), SUM(Importe3*@FactorMovImpto), SUM(SubTotal*@FactorMovImpto), ContUso, ContUso2, ContUso3, ClavePresupuestal, ClavePresupuestalImpuesto1, DescuentoGlobal, SUM(ImporteBruto*@FactorMovImpto)  --MEJORA1002
          FROM #MovImpuesto
         GROUP BY Retencion1, Retencion2, Retencion3, Impuesto1, Impuesto2, Impuesto3, Excento1, Excento2, Excento3, TipoImpuesto1, TipoImpuesto2, TipoImpuesto3, TipoRetencion1, TipoRetencion2, TipoRetencion3, LoteFijo, ContUso, ContUso2, ContUso3, ClavePresupuestal, ClavePresupuestalImpuesto1, DescuentoGlobal, ISNULL(OrigenModulo,@Modulo), ISNULL(OrigenModuloID,@ID), ISNULL(OrigenConcepto,@Concepto), ISNULL(OrigenFecha,@FechaEmision) --MEJORA1002
         ORDER BY Retencion1, Retencion2, Retencion3, Impuesto1, Impuesto2, Impuesto3, Excento1, Excento2, Excento3, TipoImpuesto1, TipoImpuesto2, TipoImpuesto3, TipoRetencion1, TipoRetencion2, TipoRetencion3, LoteFijo, ContUso, ContUso2, ContUso3, ClavePresupuestal, ClavePresupuestalImpuesto1, DescuentoGlobal, ISNULL(OrigenModulo,@Modulo), ISNULL(OrigenModuloID,@ID), ISNULL(OrigenConcepto,@Concepto), ISNULL(OrigenFecha,@FechaEmision) --MEJORA1002
      END

      IF @Utilizar = 1 AND @ImporteTotal > 0.0 AND @UtilizarMovTipo IN ('VTAS.P','VTAS.R','VTAS.S','VTAS.VC','VTAS.VCR', 'COMS.O', 'COMS.OP', 'COMS.CC')
      BEGIN
	-- Restar al Saldo del Movimiento
	IF @Modulo = 'VTAS' UPDATE Venta  SET Saldo = Saldo - @ImporteTotal /*@ImporteCx*/      WHERE ID = @UtilizarID ELSE
	IF @Modulo = 'COMS' UPDATE Compra SET Saldo = Saldo - @ImporteTotal /*@SumaImporteNeto*/ WHERE ID = @UtilizarID 
        IF @@ERROR <> 0 SELECT @Ok = 1
      END

      -- Actualizar Importes Totales
      IF (@Estatus IN ('SINAFECTAR','CONFIRMAR','BORRADOR') AND @AfectarDetalle = 1) OR (@MovTipo IN ('COMS.D', 'COMS.B', 'COMS.CA', 'COMS.GX'))
      BEGIN
        SELECT @Paquetes = NULL
        IF @Modulo = 'VTAS' AND @MovTipo NOT IN ('VTAS.PR', 'VTAS.EST', 'VTAS.C', 'VTAS.CS', 'VTAS.P', 'VTAS.S', 'VTAS.SD') 
        BEGIN
          SELECT @Paquetes = ISNULL(COUNT(DISTINCT Paquete), 0) FROM VentaD WHERE ID = @ID 
          SELECT @Paquetes = @Paquetes + ISNULL(ROUND(SUM(Cantidad), 0), 0) FROM VentaD WHERE ID = @ID AND NULLIF(Paquete, 0) IS NULL
		  AND RenglonTipo <> CASE @EmbarqueSumaArtJuego WHEN 'Articulo Juego' THEN 'C' WHEN 'Componentes' THEN 'J'	ELSE 'J' END
        END ELSE
        IF @Modulo = 'INV'  AND @MovTipo NOT IN ('INV.SOL', 'INV.OT', 'INV.OT', 'INV.IF') 
        BEGIN
          SELECT @Paquetes = ISNULL(COUNT(DISTINCT Paquete) ,0) FROM InvD WHERE ID = @ID 
          SELECT @Paquetes = @Paquetes + ISNULL(ROUND(SUM(Cantidad), 0), 0) FROM InvD WHERE ID = @ID AND NULLIF(Paquete, 0) IS NULL
		  AND RenglonTipo <> CASE @EmbarqueSumaArtJuego WHEN 'Articulo Juego' THEN 'C' WHEN 'Componentes' THEN 'J'	ELSE 'J' END
        END ELSE
        IF @Modulo = 'COMS'  AND @MovTipo NOT IN ('COMS.R', 'COMS.C', 'COMS.O', 'COMS.OP', 'COMS.OG', 'COMS.OD', 'COMS.OI') 
        BEGIN
          SELECT @Paquetes = ISNULL(COUNT(DISTINCT Paquete) ,0) FROM InvD WHERE ID = @ID 
          SELECT @Paquetes = @Paquetes + ISNULL(ROUND(SUM(Cantidad), 0), 0) FROM CompraD WHERE ID = @ID AND NULLIF(Paquete, 0) IS NULL
		  AND RenglonTipo <> CASE @EmbarqueSumaArtJuego WHEN 'Articulo Juego' THEN 'C' WHEN 'Componentes' THEN 'J'	ELSE 'J' END
        END
        SELECT @IVAFiscal = CONVERT(float, @SumaImpuesto1Neto) / NULLIF(@ImporteTotal-@SumaRetenciones, 0),
               @IEPSFiscal = CONVERT(float, @SumaImpuesto2Neto) / NULLIF(@ImporteTotal-@SumaRetenciones, 0)

        IF @Modulo = 'VTAS' UPDATE Venta  SET Peso = @SumaPeso, Volumen = @SumaVolumen, Paquetes = @Paquetes, Importe = @SumaImporte, Impuestos = @SumaImpuestosNetos, IVAFiscal = @IVAFiscal, IEPSFiscal = @IEPSFiscal, Saldo = CASE WHEN @EstatusNuevo IN ('PENDIENTE', 'PROCESAR') THEN @ImporteTotal /*@ImporteCx*/ ELSE NULL END, DescuentoLineal = @SumaDescuentoLinea, ComisionTotal = @SumaComision, PrecioTotal = @SumaPrecioLinea, CostoTotal = @SumaCostoLinea, Retencion = NULLIF(@SumaRetenciones, 0.0) WHERE ID = @ID ELSE
        --BUG9637
        IF @Modulo = 'COMS' UPDATE Compra SET Peso = @SumaPeso, Volumen = @SumaVolumen, Paquetes = @Paquetes, Importe = @SumaImporte, Impuestos = @SumaImpuestosNetos, IVAFiscal = @IVAFiscal, IEPSFiscal = @IEPSFiscal, Saldo = CASE WHEN @EstatusNuevo IN ('PENDIENTE', 'PROCESAR') THEN @ImporteTotal /*@SumaImporteNeto*/ ELSE NULL END, DescuentoLineal = @SumaDescuentoLinea, Retencion = NULLIF(@SumaRetenciones, 0.0) WHERE ID = @ID ELSE
        IF @Modulo = 'INV'  UPDATE Inv    SET Peso = @SumaPeso, Volumen = @SumaVolumen, Paquetes = @Paquetes, Importe = @SumaCostoLinea WHERE ID = @ID ELSE
        IF @Modulo = 'PROD' UPDATE Prod   SET Peso = @SumaPeso, Volumen = @SumaVolumen, Paquetes = @Paquetes, Importe = @SumaCostoLinea WHERE ID = @ID 
        IF @@ERROR <> 0 SELECT @Ok = 1
      END ELSE
        EXEC spInvReCalcEncabezado @ID, @Modulo, @CfgImpInc, @CfgMultiUnidades, @DescuentoGlobal, @SobrePrecio,
				   @CfgPrecioMoneda = @CfgPrecioMoneda

      /*IF @MovTipo = 'COMS.R' AND @Accion = 'AFECTAR' UPDATE Compra SET Proveedor = NULL WHERE ID = @ID*/

      IF @MovTipo = 'INV.IF' AND @EstatusNuevo = 'CONCLUIDO' 
        -- Generar Ajuste del Inventario Fisico
        EXEC spInvInventarioFisico @Sucursal, @ID, @Empresa, @Almacen, @IDGenerar, @Base, @CfgSeriesLotesMayoreo, @Estatus, @Ok OUTPUT, @OkRef OUTPUT

      -- En servicios cotizados, pegarle a la cotizacion
      IF @MovTipo = 'VTAS.S' AND @Estatus = 'CONFIRMAR' AND @EstatusNuevo IN ('PENDIENTE', 'CANCELADO')
      BEGIN
        SELECT @CotizacionID = ID FROM Venta WHERE Empresa = @Empresa AND OrigenTipo = 'VTAS' AND Origen = @Mov AND OrigenID = @MovID AND Estatus NOT IN ('SINAFECTAR', 'CANCELADO')
        SELECT @CotizacionEstatusNuevo = CASE WHEN @Accion = 'CANCELAR' THEN 'CANCELADO' ELSE 'CONCLUIDO' END
        EXEC spValidarTareas @Empresa, @Modulo, @CotizacionID, @CotizacionEstatusNuevo, @Ok OUTPUT, @OkRef OUTPUT
        UPDATE Venta SET Estatus = @CotizacionEstatusNuevo WHERE ID = @CotizacionID
      END
      IF @@ERROR <> 0 SELECT @Ok = 1

      IF @Estatus IN ('SINAFECTAR','AUTORIZARE','CONFIRMAR','BORRADOR') OR @Accion = 'CANCELAR'
      BEGIN
        -- Calcular Fecha Vencimiento
        IF @Accion <> 'CANCELAR' 
        BEGIN
          IF @MovTipo = 'VTAS.FR' 
            SELECT @Vencimiento = ISNULL(CASE WHEN ConVigencia = 1 THEN VigenciaDesde END, @FechaEmision) FROM Venta WHERE ID = @ID
          ELSE
            EXEC spCalcularVencimiento @Modulo, @Empresa, @ClienteProv, @Condicion, @FechaEmision, @Vencimiento OUTPUT, @Dias OUTPUT, @Ok OUTPUT 

          EXEC spExtraerFecha @Vencimiento OUTPUT
        END

        IF @MovTipo IN ('VTAS.P', 'VTAS.S', 'COMS.O') AND NULLIF(RTRIM(@Condicion), '') IS NOT NULL AND @EstatusNuevo <> 'CONFIRMAR' 
          IF (SELECT UPPER(ControlAnticipos) FROM Condicion WHERE Condicion = @Condicion) IN ('ABIERTO', 'PLAZOS', 'FECHA REQUERIDA')
            EXEC spGenerarAP @Sucursal, @Accion, @Empresa, @Modulo, @ID, @MovTipo, @FechaRegistro,
            		     @Mov, @MovID, @MovMoneda, @MovTipoCambio, @Proyecto, @ClienteProv, @Referencia, @Condicion, @Vencimiento, @ImporteTotal,
  	 	             @Ok OUTPUT, @OkRef OUTPUT

        IF @MovTipo = 'VTAS.NO'
        BEGIN
          SELECT @EsCargo = 1
          IF @Accion = 'CANCELAR' SELECT @EsCargo = ~@EsCargo
          EXEC spSaldo @Sucursal, @Accion, @Empresa, @Usuario, 'CNO', @MovMoneda, @MovTipoCambio, @ClienteProv, NULL, NULL, NULL,
                       @Modulo, @ID, @Mov, @MovID, @EsCargo, @ImporteTotal, NULL, NULL,
                       @FechaAfectacion, @Ejercicio, @Periodo, 'Consumos', NULL, 0, 0, 0,
 	  	       @Ok OUTPUT, @OkRef OUTPUT, @Renglon = @Renglon, @RenglonSub = @RenglonSub, @RenglonID = @RenglonID
        END
      END

      IF (@Generar = 1 AND @GenerarAfectado = 1) OR (@Accion = 'CANCELAR' AND @Base <> 'TODO')
      BEGIN  
        IF @Modulo = 'VTAS' SELECT @SumaPendiente = Sum(ROUND(ISNULL(CantidadPendiente, 0.0), 4)), @SumaReservada = Sum(ROUND(ISNULL(CantidadReservada, 0.0), 2)), @SumaOrdenada = Sum(ROUND(ISNULL(CantidadOrdenada, 0.0), 2)) FROM VentaD WHERE ID = @ID ELSE
        IF @Modulo = 'COMS' SELECT @SumaPendiente = Sum(ROUND(ISNULL(CantidadPendiente, 0.0), 4)) FROM CompraD WHERE ID = @ID ELSE
        IF @Modulo = 'INV'  SELECT @SumaPendiente = Sum(ROUND(ISNULL(CantidadPendiente, 0.0), 4)), @SumaReservada = Sum(ROUND(ISNULL(CantidadReservada, 0.0), 2)), @SumaOrdenada = Sum(ROUND(ISNULL(CantidadOrdenada, 0.0), 2)) FROM InvD   WHERE ID = @ID ELSE
        IF @Modulo = 'PROD' SELECT @SumaPendiente = Sum(ROUND(ISNULL(CantidadPendiente, 0.0), 4)), @SumaReservada = Sum(ROUND(ISNULL(CantidadReservada, 0.0), 2)), @SumaOrdenada = Sum(ROUND(ISNULL(CantidadOrdenada, 0.0), 2)) FROM ProdD  WHERE ID = @ID
      END

      -- Actualizar el Estatus
      IF @MovTipo NOT IN ('INV.IF', 'PROD.A', 'PROD.R', 'PROD.E')
      BEGIN
        SELECT @TienePendientes = 0
        IF @Modulo = 'VTAS' AND EXISTS(SELECT * FROM VentaD  WHERE ID = @ID AND ((ISNULL(CantidadPendiente, 0.0) <> 0.0) OR (ISNULL(CantidadReservada, 0.0) <> 0.0) OR (ISNULL(CantidadOrdenada, 0.0) <> 0.0))) SELECT @TienePendientes = 1 ELSE
        IF @Modulo = 'INV'  AND EXISTS(SELECT * FROM InvD    WHERE ID = @ID AND ((ISNULL(CantidadPendiente, 0.0) <> 0.0) OR (ISNULL(CantidadReservada, 0.0) <> 0.0) OR (ISNULL(CantidadOrdenada, 0.0) <> 0.0))) SELECT @TienePendientes = 1 ELSE
        IF @Modulo = 'PROD' AND EXISTS(SELECT * FROM ProdD   WHERE ID = @ID AND ((ISNULL(CantidadPendiente, 0.0) <> 0.0) OR (ISNULL(CantidadReservada, 0.0) <> 0.0) OR (ISNULL(CantidadOrdenada, 0.0) <> 0.0))) SELECT @TienePendientes = 1 ELSE
        IF @Modulo = 'COMS' AND EXISTS(SELECT * FROM CompraD WHERE ID = @ID AND ISNULL(CantidadPendiente, 0.0) <> 0.0) SELECT @TienePendientes = 1 

        IF @EstatusNuevo <> 'PENDIENTE' AND @TienePendientes = 1 SELECT @EstatusNuevo = 'PENDIENTE'
        IF @EstatusNuevo = 'PENDIENTE'  AND @TienePendientes = 0 SELECT @EstatusNuevo = 'CONCLUIDO'
        --- Bug 25409: Se agrega la l�nea siguiente.
        IF @EstatusNuevo = 'PENDIENTE'  AND @OrigenTipo = 'POS' AND @MovTipo = 'VTAS.C' SELECT @EstatusNuevo = 'CONFIRMAR'
      END
      IF @EstatusNuevo = 'CONCLUIDO' SELECT @FechaConclusion = @FechaEmision ELSE IF @EstatusNuevo <> 'CANCELADO' SELECT @FechaConclusion = NULL
      IF @EstatusNuevo = 'CANCELADO' SELECT @FechaCancelacion = @FechaRegistro ELSE SELECT @FechaCancelacion = NULL

      IF @CfgContX = 1 AND @CfgContXGenerar <> 'NO'
      BEGIN
        IF @Estatus NOT IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR') AND @EstatusNuevo = 'CANCELADO' 
        BEGIN
           IF @GenerarPoliza = 1 SELECT @GenerarPoliza = 0 ELSE SELECT @GenerarPoliza = 1
           IF @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX') AND @Estatus = 'PENDIENTE' AND @CfgContXFacturasPendientes = 0
             SELECT @GenerarPoliza = 0
        END ELSE BEGIN           
          IF @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FC', 'VTAS.FG', 'VTAS.FX') AND @CfgContXFacturasPendientes = 0
          BEGIN 
            IF @EstatusNuevo = 'CONCLUIDO' SELECT @GenerarPoliza = 1 
          END ELSE
  	    IF @Estatus IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR') AND @EstatusNuevo <> 'CANCELADO' SELECT @GenerarPoliza = 1 
        END
      END  

      EXEC spValidarTareas @Empresa, @Modulo, @ID, @EstatusNuevo, @Ok OUTPUT, @OkRef OUTPUT
      IF @Modulo = 'VTAS' UPDATE Venta  SET Vencimiento = @Vencimiento,  Concepto = @Concepto, FechaConclusion = @FechaConclusion, FechaCancelacion = @FechaCancelacion, UltimoCambio = /*CASE WHEN UltimoCambio IS NULL THEN */@FechaRegistro /*ELSE UltimoCambio END*/, Estatus = @EstatusNuevo, Saldo = CASE WHEN @EstatusNuevo IN ('CONCLUIDO', 'CANCELADO') THEN NULL ELSE Saldo END, Situacion = CASE WHEN @Estatus<>@EstatusNuevo THEN NULL ELSE Situacion END, GenerarPoliza = @GenerarPoliza, Autorizacion = @Autorizacion, Mensaje = NULL WHERE ID = @ID ELSE
      IF @Modulo = 'COMS' UPDATE Compra SET Vencimiento = @Vencimiento,  Concepto = @Concepto, FechaConclusion = @FechaConclusion, FechaCancelacion = @FechaCancelacion, UltimoCambio = /*CASE WHEN UltimoCambio IS NULL THEN */@FechaRegistro /*ELSE UltimoCambio END*/, Estatus = @EstatusNuevo, Saldo = CASE WHEN @EstatusNuevo IN ('CONCLUIDO', 'CANCELADO') THEN NULL ELSE Saldo END, Situacion = CASE WHEN @Estatus<>@EstatusNuevo THEN NULL ELSE Situacion END, GenerarPoliza = @GenerarPoliza, Autorizacion = @Autorizacion, Mensaje = NULL  WHERE ID = @ID ELSE
      IF @Modulo = 'INV'  UPDATE Inv    SET Vencimiento = @Vencimiento,  Concepto = @Concepto, FechaConclusion = @FechaConclusion, FechaCancelacion = @FechaCancelacion, UltimoCambio = /*CASE WHEN UltimoCambio IS NULL THEN */@FechaRegistro /*ELSE UltimoCambio END*/, Estatus = @EstatusNuevo, Situacion = CASE WHEN @Estatus<>@EstatusNuevo THEN NULL ELSE Situacion END, GenerarPoliza = @GenerarPoliza, Autorizacion = @Autorizacion WHERE ID = @ID ELSE
      IF @Modulo = 'PROD' UPDATE Prod   SET/*Vencimiento=@Vencimiento,*/ Concepto = @Concepto, FechaConclusion = @FechaConclusion, FechaCancelacion = @FechaCancelacion, UltimoCambio = /*CASE WHEN UltimoCambio IS NULL THEN */@FechaRegistro /*ELSE UltimoCambio END*/, Estatus = @EstatusNuevo, Situacion = CASE WHEN @Estatus<>@EstatusNuevo THEN NULL ELSE Situacion END, GenerarPoliza = @GenerarPoliza, Autorizacion = @Autorizacion WHERE ID = @ID
      IF @@ERROR <> 0 SELECT @Ok = 1

      EXEC spEmbarqueMov @Accion, @Empresa, @Modulo, @ID, @Mov, @MovID, @Estatus, @EstatusNuevo, @CfgEmbarcar, @Ok OUTPUT

      IF @Accion = 'CANCELAR' 
      BEGIN
        IF @EstatusNuevo = 'PENDIENTE'
        BEGIN
          --BUG15329
          IF @Base <> 'SELECCION'        
	        IF @Modulo = 'VTAS' UPDATE Venta  SET Saldo = Saldo - @ImporteTotal /*@ImporteCx*/      WHERE ID = @ID ELSE
	        IF @Modulo = 'COMS' UPDATE Compra SET Saldo = Saldo - @ImporteTotal /*@SumaImporteNeto*/ WHERE ID = @ID 
        END ELSE
        BEGIN
    	  IF @Modulo = 'VTAS' UPDATE Venta  SET Saldo = NULL WHERE ID = @ID ELSE
  	      IF @Modulo = 'COMS' UPDATE Compra SET Saldo = NULL WHERE ID = @ID 
        END
        IF @@ERROR <> 0 SELECT @Ok = 1
      END

      -- Si fue una Venta/Dev a Consignacion Guardar en Almacen Consignacion del Cliente en el Movimiento
      IF @MovTipo IN ('VTAS.VC','VTAS.VCR','VTAS.DC','VTAS.DCR') AND @Accion <> 'CANCELAR'
      BEGIN
	UPDATE Venta SET AlmacenDestino = CASE WHEN @MovTipo IN ('VTAS.VC','VTAS.VCR') THEN @GenerarAlmacenDestino ELSE @GenerarAlmacen END WHERE ID = @ID 
        IF @@ERROR <> 0 SELECT @Ok = 1
      END

      IF @Utilizar = 1 AND @Ok IS NULL
        EXEC spInvAfectarUtilizarConcluido @Empresa, @Modulo, @FechaEmision, @UtilizarID, @AfectarMatando, @UtilizarEstatus, @SumaPendiente, @FechaConclusion, @Ok OUTPUT, @OkRef OUTPUT 

      IF @Generar = 1 AND @Ok IS NULL
      BEGIN
        IF @GenerarAfectado = 1 SELECT @GenerarEstatus = 'CONCLUIDO' ELSE SELECT @GenerarEstatus = 'SINAFECTAR'
        IF @GenerarEstatus = 'CONCLUIDO' SELECT @FechaConclusion = @FechaEmision ELSE IF @GenerarEstatus <> 'CANCELADO' SELECT @FechaConclusion = NULL
        IF @UtilizarEstatus = 'CONCLUIDO' AND @CfgContX = 1 AND @CfgContXGenerar <> 'NO' SELECT @GenerarPolizaTemp = 1 ELSE SELECT @GenerarPolizaTemp = 0

        EXEC spValidarTareas @Empresa, @Modulo, @IDGenerar, @GenerarEstatus, @Ok OUTPUT, @OkRef OUTPUT
        IF @Modulo = 'VTAS' UPDATE Venta  SET FechaConclusion = @FechaConclusion, Estatus = @GenerarEstatus, GenerarPoliza = @GenerarPolizaTemp WHERE ID = @IDGenerar ELSE
        IF @Modulo = 'COMS' UPDATE Compra SET FechaConclusion = @FechaConclusion, Estatus = @GenerarEstatus, GenerarPoliza = @GenerarPolizaTemp WHERE ID = @IDGenerar ELSE
        IF @Modulo = 'INV'  UPDATE Inv    SET FechaConclusion = @FechaConclusion, Estatus = @GenerarEstatus, GenerarPoliza = @GenerarPolizaTemp WHERE ID = @IDGenerar ELSE
        IF @Modulo = 'PROD' UPDATE Prod   SET FechaConclusion = @FechaConclusion, Estatus = @GenerarEstatus, GenerarPoliza = @GenerarPolizaTemp WHERE ID = @IDGenerar
        IF @@ERROR <> 0 SELECT @Ok = 1

        EXEC xpInvGenerarFinal @Empresa, @Usuario, @Accion, @Modulo, @ID, @IDGenerar, @GenerarEstatus, @Ok OUTPUT, @OkRef OUTPUT
      END

      IF @MovTipo = 'VTAS.S' AND NULLIF(RTRIM(@ServicioSerie), '') IS NOT NULL
      BEGIN
        EXEC spSerieLoteFlujo @Sucursal, @SucursalAlmacen, @SucursalAlmacenDestino, @Accion, @Empresa, @Modulo, @ID, @ServicioArticulo, NULL, @ServicioSerie, @Almacen, 0
        --UPDATE VIN SET FechaUltimoServicio = @FechaEmision WHERE VIN = @ServicioSerie
      END

      -- Afectar en Otros Modulos
      SELECT @Continuar = 1, @CxID = NULL, @CxMovTipo = NULL
      IF (@FacturarVtasMostrador = 1 AND @Accion <> 'CANCELAR') OR (@Accion ='CANCELAR' AND @MovTipo IN ('VTAS.F','VTAS.FAR','VTAS.FB') AND @OrigenTipo = 'VMOS')
      BEGIN
        SELECT @Continuar = 0
        EXEC spInvReCalcEncabezado @ID, @Modulo, @CfgImpInc, @CfgMultiUnidades, @DescuentoGlobal, @SobrePrecio,
				   @CfgPrecioMoneda = @CfgPrecioMoneda
        IF @MovTipo IN ('VTAS.F','VTAS.FAR','VTAS.FB', 'VTAS.D')  -- CFD 3.3 Incluir la Clave VTAS.D
        BEGIN
          EXEC spInvMatarNotas @Sucursal, @ID, @Accion, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @FechaAfectacion, @Ejercicio, @Periodo, @Ok OUTPUT, @OkRef OUTPUT, @AfectandoNotasSinCobro OUTPUT
          SELECT @Continuar = @AfectandoNotasSinCobro
        END
      END

      -- ETO Tarjetas 9-Feb-2007 Recarga Tarjetas
      IF @MovTipo = 'VTAS.FB' AND @Accion in ('AFECTAR', 'CANCELAR')
      BEGIN
        EXEC spMovTipoInstruccionBit @Modulo, @Mov, 'IncrementaSaldoTarjeta', @IncrementaSaldoTarjeta OUTPUT, @Ok OUTPUT, @OkRef OUTPUT
        IF @IncrementaSaldoTarjeta = 1
          EXEC spIncrementaSaldoTarjeta @Empresa, @ID, @Mov, @MovID, @Modulo, @Ejercicio, @Periodo, @Accion, @FechaEmision, @MovMoneda, @MovTipoCambio, @Ok OUTPUT, @OkRef OUTPUT
      END

      IF @Continuar = 1 AND (@Estatus IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR') OR @EstatusNuevo = 'CANCELADO') AND @Ok IS NULL
      BEGIN
	-- Bonificacion Automatica
        IF @Accion = 'CANCELAR'
        BEGIN
          IF @CfgCompraAutoCargos = 1 AND @MovTipo IN ('COMS.F', 'COMS.FL', 'COMS.EG', 'COMS.EI', 'COMS.D', 'COMS.B') AND @Ok IS NULL
	    EXEC xpCompraAutoCargos @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, @Modulo, @Empresa, @ID, @Mov,
			            @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @FechaEmision , @Concepto, @Proyecto,
				    @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones, @FechaRegistro, @Ejercicio, @Periodo,
				    @Condicion, @Vencimiento, @ClienteProv, @SumaImporteNeto, @SumaImpuestosNetos, @VIN, @Ok OUTPUT, @OkRef OUTPUT
          IF @CfgVentaAutoBonif = 1 AND @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.D', 'VTAS.DF', 'VTAS.B') AND @Ok IS NULL
	    EXEC xpVentaAutoBonif @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, @Modulo, @Empresa, @ID, @Mov,
			          @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @FechaEmision , @Concepto, @Proyecto,
				  @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones, @FechaRegistro, @Ejercicio, @Periodo,
				  @Condicion, @Vencimiento, @ClienteProv, @CobroIntegrado, @SumaImporteNeto, @SumaImpuestosNetos, @VIN, @Ok OUTPUT, @OkRef OUTPUT, @Agente -- BUG 16650

          IF @MovTipo IN ('VTAS.F','VTAS.FAR') AND (SELECT CxcAutoAplicarAnticiposPedidos FROM EmpresaCfg2 WHERE Empresa = @Empresa) = 1
          BEGIN
            SELECT @ReferenciaAplicacionAnticipo = RTRIM(@Origen) + ' ' + RTRIM(@OrigenID)
	    EXEC xpVentaAutoAplicarAnticiposPedidos @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, @Modulo, @Empresa, @ID, @Mov,
   			          		    @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @FechaEmision , @Concepto, @Proyecto,
				  		    @Usuario, @Autorizacion, @ReferenciaAplicacionAnticipo, @DocFuente, @Observaciones, @FechaRegistro, @Ejercicio, @Periodo,
				  		    @Condicion, @Vencimiento, @ClienteProv, @CobroIntegrado, @SumaImporteNeto, @SumaImpuestosNetos, @VIN, @Ok OUTPUT, @OkRef OUTPUT
          END
        END

        IF @Modulo = 'VTAS' AND @CobroIntegrado = 0 
          EXEC spBorrarVentaCobro @ID
      
        IF @CobroIntegrado = 1 
        BEGIN
          SELECT @DineroImporte = 0.0, @CobroDesglosado = 0.0, @CobroDelEfectivo = 0.0, @CobroCambio = 0.0, @ValesCobrados = 0.0, @CobroRedondeo = 0.0, @TarjetasCobradas = 0.0 	-- ETO Tarjetas 9-Feb-2007
          SELECT @Importe1 = ISNULL(Importe1, 0.0), @Importe2 = ISNULL(Importe2, 0.0), @Importe3 = ISNULL(Importe3, 0.0), @Importe4 = ISNULL(Importe4, 0.0), @Importe5 = ISNULL(Importe5, 0.0),
         	 @FormaCobro1 = RTRIM(FormaCobro1), @FormaCobro2 = RTRIM(FormaCobro2), @FormaCobro3 = RTRIM(FormaCobro3), @FormaCobro4 = RTRIM(FormaCobro4), @FormaCobro5 = RTRIM(FormaCobro5), 
                 @Referencia1 = RTRIM(Referencia1), @Referencia2 = RTRIM(Referencia2), @Referencia3 = RTRIM(Referencia3), @Referencia4 = RTRIM(Referencia4), @Referencia5 = RTRIM(Referencia5), 
                 @CobroDelEfectivo = ISNULL(DelEfectivo, 0.0), @CtaDinero = NULLIF(RTRIM(CtaDinero), ''), @Cajero = NULLIF(RTRIM(Cajero), ''),
                 @CobroRedondeo = ISNULL(Redondeo, 0.0), @FormaCobroCambio = RTRIM(FormaCobroCambio) --MEJORA5512
            FROM VentaCobro
           WHERE ID = @ID

          EXEC spVentaCobroTotal @FormaCobro1, @FormaCobro2, @FormaCobro3, @FormaCobro4, @FormaCobro5,
    	  	                 @Importe1, @Importe2, @Importe3, @Importe4, @Importe5, @CobroDesglosado OUTPUT, @Moneda = @MovMoneda, @TipoCambio = @MovTipoCambio
          SELECT @FormaCobroVales = CxcFormaCobroVales, @FormaCobroTarjetas = CxcFormaCobroTarjetas FROM EmpresaCfg WHERE Empresa = @Empresa
          IF @FormaCobro1 = @FormaCobroVales SELECT @ValesCobrados = @ValesCobrados + @Importe1
          IF @FormaCobro2 = @FormaCobroVales SELECT @ValesCobrados = @ValesCobrados + @Importe2
          IF @FormaCobro3 = @FormaCobroVales SELECT @ValesCobrados = @ValesCobrados + @Importe3
          IF @FormaCobro4 = @FormaCobroVales SELECT @ValesCobrados = @ValesCobrados + @Importe4
          IF @FormaCobro5 = @FormaCobroVales SELECT @ValesCobrados = @ValesCobrados + @Importe5
          -- ETO Tarjetas 9-Feb-2007
          --BUG15665
          IF @FormaCobro1 = @FormaCobroTarjetas SELECT @TarjetasCobradas = @TarjetasCobradas + @Importe1, @ReferenciaTarjetas = @Referencia1
          IF @FormaCobro2 = @FormaCobroTarjetas SELECT @TarjetasCobradas = @TarjetasCobradas + @Importe2, @ReferenciaTarjetas = @Referencia2
          IF @FormaCobro3 = @FormaCobroTarjetas SELECT @TarjetasCobradas = @TarjetasCobradas + @Importe3, @ReferenciaTarjetas = @Referencia3
          IF @FormaCobro4 = @FormaCobroTarjetas SELECT @TarjetasCobradas = @TarjetasCobradas + @Importe4, @ReferenciaTarjetas = @Referencia4
          IF @FormaCobro5 = @FormaCobroTarjetas SELECT @TarjetasCobradas = @TarjetasCobradas + @Importe5, @ReferenciaTarjetas = @Referencia5

          IF @CobroDesglosado + @CobroDelEfectivo <> 0.0
          BEGIN     
            SELECT @CobroCambio = @CobroDesglosado + @CobroDelEfectivo - (@ImporteTotalCx - @SumaRetenciones) - @CobroRedondeo
            
            IF (@CobroDesglosado + @CobroDelEfectivo) <  ((@ImporteTotalCx-@SumaRetenciones) + @CobroRedondeo) SELECT @CobroCambio = 0.0            
            
            IF ROUND(ABS(@CobroCambio), @RedondeoMonetarios) = 0.01 SELECT @CobroCambio = 0.0
            IF @Accion <> 'CANCELAR'
              UPDATE VentaCobro SET Actualizado = 1, Cambio = @CobroCambio WHERE ID = @ID

            SELECT @DineroImporte = @CobroDesglosado - @CobroCambio
          END 
        END

        IF @CobroIntegrado = 1 AND @CobroIntegradoCxc = 0 AND @CobroIntegradoParcial = 0 AND @OrigenTipo <> 'CR' AND @ImporteTotalCx <> 0.0 AND (@Estatus IN ('SINAFECTAR', 'CONFIRMAR', 'BORRADOR') OR @EstatusNuevo = 'CANCELADO') AND @Ok IS NULL
        BEGIN
          IF @ValesCobrados > 0.0 OR @TarjetasCobradas <> 0 -- 	-- ETO Tarjetas 9-Feb-2007 se agreg� @TarjetasCobradas
            EXEC spValeAplicarCobro @Empresa, @Modulo, @ID, @TarjetasCobradas, @Accion, @FechaEmision, @Ok OUTPUT, @OkRef OUTPUT

	-- ETO Tarjetas 9-Feb-2007 
          IF @OK is null AND @TarjetasCobradas <> 0
            EXEC spValeGeneraAplicacionTarjeta @Empresa, @Modulo, @ID, @Mov, @MovID, @Accion, @FechaEmision, @Usuario, @Sucursal, 
						@TarjetasCobradas, @CtaDinero, @MovMoneda, @MovTipoCambio, @Ok OUTPUT, @OkRef OUTPUT, @Referencia = @ReferenciaTarjetas --BUG15665
	-- ETO Tarjetas 9-Feb-2007 Puntos por Categor�a de Art�culos
          IF @OK is null AND @Modulo = 'VTAS' AND @CfgVentaMonedero = 1 AND Exists(SELECT * FROM TarjetaSeriemov WHERE Empresa = @Empresa AND Modulo = @Modulo AND ID = @ID)
            EXEC spVentaMonedero @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @Accion, @FechaEmision, 
				 @Ejercicio, @Periodo, @Usuario, @Sucursal, @MovMoneda, @MovTipoCambio, 
				 @Ok OUTPUT, @OkRef OUTPUT


          EXEC spInvAfectarDinero @ID, @Accion, @Base, @Empresa, @Modulo, @Mov, @MovID OUTPUT, @MovTipo, @MovMoneda, @MovTipoCambio, @FechaEmision, @FechaAfectacion, @FechaConclusion,
                                  @Concepto, @Proyecto, @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones, @Estatus, @EstatusNuevo, @FechaRegistro, @Ejercicio, @Periodo,
                                  @ClienteProv, @EnviarA, @SucursalOrigen, @Ok OUTPUT, @OkRef OUTPUT,	   
                                  @EsCargo OUTPUT, @CtaDinero OUTPUT, @Cajero OUTPUT, @DineroMov OUTPUT, @DineroMovID OUTPUT,
                                  @FormaPagoCambio OUTPUT, @CobroCambio OUTPUT, @DineroImporte OUTPUT, @CobroDelEfectivo OUTPUT, @CobroSumaEfectivo OUTPUT,
                                  @Importe1 OUTPUT, @Importe2 OUTPUT, @Importe3 OUTPUT, @Importe4 OUTPUT, @Importe5 OUTPUT, @ImporteCambio OUTPUT,
                                  @FormaCobro1 OUTPUT, @FormaCobro2 OUTPUT, @FormaCobro3 OUTPUT, @FormaCobro4 OUTPUT, @FormaCobro5 OUTPUT,
                                  @Referencia1 OUTPUT, @Referencia2 OUTPUT, @Referencia3 OUTPUT, @Referencia4 OUTPUT, @Referencia5 OUTPUT, 
                                  @FormaMoneda OUTPUT, @FormaTipoCambio OUTPUT, @FormaCobroVales OUTPUT, @FormaCobroCambio OUTPUT --MEJORA5512
        END ELSE
        IF @ImporteTotalCx > 0.0 AND @Ok IS NULL AND @OrigenTipo <> 'CR' AND 
           ((@MovTipo IN ('VTAS.FM', 'VTAS.N', 'VTAS.NO', 'VTAS.NR') AND @CobroIntegradoCxc = 1) OR
           (((@MovTipo IN ('VTAS.F','VTAS.FX','VTAS.FAR', 'VTAS.FB','VTAS.D','VTAS.DF')) OR (@SubClave = 'VTAS.FA')) AND @CobrarPedido = 0 AND (@Estatus IN ('SINAFECTAR', 'CONFIRMAR', 'BORRADOR') OR @EstatusNuevo = 'CANCELADO')) OR 
           (@MovTipo IN ('VTAS.B', 'COMS.F','COMS.FL','COMS.EG', 'COMS.EI','COMS.D','COMS.B','COMS.CA', 'COMS.GX') AND @EstatusNuevo IN ('CONCLUIDO','PROCESAR','CANCELADO')) )
        BEGIN
          -- Retenciones de la Compra
          IF /*@CfgRetencionAlPago = 0 OR*/ @BorrarRetencionCx = 1 SELECT @RetencionCx = 0.0, @Retencion2Cx = 0.0, @Retencion3Cx = 0.0

          IF @MovTipo = 'COMS.EI'
            EXEC spGenerarCxImportacion @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, NULL, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, 
         	                        @FechaAfectacion, @Concepto, @Proyecto, @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones,
   		   		        @FechaRegistro, @Ejercicio, @Periodo,
		                        @Condicion, @Vencimiento, @ClienteProv, @EnviarA, @Agente, NULL, NULL, NULL,
                                        @ImporteCx, @ImpuestosCx, @RetencionCx, @SumaComision, 
                                        NULL, NULL, NULL, NULL, @VIN, NULL,
			                @CxModulo OUTPUT, @CxMov OUTPUT, @CxMovID OUTPUT,
                                        @Ok OUTPUT, @OkRef OUTPUT, @INSTRUCCIONES_ESP = 'SIN_DOCAUTO', @IVAFiscal = @IVAFiscal, @IEPSFiscal = @IEPSFiscal, @Retencion2 = @Retencion2Cx, @Retencion3 = @Retencion3Cx
          ELSE BEGIN
            IF (@CobroIntegradoCxc = 1 OR @CobroIntegradoParcial = 1) AND @Accion = 'CANCELAR'
              EXEC spCobroIntegradoCxcCancelar @Sucursal, @Accion, @Modulo, @Empresa, @Usuario, @ID, @Mov, @MovID, @FechaRegistro, @Ok OUTPUT, @OkRef OUTPUT

            SELECT @CondicionCx = @Condicion, @VencimientoCx = @Vencimiento
            IF @CobroIntegradoParcial = 1
              SELECT @CondicionCx = Condicion, @VencimientoCx = Vencimiento FROM VentaCobro WHERE ID = @ID

            IF @CfgAC = 1 AND @Modulo = 'VTAS' 
            BEGIN
              SELECT @LCMetodo = ta.Metodo, @LCPorcentajeResidual = ISNULL(lc.PorcentajeResidual, 0)
                FROM Venta v 
                JOIN TipoAmortizacion ta ON ta.TipoAmortizacion = v.TipoAmortizacion
                JOIN LC ON lc.LineaCredito = v.LineaCredito 
               WHERE v.ID = @ID          
               EXEC xpPorcentajeResidual @Modulo, @ID, @LCPorcentajeResidual OUTPUT

--COMENTARIO_0013

            END

            EXEC @CxID = spGenerarCx @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, NULL, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, 
    	                   	     @FechaAfectacion, @Concepto, @Proyecto, @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones,
   		           	     @FechaRegistro, @Ejercicio, @Periodo,
		           	     @CondicionCx, @VencimientoCx, @ClienteProv, @EnviarA, @Agente, NULL, NULL, NULL,
                           	     @ImporteCx, @ImpuestosCx, @RetencionCx, @SumaComision, 
                           	     NULL, NULL, NULL, NULL, @VIN, NULL,
			   	     @CxModulo OUTPUT, @CxMov OUTPUT, @CxMovID OUTPUT,
                           	     @Ok OUTPUT, @OkRef OUTPUT, @INSTRUCCIONES_ESP = 'SIN_DOCAUTO', @IVAFiscal = @IVAFiscal, @IEPSFiscal = @IEPSFiscal, @Retencion2 = @Retencion2Cx, @Retencion3 = @Retencion3Cx, @EndosarA = @EndosarA, @CopiarMovImpuesto = 1
            
            IF (@CobroIntegradoCxc = 1 OR @CobroIntegradoParcial = 1) AND @Accion <> 'CANCELAR'
              EXEC spCobroIntegradoCxc @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, @Modulo,
                                           @Empresa, @Usuario, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @FechaRegistro,
                                           @DineroImporte, @CobroDelEfectivo, @CobroCambio,
                                           @FormaCobro1, @FormaCobro2, @FormaCobro3, @FormaCobro4, @FormaCobro5,
                                           @Importe1, @Importe2, @Importe3, @Importe4, @Importe5,
                                           @Referencia1, @Referencia2, @Referencia3, @Referencia4, @Referencia5,
                                           @CtaDinero, @Cajero, @CxID, @FormaCobroCambio, @Ok OUTPUT, @OkRef OUTPUT

            IF @CfgAC = 1 AND @LCMetodo = 50 AND @Accion <> 'CANCELAR'
            BEGIN
              SELECT @CxAjusteImporte = @ImporteCx * (@LCPorcentajeResidual/100.0)
              IF @CxAjusteImporte > 0.0
              BEGIN
                SELECT @CxAjusteMov = ACAjusteValorResidual FROM EmpresaCfgMov WHERE Empresa = @Empresa
                SELECT @CxConcepto = ACAjusteConceptoValorResidual FROM EmpresaCfg WHERE Empresa = @Empresa
                EXEC @CxAjusteID = spAfectar 'CXC', @CxID, 'GENERAR', 'TODO', @CxAjusteMov, @Usuario, @EnSilencio = 1, @Conexion = 1, @Ok = @Ok OUTPUT, @OkRef = @OkRef OUTPUT
                IF @Ok = 80030 SELECT @Ok = NULL, @OkRef = NULL
                IF @Ok IS NULL AND @CxAjusteID IS NOT NULL
                BEGIN
                  UPDATE Cxc  SET Concepto = @CxConcepto, Importe = @CxAjusteImporte, Impuestos = NULL, AplicaManual = 1 WHERE ID = @CxAjusteID
                  DELETE CxcD WHERE ID = @CxAjusteID
                  INSERT CxcD (ID, Renglon, Aplica, AplicaID, Importe) VALUES (@CxAjusteID, 2048.0, @Mov, @MovID, @CxAjusteImporte)
                  EXEC spAfectar 'CXC', @CxAjusteID, 'AFECTAR', 'TODO', NULL, @Usuario, @EnSilencio = 1, @Conexion = 1, @Ok = @Ok OUTPUT, @OkRef = @OkRef OUTPUT
                END
              END

              SELECT @CxAjusteImporte = @ImpuestosCx
              IF @CxAjusteImporte > 0.0
              BEGIN
                SELECT @CxAjusteMov = ACAjusteImpuestoAd FROM EmpresaCfgMov WHERE Empresa = @Empresa
                SELECT @CxConcepto = ACAjusteConceptoImpuestoAd FROM EmpresaCfg WHERE Empresa = @Empresa
                EXEC @CxAjusteID = spAfectar 'CXC', @CxID, 'GENERAR', 'TODO', @CxAjusteMov, @Usuario, @EnSilencio = 1, @Conexion = 1, @Ok = @Ok OUTPUT, @OkRef = @OkRef OUTPUT
                IF @Ok = 80030 SELECT @Ok = NULL, @OkRef = NULL
                IF @Ok IS NULL AND @CxAjusteID IS NOT NULL
                BEGIN
                  UPDATE Cxc  SET Concepto = @CxConcepto, Importe = @CxAjusteImporte, Impuestos = NULL, AplicaManual = 1 WHERE ID = @CxAjusteID
                  DELETE CxcD WHERE ID = @CxAjusteID
                  INSERT CxcD (ID, Renglon, Aplica, AplicaID, Importe) VALUES (@CxAjusteID, 2048.0, @Mov, @MovID, @CxAjusteImporte)
                  EXEC spAfectar 'CXC', @CxAjusteID, 'AFECTAR', 'TODO', NULL, @Usuario, @EnSilencio = 1, @Conexion = 1, @Ok = @Ok OUTPUT, @OkRef = @OkRef OUTPUT
                END
              END
            END
          END
          IF @CxID IS NOT NULL
            SELECT @CxMovTipo = Clave FROM MovTipo WHERE Modulo = @CxModulo AND Mov = @CxMov
        END

        -- Retenciones de la Compra
        IF (@Fiscal = 0 OR @FiscalGenerarRetenciones = 1) AND @CfgRetencionAlPago = 0 AND @MovTipo IN ('COMS.F','COMS.FL','COMS.EG', 'COMS.EI', 'COMS.D') AND (@SumaRetencion <> 0.0 OR @SumaRetencion2 <> 0.0 OR @SumaRetencion3 <> 0.0)
        BEGIN
          IF @SumaRetencion <> 0.0 
          BEGIN
            IF @CfgRetencionAcreedor IS NULL 
              SELECT @Ok = 70100
            ELSE
              EXEC spGenerarCx @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, NULL, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, 
                               @FechaEmision, @CfgRetencionConcepto, @Proyecto, @Usuario, @Autorizacion, NULL, @DocFuente, @Observaciones,
  	  	               @FechaRegistro, @Ejercicio, @Periodo,
		               NULL, NULL, @CfgRetencionAcreedor, NULL, NULL, NULL, NULL, NULL,
                               @SumaRetencion, NULL, NULL, NULL, 
                               NULL, NULL, NULL, NULL, NULL, @CfgRetencionMov,
		               @CxModulo OUTPUT, @CxMov OUTPUT, @CxMovID OUTPUT,
                               @Ok OUTPUT, @OkRef OUTPUT
          END
          IF @SumaRetencion2 <> 0.0 
          BEGIN
            IF @CfgRetencion2Acreedor IS NULL 
              SELECT @Ok = 70100
            ELSE
              EXEC spGenerarCx @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, NULL, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, 
                               @FechaEmision, @CfgRetencion2Concepto, @Proyecto, @Usuario, @Autorizacion, NULL, @DocFuente, @Observaciones,
  	    	               @FechaRegistro, @Ejercicio, @Periodo,
		               NULL, NULL, @CfgRetencion2Acreedor, NULL, NULL, NULL, NULL, NULL,
                               @SumaRetencion2, NULL, NULL, NULL, 
                               NULL, NULL, NULL, NULL, NULL, @CfgRetencionMov,
	  	               @CxModulo OUTPUT, @CxMov OUTPUT, @CxMovID OUTPUT,
                               @Ok OUTPUT, @OkRef OUTPUT
          END
          IF @SumaRetencion3 <> 0.0 
          BEGIN
            IF @CfgRetencion3Acreedor IS NULL 
              SELECT @Ok = 70100
            ELSE
              EXEC spGenerarCx @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, NULL, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, 
                               @FechaEmision, @CfgRetencion3Concepto, @Proyecto, @Usuario, @Autorizacion, NULL, @DocFuente, @Observaciones,
  	    	               @FechaRegistro, @Ejercicio, @Periodo,
		               NULL, NULL, @CfgRetencion3Acreedor, NULL, NULL, NULL, NULL, NULL,
                               @SumaRetencion3, NULL, NULL, NULL, 
                               NULL, NULL, NULL, NULL, NULL, @CfgRetencionMov,
	  	               @CxModulo OUTPUT, @CxMov OUTPUT, @CxMovID OUTPUT,
                               @Ok OUTPUT, @OkRef OUTPUT
          END
        END

        -- Disminuir Anticipos Facturados
        IF @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FB') AND (@Estatus = 'SINAFECTAR' OR @EstatusNuevo = 'CANCELADO') AND @CfgAnticiposFacturados = 1 AND (@AnticiposFacturados > 0.0 OR @AnticipoFacturadoTipoServicio = 1) --ANTICIPOFACTURADO
        BEGIN
          IF @Accion = 'CANCELAR' SELECT @EsCargo = 1 ELSE SELECT @EsCargo = 0 
          IF @Accion = 'CANCELAR'
           UPDATE Cxc 
              SET AnticipoSaldo = ISNULL(AnticipoSaldo, 0) + vfa.Importe
             FROM Cxc c, VentaFacturaAnticipo vfa
            WHERE vfa.ID = @ID AND vfa.CxcID = c.ID
          ELSE BEGIN
            IF EXISTS(SELECT 1 FROM VentaD WHERE ID = @ID AND AnticipoFacturado = 1 AND (AnticipoMoneda <> @MovMoneda OR AnticipoTipoCambio <> @MovTipoCambio)) SELECT @Ok = 10495 --ANTICIPOFACTURADO
             
            --SELECT @SumaAnticiposFacturados = SUM((AnticipoAplicar*TipoCambio)/@MovTipoCambio) FROM Cxc WHERE AnticipoAplicaModulo = @Modulo AND AnticipoAplicaID = @ID --ANTICIPOFACTURADO
			SELECT @SumaAnticiposFacturados = SUM(CASE WHEN RTRIM(LTRIM(Moneda)) = RTRIM(LTRIM(@MovMoneda)) THEN AnticipoAplicar ELSE (AnticipoAplicar*TipoCambio)/@MovTipoCambio END) FROM Cxc WHERE AnticipoAplicaModulo = @Modulo AND AnticipoAplicaID = @ID AND Estatus IN ('PENDIENTE', 'CONCLUIDO')--ANTICIPOFACTURADO            
            EXEC xpSumaAnticiposFacturados @Empresa, @Usuario, @Accion, @Modulo, @ID, @MovMoneda, @MovTipoCambio, @SumaAnticiposFacturados OUTPUT, @Ok OUTPUT, @OkRef OUTPUT

            IF @AnticipoFacturadoTipoServicio = 1 SELECT @AnticiposFacturados = (SELECT SUM(ABS(ISNULL(Importetotal,0.0))-ABS(ISNULL(AnticipoRetencion,0.0))) FROM VentaTCalc WHERE ID = @ID AND AnticipoFacturado = 1) --ANTICIPOFACTURADO
            IF /*ISNULL(@SumaAnticiposFacturados, 0.0)> 0.0 AND */ABS(ROUND(@AnticiposFacturados,2)-ROUND(@SumaAnticiposFacturados,2)) > 0.1 SELECT @Ok = 30405 ELSE
            IF @AnticipoFacturadoTipoServicio = 1 AND ABS(ROUND(@AnticiposFacturados,2)-ROUND(@SumaAnticiposFacturados,2)) > 0.1 SELECT @Ok = 30405 ELSE                  
            IF @AnticipoFacturadoTipoServicio = 1 AND EXISTS(SELECT 1 FROM VentaTCalc WHERE ID = @ID AND AnticipoFacturado = 1 AND ImporteTotal > 0.0) SELECT @Ok = 30405 --ANTICIPOFACTURADO
            IF EXISTS(SELECT * FROM Cxc WHERE AnticipoAplicaModulo = @Modulo AND AnticipoAplicaID = @ID AND (ISNULL(AnticipoAplicar, 0) < 0.0 OR ROUND(AnticipoAplicar, 0) > ROUND(AnticipoSaldo, 0))) SELECT @Ok = 30405 
            ELSE BEGIN
              INSERT VentaFacturaAnticipo (ID, CxcID, Importe)
              SELECT @ID, ID, AnticipoAplicar
                FROM Cxc
               WHERE AnticipoAplicaModulo = @Modulo AND AnticipoAplicaID = @ID

              UPDATE Cxc 
                 SET AnticipoSaldo = ISNULL(AnticipoSaldo, 0) - ISNULL(AnticipoAplicar, 0),
                     AnticipoAplicar = NULL,
                     AnticipoAplicaModulo = NULL,
                     AnticipoAplicaID = NULL 
               WHERE AnticipoAplicaModulo = @Modulo AND AnticipoAplicaID = @ID  
            END
          END
          EXEC spSaldo @Sucursal, @Accion, @Empresa, @Usuario, 'CANT', @MovMoneda, @MovTipoCambio, @ClienteProv, NULL, NULL, NULL,
                       @Modulo, @ID, @Mov, @MovID, @EsCargo, @AnticiposFacturados, NULL, NULL,
                       @FechaAfectacion, @Ejercicio, @Periodo, @Mov, @MovID, 0, 0, 0,
     	               @Ok OUTPUT, @OkRef OUTPUT
        END

        --REQ7890
        IF @MovTipo IN ('COMS.EG', 'COMS.EI', 'INV.EI', 'COMS.GX') AND @EstatusNuevo IN ('CONCLUIDO','PROCESAR','CANCELADO')
          EXEC spAfectarGastoDiverso @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @FechaRegistro, 
                                     @Proyecto, @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones, @Ejercicio, @Periodo, @VIN,
                                     @Ok OUTPUT, @OkRef OUTPUT

        -- Afectar las Comisiones
        IF @UltAgente IS NOT NULL AND @ComisionAcum <> 0.0 AND @Ok IS NULL AND 
           (((@MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.FB', 'VTAS.D', 'VTAS.DF', 'VTAS.B') AND (@Estatus = 'SINAFECTAR' OR @EstatusNuevo = 'CANCELADO')) AND (@CfgVentaComisionesCobradas = 0 OR @CobroIntegrado = 1 OR @CobrarPedido = 1)) OR @MovTipo IN ('VTAS.FM', 'VTAS.N', 'VTAS.NO', 'VTAS.NR')) 
        BEGIN
          EXEC spGenerarCx @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, 'AGENT', @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio,
                           @FechaAfectacion, @Concepto, @Proyecto, @Usuario,  @Autorizacion, @Referencia, @DocFuente, @Observaciones,
                           @FechaRegistro, @Ejercicio, @Periodo, 
                           NULL, NULL, @ClienteProv, NULL, @UltAgente, NULL, NULL, NULL, 
                           @ComisionImporteNeto, NULL, NULL, @ComisionAcum, 
                           NULL, NULL, NULL, NULL, NULL, NULL,
                           @CxModulo, @CxMov, @CxMovID, @Ok OUTPUT, @OkRef  OUTPUT
          SELECT @ComisionAcum = 0.0, @ComisionImporteNeto = 0.0
        END

        IF @MovTipo = 'VTAS.DF' OR (@MovTipo = 'INV.A' AND @CfgInvAjusteCargoAgente <> 'NO') AND @Ok IS NULL
        BEGIN
          SELECT @CxImporte = NULL, @CxMovEspecifico = NULL, @CxAgente = @Agente

          IF @MovTipo = 'VTAS.DF'
          BEGIN
            SELECT @CxImporte = -SUM(Cantidad*Costo) FROM VentaD WHERE ID = @ID
            SELECT @CxMovEspecifico = @Mov
            SELECT @CxAgente = AgenteServicio FROM Venta WHERE ID = @ID
          END ELSE BEGIN
            IF @CfgInvAjusteCargoAgente = 'PRECIO' 
              SELECT @CxImporte = SUM(d.Cantidad*ISNULL(d.Precio, a.PrecioLista)) FROM InvD d, Art a WHERE d.ID = @ID AND d.Articulo = a.Articulo 
            ELSE 
              SELECT @CxImporte = SUM(Cantidad*Costo) FROM InvD WHERE ID = @ID
          END

          IF ISNULL(@CxImporte, 0.0) < 0.0
          BEGIN
            SELECT @CxImporte = -@CxImporte
            EXEC spGenerarCx @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, 'AGENT', @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @MovMoneda, @MovTipoCambio,
                             @FechaAfectacion, @Concepto, @Proyecto, @Usuario,  @Autorizacion, @Referencia, @DocFuente, @Observaciones,
                             @FechaRegistro, @Ejercicio, @Periodo, 
                             NULL, NULL, @Agente, NULL, @CxAgente, NULL, NULL, NULL, 
                             @CxImporte, NULL, NULL, @CxImporte, 
                             NULL, NULL, NULL, NULL, NULL, @CxMovEspecifico,
                             @CxModulo, @CxMov, @CxMovID, @Ok OUTPUT, @OkRef  OUTPUT    
            IF @Ok = 80030 SELECT @Ok = NULL, @OkRef = NULL
          END
        END

	-- Bonificacion Automatica
        IF @Accion <> 'CANCELAR'
        BEGIN
          IF @CfgCompraAutoCargos = 1 AND @MovTipo IN ('COMS.F', 'COMS.FL', 'COMS.EG', 'COMS.EI', 'COMS.D', 'COMS.B') AND @Ok IS NULL
	    EXEC xpCompraAutoCargos @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, @Modulo, @Empresa, @ID, @Mov,
			            @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @FechaEmision , @Concepto, @Proyecto,
				    @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones, @FechaRegistro, @Ejercicio, @Periodo,
				    @Condicion, @Vencimiento, @ClienteProv, @SumaImporteNeto, @SumaImpuestosNetos, @VIN, @Ok OUTPUT, @OkRef OUTPUT
          IF @CfgVentaAutoBonif = 1 AND @MovTipo IN ('VTAS.F','VTAS.FAR', 'VTAS.D', 'VTAS.DF', 'VTAS.B') AND @Ok IS NULL
	    EXEC xpVentaAutoBonif @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, @Modulo, @Empresa, @ID, @Mov,
			          @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @FechaEmision , @Concepto, @Proyecto,
				  @Usuario, @Autorizacion, @Referencia, @DocFuente, @Observaciones, @FechaRegistro, @Ejercicio, @Periodo,
				  @Condicion, @Vencimiento, @ClienteProv, @CobroIntegrado, @SumaImporteNeto, @SumaImpuestosNetos, @VIN, @Ok OUTPUT, @OkRef OUTPUT, @Agente -- BUG 16650
        END

        IF @Accion <> 'CANCELAR' AND @MovTipo IN ('VTAS.F','VTAS.FAR') AND (SELECT CxcAutoAplicarAnticiposPedidos FROM EmpresaCfg2 WHERE Empresa = @Empresa) = 1
        BEGIN
          SELECT @ReferenciaAplicacionAnticipo = RTRIM(@Origen) + ' ' + RTRIM(@OrigenID)
          EXEC xpVentaAutoAplicarAnticiposPedidos @Sucursal, @SucursalOrigen, @SucursalDestino, @Accion, @Modulo, @Empresa, @ID, @Mov,
   			          		  @MovID, @MovTipo, @MovMoneda, @MovTipoCambio, @FechaEmision , @Concepto, @Proyecto,
				  		  @Usuario, @Autorizacion, @ReferenciaAplicacionAnticipo, @DocFuente, @Observaciones, @FechaRegistro, @Ejercicio, @Periodo,
				  		  @Condicion, @Vencimiento, @ClienteProv, @CobroIntegrado, @SumaImporteNeto, @SumaImpuestosNetos, @VIN, @Ok OUTPUT, @OkRef OUTPUT
        END
	-- Documentacion Automatica
	IF @Ok IN (NULL, 80030) AND @CxID IS NOT NULL AND @CxMovTipo IN ('CXC.F', 'CXC.CA', 'CXC.CAP', 'CXC.CAD', 'CXC.D', 'CXP.F', 'CXP.CA', 'CXP.CAP', 'CXP.CAD', 'CXP.D') AND @Condicion IS NOT NULL AND @Accion <> 'CANCELAR' 
	BEGIN 
          SELECT @Ok = NULL, @OkRef = NULL
          IF (SELECT AC FROM EmpresaGral WHERE Empresa = @Empresa) = 0
  	    IF EXISTS(SELECT * FROM Condicion WHERE Condicion = @Condicion AND DA = 1)
              EXEC spCxDocAuto @CxModulo, @CxID, @Usuario, @Ok OUTPUT, @OkRef OUTPUT
        END

        IF @CfgCompraAutoEndosoAutoCargos = 1 AND @Modulo = 'COMS' AND @MovTipo = 'COMS.F' AND @Accion = 'AFECTAR' AND @EstatusNuevo = 'CONCLUIDO' AND @CxModulo = 'CXP' and @CxmovTipo = 'CXP.F' AND @CxID IS NOT NULL AND @Ok IN (NULL, 80030) 
        BEGIN
          SELECT @Proveedor = Proveedor FROM Compra WHERE ID = @ID
          SELECT @AutoEndosar = AutoEndoso FROM Prov WHERE Proveedor = @Proveedor
 
          IF @AutoEndosar IS NOT NULL
          BEGIN
            SELECT @Ok = NULL, @OkRef = NULL
            SELECT @CxEndosoMov = CxpEndoso FROM EmpresaCfgMov WHERE Empresa = @Empresa
            EXEC spCx @CxID, @CxModulo, 'GENERAR', 'TODO', @FechaRegistro, @CxEndosoMov, @Usuario, 1, 0, @CxEndosoMov OUTPUT, @CxEndosoMovID OUTPUT, @CxEndosoID OUTPUT, @Ok OUTPUT, @OkRef OUTPUT
            IF @Ok = 80030 SELECT @Ok = NULL, @OkRef = NULL
            IF @Ok IS NULL
            BEGIN
              IF @CxModulo = 'CXP' UPDATE Cxp SET FechaEmision = @FechaEmision, Proveedor = @AutoEndosar WHERE ID = @CxEndosoID 
                EXEC spCx @CxEndosoID, @CxModulo, 'AFECTAR', 'TODO', @FechaRegistro, NULL, @Usuario, 1, 0, @CxEndosoMov OUTPUT, @CxEndosoMovID OUTPUT, NULL, @Ok OUTPUT, @OkRef OUTPUT
            END
          END
        END

        IF @MovTipo = 'COMS.OP' AND @Ok IS NULL
          EXEC spCompraProrrateo @Sucursal, @Empresa, @Usuario, @Accion, @Modulo, @ID, @FechaRegistro, 
                                 @Mov, @MovID, @FechaEmision, @Ejercicio, @Periodo, @MovMoneda, @MovTipoCambio, 
                                 @Ok OUTPUT, @OkRef OUTPUT
        -- Explotar PROD.O 
        IF @MovTipo = 'PROD.O' AND @Ok IS NULL
          EXEC spProdExplotar @Sucursal, @Empresa, @Usuario, @Accion, @Modulo, @ID, @FechaRegistro, 0, @Ok OUTPUT, @OkRef OUTPUT

        IF @MovTipo IN ('VTAS.FG'/*, 'VTAS.FX'*/) AND @Ok IS NULL
          EXEC spGenerarGasto @Accion, @Empresa, @Sucursal, @Usuario, @Modulo, @ID, @Mov, @MovID, @FechaEmision, @FechaRegistro, @Ok OUTPUT, @OkRef OUTPUT, @MovTipo = @MovTipo
      END  -- if @Continuar = 1
    END

    IF @Modulo = 'VTAS'
    BEGIN
      IF (SELECT TieneMovimientos FROM Cte WHERE Cliente = @ClienteProv) = 0      
        UPDATE Cte SET TieneMovimientos = 1 WHERE Cliente = @ClienteProv 
    END
    IF @Modulo = 'VTAS' AND @EnviarA IS NOT NULL
    BEGIN
      IF (SELECT TieneMovimientos FROM CteEnviarA WHERE Cliente = @ClienteProv  AND ID = @EnviarA) = 0
        UPDATE CteEnviarA SET TieneMovimientos = 1 WHERE Cliente = @ClienteProv  AND ID = @EnviarA
    END
    IF @Almacen IS NOT NULL
    BEGIN
      IF (SELECT TieneMovimientos FROM Alm WHERE Almacen = @Almacen) = 0      
        UPDATE Alm SET TieneMovimientos = 1 WHERE Almacen = @Almacen 
    END
    IF @AlmacenDestino IS NOT NULL
    BEGIN
      IF (SELECT TieneMovimientos FROM Alm WHERE Almacen = @AlmacenDestino) = 0      
        UPDATE Alm SET TieneMovimientos = 1 WHERE Almacen = @AlmacenDestino 
    END
    IF @Agente IS NOT NULL
    BEGIN
      IF (SELECT TieneMovimientos FROM Agente WHERE Agente = @Agente) = 0      
        UPDATE Agente SET TieneMovimientos = 1 WHERE Agente = @Agente 
    END
    IF @Modulo = 'COMS'
    BEGIN
      IF (SELECT TieneMovimientos FROM Prov WHERE Proveedor = @ClienteProv) = 0      
        UPDATE Prov SET TieneMovimientos = 1 WHERE Proveedor = @ClienteProv
    END

    IF @OrigenMovTipo = 'VTAS.FR'
      EXEC spAfectarMovRecurrente @Accion, @Empresa, @Modulo, @Origen, @OrigenID, @Ok OUTPUT, @OkRef OUTPUT

    IF @MovTipo = 'VTAS.CTO'
      EXEC spMovContratoGenerar @Accion, @Empresa, @Sucursal, @Usuario, @Modulo, @ID, @Mov, @MovID, @FechaRegistro, @Ok OUTPUT, @OkRef OUTPUT

    IF @MovTipo IN ('COMS.CA', 'COMS.GX')
    BEGIN
      SELECT @ProrrateoAplicaID = p.ID, @ProrrateoAplicaIDMov = p.Mov, @ProrrateoAplicaIDMovID = p.MovID
        FROM Compra c, Compra p 
       WHERE c.ID = @ID 
         AND c.ProrrateoAplicaID = p.ID 
      IF @ProrrateoAplicaID IS NOT NULL
        EXEC spMovFlujo @Sucursal, @Accion, @Empresa, @Modulo, @ID, @Mov, @MovID, @Modulo, @ProrrateoAplicaID, @ProrrateoAplicaIDMov, @ProrrateoAplicaIDMovID, @Ok OUTPUT 
    END

    IF @Ok IS NULL OR @Ok BETWEEN 80030 AND 81000
    BEGIN
      IF @GenerarGasto = 1 AND @Modulo = 'INV'
        EXEC spGenerarGasto @Accion, @Empresa, @Sucursal, @Usuario, @Modulo, @ID, @Mov, @MovID, @FechaEmision, @FechaRegistro, @Ok OUTPUT, @OkRef OUTPUT, @MovTipoGenerarGasto = 1

      EXEC xpInvGenerarGasto @Sucursal, @Accion, @Modulo, @ID, @Mov, @MovID, @MovTipo, @Empresa, @Usuario, @FechaRegistro, @ClienteProv, @Ok OUTPUT, @OkRef OUTPUT
    END

    IF @MovTipo IN ('COMS.F', 'COMS.CC', 'VTAS.F') AND @Accion = 'AFECTAR' AND @EstatusNuevo = 'CONCLUIDO'
      EXEC spEliminarOrdenesPendientes @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
          	     	               @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
	        		       NULL, NULL,
                                       @Ok OUTPUT, @OkRef OUTPUT
                                       
    IF @MovTipo = 'COMS.O' AND @Accion = 'AFECTAR' AND @EstatusNuevo = 'PENDIENTE'
      EXEC spCancelarRequisicionesPendientes @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
                                             @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
                                             NULL, NULL,
                                             @Ok OUTPUT, @OkRef OUTPUT

    IF @MovTipo IN ('VTAS.P', 'VTAS.S') AND @CfgVentaDMultiAgenteSugerir = 1  AND @EstatusNuevo = 'PENDIENTE'
      EXEC spSugerirVentaDAgenteFecha @ID, @EnSilencio = 1

--COMENTARIO_0014

    IF @WMS = 1 AND EXISTS(SELECT * FROM Alm WHERE Almacen = @Almacen AND WMS = 1) AND @Accion IN ('AFECTAR', 'CANCELAR', 'RESERVARPARCIAL') AND @OrigenTipo <> 'TMA' AND @Ok IS NULL
    BEGIN
      SELECT @GenerarOrden = 0  	
      IF EXISTS(SELECT * FROM Alm WHERE Almacen = @Almacen AND GenerarOrdenEntarimado = 1) AND 
         EXISTS(SELECT * FROM AlmOrdenEntarimadoMov WHERE Almacen = @Almacen AND Modulo = @Modulo AND Mov = @Mov)
        EXEC spGenerarOrdemEntarimado @Modulo, @ID, @Accion, @Empresa, @Sucursal, @Usuario, @Mov, @MovID, @MovTipo, @Almacen, @Ok OUTPUT, @OkRef OUTPUT

      IF EXISTS(SELECT * FROM Alm WHERE Almacen = @Almacen AND (GenerarOrdenAcomodoRecibo = 1 OR GenerarSolAcomodoRecibo = 1)) AND 
         EXISTS(SELECT * FROM AlmOrdenAcomodoReciboMov WHERE Almacen = @Almacen AND Modulo = @Modulo AND Mov = @Mov)
      BEGIN
      	IF EXISTS(SELECT * FROM Alm WHERE Almacen = @Almacen AND GenerarOrdenAcomodoRecibo = 1) SELECT @GenerarOrden = 1
        EXEC spGenerarOrdenTarimaAcomodo 'RECIBO', @Modulo, @ID, @Accion, @Empresa, @Sucursal, @Usuario, @Mov, @MovID, @MovTipo, @FechaEmision, @Proyecto, @Almacen, @Ok OUTPUT, @OkRef OUTPUT, @GenerarOrden = @GenerarOrden
      END

      IF EXISTS(SELECT * FROM Alm WHERE Almacen = @Almacen AND (GenerarOrdenAcomodoSurtido = 1 OR GenerarSolAcomodoSurtido = 1)) AND 
         EXISTS(SELECT * FROM AlmOrdenAcomodoSurtidoMov WHERE Almacen = @Almacen AND Modulo = @Modulo AND Mov = @Mov)
      BEGIN
      	IF EXISTS(SELECT * FROM Alm WHERE Almacen = @Almacen AND GenerarOrdenAcomodoSurtido = 1) SELECT @GenerarOrden = 1
        EXEC spGenerarOrdenTarimaAcomodo 'REABASTECIMIENTO', @Modulo, @ID, @Accion, @Empresa, @Sucursal, @Usuario, @Mov, @MovID, @MovTipo, @FechaEmision, @Proyecto, @Almacen, @Ok OUTPUT, @OkRef OUTPUT, @GenerarOrden = @GenerarOrden
      END
    END

    /* Generar Transito */
    IF @MovTipo IN ('INV.SI', 'INV.DTI') AND @Ok IS NULL AND @Accion <> 'VERIFICAR'
    BEGIN
      IF @Accion <> 'CANCELAR'
      BEGIN
        EXEC @IDGenerar = spMovCopiar @Sucursal, @Modulo, @ID, @Usuario, @FechaRegistro, 1, @CopiarArtCostoInv = 1
        IF @IDGenerar IS NOT NULL
        BEGIN   
          IF @MovTipo = 'INV.DTI'
          BEGIN
            UPDATE Inv SET Almacen = @AlmacenDestinoOriginal, AlmacenDestino = @Almacen WHERE ID = @IDGenerar
            UPDATE InvD SET Almacen = @AlmacenDestinoOriginal WHERE ID = @IDGenerar
          END
          UPDATE Inv 
             SET Referencia      = RTRIM(@Mov)+ ' ' + RTRIM(@MovID),
                 SucursalDestino = (SELECT a.Sucursal  FROM Inv i, Alm a  WHERE i.ID = @IDGenerar AND a.Almacen = i.AlmacenDestino),
                 Mov             = (SELECT InvTransito FROM EmpresaCfgMov WHERE Empresa = @Empresa),
                 OrigenTipo = @Modulo,
                 Origen     = @Mov,
                 OrigenID   = @MovID
           WHERE ID = @IDGenerar

          UPDATE SerieLoteMov 
             SET Sucursal = (SELECT Sucursal  FROM Alm WHERE Almacen = @AlmacenDestinoOriginal)
           WHERE Empresa = @Empresa AND Modulo = @Modulo AND ID = @IDGenerar
          EXEC xpGenerarTransito @Empresa, @Sucursal, @Usuario, @Modulo, @MovTipo, @Referencia, @ID, @IDGenerar
        END
      END ELSE
        SELECT @IDGenerar = @IDTransito

--    SELECT @VolverAfectar = 3 
      IF @Ok IN (NULL, 80030)
      BEGIN
        SELECT @Ok = NULL, @OkRef = NULL
        EXEC spInv @IDGenerar, @Modulo, @Accion, 'TODO', @FechaRegistro, NULL, @Usuario, 1, @SincroFinal, 'TRANSITO',
                   @Mov, @MovID, @IDGenerar, @ContID,
                   @Ok OUTPUT, @OkRef OUTPUT/*, @VolverAfectar*/

        SELECT @TransitoSucursal = Sucursal, @TransitoMov = Mov, @TransitoMovID = MovID, @TransitoEstatus = Estatus FROM Inv WHERE ID = @IDGenerar
        IF @Ok IN (NULL, 80030)
        BEGIN
          EXEC spMovFlujo @Sucursal, @Accion, @Empresa, @Modulo, @ID, @Mov, @MovID, @Modulo, @IDGenerar, @TransitoMov, @TransitoMovID, @Ok OUTPUT
          IF @Accion = 'CANCELAR' AND @Ok = 80030 SELECT @Ok = NULL, @OkRef = NULL
        END ELSE SELECT @OkRef = @TransitoMov
      END

      /* Traspaso Express */
      IF (SELECT TraspasoExpress FROM MovTipo WHERE Modulo = @Modulo AND Mov = @Mov) = 1 AND @Ok IN (NULL, 80030) AND @Accion <> 'CANCELAR'  AND @TransitoEstatus = 'PENDIENTE'
      BEGIN
        SELECT @Ok = NULL, @OkRef = NULL
        SELECT @IDTransito = @IDGenerar
        EXEC @IDGenerar = spMovCopiar @Sucursal, @Modulo, @IDTransito, @Usuario, @FechaRegistro, 1, @CopiarArtCostoInv = 1
        IF @IDGenerar IS NOT NULL
        BEGIN
          UPDATE Inv 
             SET Mov             = (SELECT InvReciboTraspaso FROM EmpresaCfgMov WHERE Empresa = @Empresa),
--                 SucursalDestino = (SELECT a.Sucursal  FROM Inv i, Alm a  WHERE i.ID = @IDGenerar AND a.Almacen = i.AlmacenDestino),
                 OrigenTipo      = @Modulo,
                 Origen          = @TransitoMov,
                 OrigenID        = @TransitoMovID,
                 Directo         = 0
           WHERE ID = @IDGenerar
          UPDATE InvD 
             SET Aplica   = @TransitoMov,
                 AplicaID = @TransitoMovID
           WHERE ID = @IDGenerar

          EXEC spInv @IDGenerar, @Modulo, @Accion, 'TODO', @FechaRegistro, NULL, @Usuario, 1, @SincroFinal, NULL,
                     @Mov, @MovID, @IDGenerar, @ContID,
                     @Ok OUTPUT, @OkRef OUTPUT/*, @VolverAfectar*/
          SELECT @TraspasoExpressMov = Mov, @TraspasoExpressMovID = MovID FROM Inv WHERE ID = @IDGenerar
          IF @Ok IN (NULL, 80030)
            EXEC spMovFlujo @Sucursal, @Accion, @Empresa, @Modulo, @IDTransito, @TransitoMov, @TransitoMovID, @Modulo, @IDGenerar, @TraspasoExpressMov, @TraspasoExpressMovID, @Ok OUTPUT
          ELSE
            SELECT @OkRef = @TraspasoExpressMov
        END
      END
    END

    /* TransferirA */
    IF @MovTipo IN ('VTAS.D', 'VTAS.DCR') AND @Ok IN (NULL, 80030) 
    BEGIN
      SELECT @Ok = NULL
      IF EXISTS(SELECT * FROM VentaD WHERE ID = @ID AND ISNULL(NULLIF(RTRIM(TransferirA), ''), Almacen) <> Almacen)
        EXEC spInvTransferirA @Empresa, @Sucursal, @Usuario, @Accion, @Modulo, @ID, @Mov, @MovID, @FechaEmision, @FechaRegistro, @Ok OUTPUT, @OkRef OUTPUT
    END

    IF @FEA = 1 
    BEGIN
      SELECT @MovTipoConsecutivoFEA = NULLIF(RTRIM(ConsecutivoFEA), '') FROM MovTipo WHERE Modulo = @Modulo AND Mov = @Mov
      IF @MovTipoConsecutivoFEA IS NOT NULL
      BEGIN
        IF @Accion = 'AFECTAR' AND @Estatus IN ('SINAFECTAR', 'BORRADOR', 'CONFIRMAR') AND NOT EXISTS(SELECT * FROM VentaFEA WHERE ID = @ID)
        BEGIN
          EXEC spConsecutivo @MovTipoConsecutivoFEA, @Sucursal, @FEAConsecutivo OUTPUT, @Referencia = @FEAReferencia OUTPUT
          EXEC spMovIDEnSerieConsecutivo @FEAConsecutivo, @FEASerie OUTPUT, @FEAFolio OUTPUT
          INSERT VentaFEA (
                 ID,  Serie,     Folio,     Aprobacion,                   Procesar, Cancelada) 
          SELECT @ID, @FEASerie, @FEAFolio, CONVERT(int, @FEAReferencia), 1,        0
          EXEC spPreValidarFEA @ID, 0, @Ok OUTPUT, @OkRef OUTPUT
        END ELSE
        IF @Accion = 'CANCELAR' AND @Estatus IN ('PENDIENTE', 'CONCLUIDO') 
        BEGIN
	  UPDATE VentaFEA SET Procesar = 1, Cancelada = 1 WHERE ID = @ID
        END
      END
    END 

    IF @CfgVentaPuntosEnVales = 1 AND @Accion IN ('AFECTAR', 'RESERVARPARCIAL', 'CANCELAR') AND @Mov IN (SELECT Mov FROM EmpresaCfgPuntosEnValesMov WHERE Empresa = @Empresa) AND (@Ok IS NULL OR @Ok BETWEEN 80030 AND 81000)
      EXEC spVentaPuntosEnVales @Empresa, @Modulo, @ID, @Mov, @MovID, @MovTipo, @Accion, @FechaEmision, @Usuario, @Sucursal, @MovMoneda, @MovTipoCambio, @Ok OUTPUT, @OkRef OUTPUT
   
    IF @Ok IS NULL AND @MovTipo = 'COMS.GX'
      IF EXISTS(SELECT * FROM CompraD WHERE ID = @ID AND EsEstadistica = 1)
        EXEC spInvGenerarEstadistica @Empresa, @Sucursal, @Modulo, @ID, @Mov, @MovID, @Accion, @ClienteProv, @Ok OUTPUT, @OkRef OUTPUT

    IF @MovTipo = 'INV.A' AND @OrigenMovTipo= 'INV.IF'
      EXEC spMovFlujo @Sucursal, @Accion, @Empresa, 'INV', @IDOrigen, @Origen, @OrigenID, 'INV', @ID, @Mov, @MovID, @Ok OUTPUT

    -- Agregar a Estatus Log
    IF @Ok IS NULL OR @Ok BETWEEN 80030 AND 81000
      EXEC spMovFinal @Empresa, @Sucursal, @Modulo, @ID, @Estatus, @EstatusNuevo, @Usuario, @FechaEmision, @FechaRegistro, @Mov, @MovID, @MovTipo, @IDGenerar, @Ok OUTPUT, @OkRef OUTPUT

    IF @Ok IS NULL OR @Ok BETWEEN 80030 AND 81000
      EXEC spInvFacturaFlexibleAfectar @Empresa, @Sucursal, @Usuario, @Accion, @Estatus, @Modulo, @ID, @Ok OUTPUT, @OkRef OUTPUT

    IF (@Ok IS NULL OR @Ok BETWEEN 80030 AND 81000) AND @EsEcuador = 1
      EXEC spEcuadorAutorizacion @Sucursal, @Empresa, @Modulo, @ID, @Accion, @EstatusNuevo, @Ok OUTPUT, @OkRef OUTPUT

    IF @Ok IS NULL
      EXEC spGTInvAfectar @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
      	     	          @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
			  @UtilizarID, @UtilizarMovTipo, @IDGenerar,
                          @Ok OUTPUT, @OkRef OUTPUT

    IF @Ok IS NULL
      EXEC spInvFacturaProrrateadaAfectar @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
      	     	                          @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
			                  @UtilizarID, @UtilizarMovTipo,
                                          @Ok OUTPUT, @OkRef OUTPUT

    IF @Ok IS NULL
      EXEC spInvPedidoProrrateadoAfectar  @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
      	     	                          @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
			                  @UtilizarID, @UtilizarMovTipo,
                                          @Ok OUTPUT, @OkRef OUTPUT

    IF @Ok IS NULL OR @Ok BETWEEN 80030 AND 81000
      EXEC xpInvAfectar @ID, @Accion, @Base, @Empresa, @Usuario, @Modulo, @Mov, @MovID, @MovTipo,
    	     	        @MovMoneda, @MovTipoCambio, @Estatus, @EstatusNuevo, @FechaEmision, @FechaRegistro, @FechaAfectacion, @Conexion, @SincroFinal, @Sucursal,
			NULL, NULL,
                        @Ok OUTPUT, @OkRef OUTPUT
    IF @MovTipo = 'VTAS.S' AND @GenerarOP = 1 AND @EstatusNuevo IN ('PENDIENTE', 'CANCELADO') AND @Estatus <> @EstatusNuevo
      EXEC spAutoGenerarOP @Sucursal, @Accion, @Modulo, @ID, @Mov, @MovID, @MovTipo, @Empresa, @Usuario, @FechaRegistro, @ClienteProv, @ServicioSerie, @Ok OUTPUT, @OkRef OUTPUT

  IF @MovTipo = 'INV.EP' AND @EstatusNuevo = 'CANCELADO' AND @Ok IS NULL AND @Accion = 'CANCELAR'
    EXEC spInvEntradaProductoCancelarConsumoMaterial @Accion, @Empresa, @ID, @Ok OUTPUT, @OkRef OUTPUT

  IF @MovTipo = 'INV.CM' AND @EstatusNuevo = 'CONCLUIDO' AND @Ok IS NULL AND @OrigenTipo = 'INV/EP'
    EXEC spInvConsumoMaterialAfectarEntradaProducto @Accion, @Empresa, @Sucursal, @ID, @Mov, @MovID, @Ok OUTPUT, @OkRef OUTPUT

    -- Cancelar el Flujo
    IF @Accion = 'CANCELAR' AND @EstatusNuevo = 'CANCELADO' AND @Ok IS NULL
    BEGIN
      EXEC spCancelarFlujo @Empresa, @Modulo, @ID, @Ok OUTPUT
      IF @Modulo = 'VTAS' UPDATE VentaOrigen SET OrigenID = 0 WHERE ID = @ID
    END

    IF @SAUX = 1 AND @Accion IN ('AFECTAR', 'CANCELAR', 'RESERVARPARCIAL') AND @OK IS NULL
      EXEC spFlujoSAUX @Modulo, @ID, @Accion, @Base, @FechaRegistro, NULL, @Empresa, @Sucursal, @Usuario, @Conexion, @SincroFinal, @Mov, @MovID, @MovTipo, @Almacen, @FechaEmision, @Proyecto, @Ok OUTPUT, @OkRef OUTPUT

--if @ok IN (NULL, 80030) select @Ok = 1 -- breakpoint

  IF @Conexion = 0
  BEGIN
    IF @Ok IS NULL OR @Ok BETWEEN 80030 AND 81000
      COMMIT TRANSACTION
    ELSE BEGIN
      DECLARE @PolizaDescuadrada TABLE (Cuenta varchar(20) NULL, SubCuenta varchar(50) NULL, Concepto varchar(50) NULL, Debe money NULL, Haber money NULL, SucursalContable int NULL)
      IF EXISTS(SELECT * FROM PolizaDescuadrada WHERE Modulo = @Modulo AND ID = @ID)
      INSERT @PolizaDescuadrada (Cuenta, SubCuenta, Concepto, Debe, Haber, SucursalContable) SELECT Cuenta, SubCuenta, Concepto, Debe, Haber, SucursalContable FROM PolizaDescuadrada WHERE Modulo = @Modulo AND ID = @ID 
      ROLLBACK TRANSACTION
      DELETE PolizaDescuadrada WHERE Modulo = @Modulo AND ID = @ID
      INSERT PolizaDescuadrada (Modulo, ID, Cuenta, SubCuenta, Concepto, Debe, Haber, SucursalContable) SELECT @Modulo, @ID, Cuenta, SubCuenta, Concepto, Debe, Haber, SucursalContable FROM @PolizaDescuadrada
    END
  END
    
  IF @Ok = 80070 AND @MovTipo = 'INV.IF' UPDATE Inv SET Estatus = 'CONCLUIDO', FechaConclusion = GETDATE() WHERE ID = @ID
  RETURN
END
GO
