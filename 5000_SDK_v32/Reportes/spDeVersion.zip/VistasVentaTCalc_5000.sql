/* Configuracion MS SQL Server */
SET DATEFIRST 7
SET ANSI_NULLS OFF
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET LOCK_TIMEOUT -1
SET QUOTED_IDENTIFIER OFF
GO
/*** VentaCalc ***/
if exists (select * from sysobjects where id = object_id('dbo.VentaCalc') and type = 'V') drop view dbo.VentaCalc
GO
CREATE VIEW VentaCalc
--//WITH ENCRYPTION
AS 
SELECT 
  v.*,
  "DescuentosTotales" = (Convert(money, ROUND((v.Importe*ISNULL(v.DescuentoGlobal, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0)))+ISNULL(v.DescuentoLineal, 0.0)),
  "ImporteSobrePrecio"= (Convert(money, ROUND((v.Importe*ISNULL(v.SobrePrecio, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0)))),
  "SubTotal"          = Convert(money, ROUND(dbo.fnSubTotal(v.Importe, v.DescuentoGlobal, v.SobrePrecio), ISNULL(vs.RedondeoMonetarios,0))),
  "ImporteTotal"      = Convert(money, ROUND(dbo.fnSubTotal(v.Importe, v.DescuentoGlobal, v.SobrePrecio) + ISNULL(v.Impuestos, 0.0), ISNULL(vs.RedondeoMonetarios,0))),
  "TotalNeto"         = Convert(money, ROUND(dbo.fnSubTotal(v.Importe, v.DescuentoGlobal, v.SobrePrecio) + ISNULL(v.Impuestos, 0.0) - ISNULL(v.AnticiposFacturados, 0.0) - ISNULL(v.Retencion, 0.0), ISNULL(vs.RedondeoMonetarios,0)))

FROM Venta v
JOIN Version vs ON 1 = 1
GO


-- select * from VentaDpreCalc
-- select * from VentaDpreCalc
/*** VentaDpreCalc ***/
if exists (select * from sysobjects where id = object_id('dbo.VentaDpreCalc') and type = 'V') drop view dbo.VentaDpreCalc
GO
CREATE VIEW VentaDpreCalc
--//WITH ENCRYPTION
AS 
SELECT 
  d.*,
  "CantidadNeta" = Cantidad-ISNULL(CantidadCancelada, 0.0),
  "CantidadSinObsequios" = Cantidad-ISNULL(CantidadCancelada, 0.0)-ISNULL(CantidadObsequio, 0.0),
  "CantidadFactor" = (Cantidad-ISNULL(CantidadCancelada, 0.0))*Factor,
  "ReservadaFactor" = CantidadReservada*Factor,
  "OrdenadaFactor" = CantidadOrdenada*Factor,
  "PendienteFactor" = CantidadPendiente*Factor,
  "Impuesto1Base" = Impuesto1,
  "Impuesto2Base" = CASE WHEN v.Impuesto2Info=1 THEN 0.0 ELSE Impuesto2 END,
  "Impuesto3Base" = CASE WHEN v.Impuesto3Info=1 THEN 0.0 ELSE Impuesto3 END,
  "Impuesto2BaseImpuesto1" = CASE WHEN v.Impuesto2Info=1 OR v.Impuesto2BaseImpuesto1=0 THEN 0.0 ELSE Impuesto2 END,
  "Retencion2BaseImpuesto1" = CASE WHEN ISNULL(v.Retencion2BaseImpuesto1,0) = 0 THEN 0 ELSE 1 END, --ARCC
  "ImpuestosPorcentaje" = convert(float, round((CASE WHEN v.Impuesto2Info=0 THEN ISNULL(Impuesto2,0.0) ELSE 0.0 END)+(ISNULL(Impuesto1, 0.0)*(1.0+((CASE WHEN v.Impuesto2Info=1 OR v.Impuesto2BaseImpuesto1=0 THEN 0.0 ELSE ISNULL(Impuesto2,0.0) END)/100))), 10.0)),
  "ImpuestosImporte"    = convert(float, ROUND((Cantidad-ISNULL(CantidadCancelada, 0.0))*ISNULL(CASE WHEN v.Impuesto3Info=1 THEN 0.0 ELSE Impuesto3 END, 0.0), ISNULL(v.RedondeoMonetarios,0))),
  "CostoTotal"          = convert(float, ROUND((Cantidad-ISNULL(CantidadCancelada, 0.0))*Costo, ISNULL(v.RedondeoMonetarios,0))),
  "CostoActividadTotal" = convert(float, ROUND((Cantidad-ISNULL(CantidadCancelada, 0.0))*CostoActividad, ISNULL(v.RedondeoMonetarios,0))),
  "PrecioTotal"         = convert(float, ROUND((Cantidad-ISNULL(CantidadCancelada, 0.0)-ISNULL(CantidadObsequio, 0.0))*Precio, ISNULL(v.RedondeoMonetarios,0))),
  "preImporte"          = convert(float, ROUND(((Cantidad-ISNULL(CantidadCancelada, 0.0)-ISNULL(CantidadObsequio, 0.0))*Precio)-ISNULL(case when DescuentoTipo='$' then DescuentoLinea else (Cantidad-ISNULL(CantidadCancelada, 0.0)-ISNULL(CantidadObsequio, 0.0))*Precio*(DescuentoLinea/100.0) end, 0.0), ISNULL(v.RedondeoMonetarios,0))),--,
  "preImporteSinDL"     = convert(float, ROUND(((Cantidad-ISNULL(CantidadCancelada, 0.0)-ISNULL(CantidadObsequio, 0.0))*Precio), ISNULL(v.RedondeoMonetarios,0))),--REQ Q3069 CFDGT
  "ImpIncpreImporte"    = convert(float, ROUND(((Cantidad-ISNULL(CantidadCancelada, 0.0)-ISNULL(CantidadObsequio, 0.0))*Precio), ISNULL(v.RedondeoMonetarios,0)))
  --"DescuentoLineal"     = convert(float, ROUND((case when DescuentoTipo='$' then DescuentoLinea else (Cantidad-ISNULL(CantidadCancelada, 0.0)-ISNULL(CantidadObsequio, 0.0))*Precio*(DescuentoLinea/100.0) end), dbo.fnRedondeoMonetarios()))

FROM VentaD d
JOIN Version v ON 1 = 1
GO

-- select * from VentaDpreCalc2 
/*** VentaDpreCalc2 ***/
if exists (select * from sysobjects where id = object_id('dbo.VentaDpreCalc2') and type = 'V') drop view dbo.VentaDpreCalc2
GO
CREATE VIEW VentaDpreCalc2
--//WITH ENCRYPTION
AS 
SELECT 
  d.*,
  "preImporte2" = CASE 
                    WHEN cfg.VentaPrecioMoneda = 1 THEN preImporte*PrecioTipoCambio/v.TipoCambio
                    ELSE preImporte
                  END,
  "ImpIncpreImporte2" = CASE 
                          WHEN cfg.VentaPrecioMoneda = 1 THEN ImpIncpreImporte*PrecioTipoCambio/v.TipoCambio
                          ELSE ImpIncpreImporte
                         END,
  "ImpIncprePrecio" = CASE 
                        WHEN cfg.VentaPrecioMoneda = 1 THEN Precio*PrecioTipoCambio/v.TipoCambio
                        ELSE Precio
                      END,                         
  --REQ Q3069 CFDGT
  "preImporte2SinDL" = CASE 
                         WHEN cfg.VentaPrecioMoneda = 1 THEN preImporteSinDL*PrecioTipoCambio/v.TipoCambio
                         ELSE preImporteSinDL
                       END,
  "prePrecioSinDL" = CASE 
                       WHEN cfg.VentaPrecioMoneda = 1 THEN Precio*PrecioTipoCambio/v.TipoCambio
                       ELSE Precio
                     END,
  --REQ Q3069 CFDGT
  "DescuentoLineal" = CASE
                        WHEN cfg.VentaPrecioMoneda = 1 THEN CantidadSinObsequios*Precio*PrecioTipoCambio/v.TipoCambio*(DescuentoLinea/100.0)
                        ELSE CantidadSinObsequios*Precio*(DescuentoLinea/100.0)
                      END
FROM Venta v 
JOIN VentaDpreCalc d ON v.ID = d.ID
JOIN EmpresaCfg cfg ON v.Empresa = cfg.Empresa
GO

-- select * from VentaDCalc
/*** VentaDCalc ***/
if exists (select * from sysobjects where id = object_id('dbo.VentaDCalc') and type = 'V') drop view dbo.VentaDCalc
GO
CREATE VIEW VentaDCalc
--//WITH ENCRYPTION
AS 
SELECT 
  d.*,
  "Importe" = CASE 
				WHEN cfg.VentaPreciosImpuestoIncluido = 1 THEN (preImporte2-ISNULL(d.Impuesto3Base,0.0))/ (1.0 + (ISNULL(d.Impuesto2Base, 0.0)/100) + ((ISNULL(d.Impuesto1Base,0.0)/100) * (1+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100))))
                ELSE preImporte2
              END,
  --REQ Q3069 CFDGT
  "ImporteSinDL" = CASE 
				     WHEN cfg.VentaPreciosImpuestoIncluido = 1 THEN (preImporte2SinDL-ISNULL(d.Impuesto3Base,0.0))/ (1.0 + (ISNULL(d.Impuesto2Base, 0.0)/100) + ((ISNULL(d.Impuesto1Base,0.0)/100) * (1+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100))))
				     ELSE preImporte2SinDL
				     END,
  "PrecioSinDL" = CASE 
				    WHEN cfg.VentaPreciosImpuestoIncluido = 1 THEN (prePrecioSinDL-ISNULL(d.Impuesto3Base,0.0))/ (1.0 + (ISNULL(d.Impuesto2Base, 0.0)/100) + ((ISNULL(d.Impuesto1Base,0.0)/100) * (1+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100))))
				    ELSE prePrecioSinDL
				  END,
  --REQ Q3069 CFDGT
  "ImpIncImporte" = CASE 
				      WHEN cfg.VentaPreciosImpuestoIncluido = 1 THEN (ImpIncpreImporte2-ISNULL(d.Impuesto3Base,0.0))/ (1.0 + (ISNULL(d.Impuesto2Base, 0.0)/100) + ((ISNULL(d.Impuesto1Base,0.0)/100) * (1+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100))))
                      ELSE ImpIncpreImporte2
                    END,              
  "ImpIncPrecio" = CASE 
				     WHEN cfg.VentaPreciosImpuestoIncluido = 1 THEN (ImpIncprePrecio-ISNULL(d.Impuesto3Base,0.0))/ (1.0 + (ISNULL(d.Impuesto2Base, 0.0)/100) + ((ISNULL(d.Impuesto1Base,0.0)/100) * (1+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100))))
                     ELSE ImpIncprePrecio
                   END
FROM Venta v 
JOIN VentaDpreCalc2 d ON v.ID = d.ID
JOIN EmpresaCfg cfg ON v.Empresa = cfg.Empresa
GO

/*** VentaTCalc ***/
if exists (select * from sysobjects where id = object_id('dbo.VentaTCalc') and type = 'V') drop view dbo.VentaTCalc
GO
CREATE VIEW VentaTCalc
--//WITH ENCRYPTION
AS 
SELECT 
  v.ID,
  v.Empresa,
  v.SucursalOrigen,
  v.Sucursal,
  v.SucursalVenta,
  v.Mov,
  v.MovID,
  v.Moneda,
  v.TipoCambio,
  v.Concepto,
  v.Referencia,
  v.Proyecto,
  v.FechaRegistro,
  v.FechaEmision,
  d.FechaRequerida,
  v.HoraRequerida,
  v.FechaOriginal,
  v.Prioridad,
  v.Estatus,
  v.Situacion,
  v.SituacionFecha,
  v.SituacionUsuario,
  v.SituacionNota,
  v.Cliente,
  d.EnviarA,
  v.Agente,
  v.FormaEnvio,
  v.Condicion,
  v.Vencimiento,
  v.Usuario,
  v.Paquetes,
  v.Observaciones,
  v.Causa,
  v.AnticiposFacturados,
  v.Retencion,
  v.Ejercicio,
  v.Periodo,
  v.FechaConclusion,
  v.FechaEntrega,
  v.EmbarqueEstado,
  v.Peso,
  v.Volumen,
  v.ListaPreciosEsp,
  v.ZonaImpuesto,
  v.Extra,
  v.ServicioArticulo,
  v.ServicioSerie,
  v.Clase,
  v.SubClase,
  d.Aplica,
  d.AplicaID,
  d.Renglon,
  d.RenglonSub,
  d.RenglonID,
  d.RenglonTipo,
  d.Almacen,
  d.Codigo,
  d.Articulo,
  d.SubCuenta,
  d.Unidad,
  d.Precio,
  d.DescuentoTipo,
  d.DescuentoLinea,
  d.Impuesto1,
  d.Impuesto2,
  d.Impuesto3,
  d.Cantidad, 
  d.CantidadInventario,
  d.Factor,
  d.CantidadNeta, 
  d.CantidadFactor,
  d.ReservadaFactor,
  d.OrdenadaFactor,
  d.PendienteFactor,
  d.ImpuestosPorcentaje, 
  d.PoliticaPrecios,
  d.Comision,
  d.CantidadPendiente,
  d.CantidadReservada,
  d.CantidadOrdenada,
  d.CantidadEmbarcada,
  d.Costo,
  d.AjusteCosteo,
  d.CostoUEPS,
  d.CostoPEPS,
  d.UltimoCosto,
  d.CostoEstandar,
  d.PrecioLista,
  d.CostoTotal, 
  d.CostoActividad,
  d.CostoActividadTotal, 
  d.PrecioTotal, 
  d.Importe, 
  d.ContUso,
  d.ContUso2,
  d.ContUso3,
  d.Espacio,
  d.UEN,
  d.ExcluirISAN,
  d.Posicion,
  d.PresupuestoEsp,
  d.DescuentoLineal,
  d.TipoImpuesto1,
  d.TipoImpuesto2,
  d.TipoImpuesto3,
  d.Retencion1,
  d.Retencion2,
  d.Retencion3,     
  d.CostoPromedio,
  d.CostoReposicion,
  d.Ordencompra, 
  d.DescripcionExtra,
  d.AnticipoFacturado,  --ANTICIPOFACTURADO
  d.AnticipoMoneda, --ANTICIPOFACTURADO
  d.AnticipoTipoCambio, --ANTICIPOFACTURADO
  d.AnticipoRetencion, --ANTICIPOFACTURADO
  d.ImpIncPrecio,
  d.ImpIncPreImporte,
  d.ImpIncImporte,
  d.Tarima, --REQ12615 WMS
  "ImpIncDescuentoLineal" = ImpIncImporte*(d.DescuentoLinea/100.0),  
  --REQ Q3069 CFDGT
  d.PrecioSinDL,
  d.PreImporteSinDL,
  d.ImporteSinDL,
  "DescuentoLinealSinDL" = ImporteSinDL*(d.DescuentoLinea/100.0),
  --REQ Q3069 CFDGT
  "ImporteDescuentoGlobal" = convert(float, ROUND((d.Importe*(CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END)/100.0), ISNULL(vs.RedondeoMonetarios,0))),
  "DescuentosTotales"      = convert(float, ROUND((d.Importe*(CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END)/100.0) + ISNULL(d.DescuentoLineal, 0.0), ISNULL(vs.RedondeoMonetarios,0))),
  "ImpIncDescuentosTotales"= convert(float, ROUND(((d.ImpIncImporte*(1.0 - (ISNULL(d.DescuentoLinea, 0.0)/100.0)))*(CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END)/100.0) + (ISNULL(ImpIncImporte,0.0)*(ISNULL(d.DescuentoLinea,0.0)/100.0)), ISNULL(vs.RedondeoMonetarios,0))),
  "DescuentosTotalesSinDL" = convert(float, ROUND((d.ImporteSinDL*ISNULL(v.DescuentoGlobal, 0.0)/100.0) + (ISNULL(ImporteSinDL,0.0)*(ISNULL(d.DescuentoLinea,0.0)/100.0)), ISNULL(vs.RedondeoMonetarios,0))),--REQ Q3069 CFDGT
  "ImporteSobrePrecio"     = convert(float, ROUND((d.Importe*ISNULL(v.SobrePrecio, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0))),
  "SubTotal"               = Convert(float, ROUND(dbo.fnSubTotal(d.Importe, (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio), ISNULL(vs.RedondeoMonetarios,0))),
  "SubTotalSinDL"  = Convert(float, ROUND(dbo.fnSubTotal(d.ImporteSinDL,  0.0, v.SobrePrecio), ISNULL(vs.RedondeoMonetarios,0))), --REQ Q3069 CFDGT
  "ImpIncSubTotal"         = Convert(float, ROUND(dbo.fnSubTotal(d.ImpIncImporte,  0.0, v.SobrePrecio), ISNULL(vs.RedondeoMonetarios,0))),  
  "Impuesto1Total"         = Convert(float, ROUND(dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) * (1.0+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100.0))*(ISNULL(Impuesto1Base, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0))),
  "Impuesto2Total"         = Convert(float, ROUND(dbo.fnSubTotal(d.Importe, (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) * (ISNULL(Impuesto2Base, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0))),
  "Impuesto3Total"         = ISNULL(ImpuestosImporte, 0.0),--Convert(float, ROUND(dbo.fnSubTotal(d.Importe, v.DescuentoGlobal, v.SobrePrecio) * (1.0+(ISNULL(Impuesto2Base, 0.0)/100.0))*(ISNULL(Impuesto3Base, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0))),
  "Impuestos" 	           = ISNULL(ImpuestosImporte, 0.0) + Convert(float, ROUND(dbo.fnSubTotal(d.Importe, (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) * (ISNULL(ImpuestosPorcentaje, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0))),
  "Retencion1Total"        = Convert(float, ROUND(dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) *(ISNULL(d.Retencion1, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0))), --ARCC
  "Retencion2Total"        = Convert(float, ROUND((CASE WHEN d.Retencion2BaseImpuesto1 = 0 THEN dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) ELSE Convert(float, ROUND(dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) * (1.0+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100.0))*(ISNULL(Impuesto1Base, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0))) END) *(ISNULL(d.Retencion2, 0.0)/100.0), ISNULL(vs.RedondeoMonetarios,0))), --ARCC 
  "Retencion3Total"        = Convert(float, ROUND(dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) *(ISNULL(d.Retencion3, 0.0)/100.0), dbo.fnRedondeoMonetarios())),
  "ImporteTotal"           = ISNULL(ImpuestosImporte, 0.0) + Convert(float, ROUND(dbo.fnSubTotal(d.Importe, (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) * (1.0+(ISNULL(ImpuestosPorcentaje, 0.0)/100.0)), ISNULL(vs.RedondeoMonetarios,0))),
  "TotalNeto"              = (ISNULL(ImpuestosImporte, 0.0) 
	 + Convert(float, ROUND(dbo.fnSubTotal(d.Importe, (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) * (1.0+(ISNULL(ImpuestosPorcentaje, 0.0)/100.0)), dbo.fnRedondeoMonetarios())-
	 ISNULL(Convert(float, ROUND(dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) *(ISNULL(d.Retencion1, 0.0)/100.0), dbo.fnRedondeoMonetarios())),0.0)
	 -ISNULL(Convert(float, ROUND((CASE WHEN d.Retencion2BaseImpuesto1 = 0 THEN dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) ELSE Convert(float, ROUND(dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) * (1.0+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100.0))*(ISNULL(Impuesto1Base, 0.0)/100.0), dbo.fnRedondeoMonetarios())) END) *(ISNULL(d.Retencion2, 0.0)/100.0), dbo.fnRedondeoMonetarios())),0.0)))
	 -ISNULL(Convert(float, ROUND(dbo.fnSubTotal(ISNULL(d.Importe,0.0), (CASE WHEN ISNULL(d.AnticipoFacturado, 0) = 0 THEN ISNULL(v.DescuentoGlobal,0.0) ELSE 0 END), v.SobrePrecio) *(ISNULL(d.Retencion3, 0.0)/100.0), dbo.fnRedondeoMonetarios())),0.0)
-- En caso de que al TotalNeto se quiera descontar AnticiposFacturados y Retenciones descoemntar el calculo siguiente
/* "TotalNeto"              = ISNULL(ImpuestosImporte, 0.0) + Convert(float, ROUND(dbo.fnSubTotal(d.Importe, v.DescuentoGlobal, v.SobrePrecio) * (1.0+(ISNULL(ImpuestosPorcentaje, 0.0)/100.0)) 
                             - dbo.fnR3((SELECT SUM(b.importe) FROM VentaDCalc b WHERE b.ID = v.ID),100,d.Importe)*ISNULL(v.AnticiposFacturados, 0.0)
                             - CASE WHEN dbo.fnEsPitex(v.Cliente) = 1 
                                    THEN Convert(float, dbo.fnSubTotal(d.Importe, v.DescuentoGlobal, v.SobrePrecio) * (1.0+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100.0))*(ISNULL(Impuesto1Base, 0.0)/100.0)) 
                                    ELSE CASE WHEN d.Articulo ='FLETE' 
                                              THEN Convert(float, dbo.fnSubTotal(d.Importe, v.DescuentoGlobal, v.SobrePrecio) * (1.0+(ISNULL(d.Impuesto2BaseImpuesto1, 0.0)/100.0))*(ISNULL(Impuesto1Base, 0.0)/100.0))  
                                              ELSE 0 END
                                    END, ISNULL(vs.RedondeoMonetarios,0)))*/

FROM Venta v
JOIN VentaDCalc d ON v.ID = d.ID
JOIN Version vs ON 1 = 1
GO