SET DATEFIRST 7
SET ANSI_NULLS OFF
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET LOCK_TIMEOUT -1
SET QUOTED_IDENTIFIER OFF
GO

/**************** spAplicarAnticiposCFDI ****************/
if exists (select * from sysobjects where id = object_id('dbo.spAplicarAnticiposCFDI') and type = 'P') drop procedure dbo.spAplicarAnticiposCFDI
GO             
CREATE PROCEDURE spAplicarAnticiposCFDI
        @Estacion       int,
        @ID             int
        
--//WITH ENCRYPTION
AS BEGIN
  -- SET nocount ON
  DECLARE
    @Transaccion                        varchar(50),
    @Ok                                 int,
    @OkRef                              varchar(255),
    @Empresa                            varchar(5),
    @Cliente                            varchar(10),
    @MovMoneda                          varchar(10),
    @MovTipoCambio                      float,
    @Moneda                             varchar(10),
    @TipoCambio                         float,
    @Importe                            float,
    @Impuestos                          float,
    @Retencion                          float,
    @Retencion2                         float,
    @PorcentajeRetencion                float,
    @PorcentajeRetencion2               float,
    @AnticipoAplicar                    float,
    @AnticipoAplicar2					float,
    @AnticipoSaldo						float,
    @MovAnticipoAplicar                 float,
    @RenglonID                          int,
    @AsignoAnticipo                     bit,
    @FactorAplicar						float,
    @ImporteVenta						float,
    @RetencionVenta						float,
    @DescuentoLinea						float,
    @DescuentoImporte					money,
    @IDOrigen							int,
    @MovOrigen							varchar(20),
    @MovIDOrigen						varchar(20)

  SET @Transaccion = 'spAplicarAnticiposCFDI' + RTRIM(LTRIM(CONVERT(varchar,@Estacion)))
  
  BEGIN TRANSACTION @Transaccion

  SELECT @Ok = NULL, @OkRef = NULL
  
  SELECT 
    @Empresa = Empresa,
    @Cliente = Cliente,
    @MovMoneda  = Moneda,
    @MovTipoCambio = TipoCambio
    FROM Venta 
   WHERE ID = @ID
  
  IF @Ok IS NULL
  BEGIN
    
    SET @AsignoAnticipo = 0
    
    DELETE FROM VentaOrigenDevolucion WHERE Modulo = 'VTAS' AND Id = @ID
    
    SELECT
	  @ImporteVenta = SUM(ISNULL(ImporteTotal,0.0)),
	  @RetencionVenta = SUM(ISNULL(Retencion1Total,0.0)+ISNULL(Retencion2Total,0.0)+ISNULL(Retencion3Total,0.0))
	  FROM VentaTCalc
	 WHERE ID = @ID
    
    DECLARE crRelacionAnticipos CURSOR FOR
     SELECT ID, Mov, MovID, AnticipoSaldo, AnticipoAplicar
       FROM Cxc
      WHERE Empresa = @Empresa
        AND AnticipoSaldo > 0.0
        AND Estatus IN ('PENDIENTE','CONCLUIDO')
        AND Cliente = @Cliente
        AND ISNULL(AnticipoAplicar,0.0) > 0.0
        AND AnticipoAplicaID = @ID
        
    OPEN crRelacionAnticipos
    FETCH NEXT FROM crRelacionAnticipos INTO @IDOrigen, @MovOrigen, @MovIDOrigen, @AnticipoSaldo, @AnticipoAplicar2
    WHILE @@FETCH_STATUS = 0 AND @Ok IS NULL
    BEGIN
    
	  IF @AnticipoAplicar2 > @AnticipoSaldo SELECT @Ok = 30400, @OkRef = @MovOrigen + ' ' + @MovIDOrigen
    
	  IF NOT EXISTS (SELECT * FROM VentaOrigenDevolucion WHERE Empresa = @Empresa AND Modulo = 'VTAS' AND ID = @ID AND ModuloOrigen = 'CXC' AND IdOrigen = @IDOrigen AND MovOrigen = @MovOrigen AND MovIDOrigen = @MovIDOrigen) AND @Ok IS NULL
	  INSERT VentaOrigenDevolucion (Empresa,  Modulo, Id,	ModuloOrigen, IdOrigen,	  MovOrigen,  MovIDOrigen)
							VALUES (@Empresa, 'VTAS', @ID,  'CXC',		  @IDOrigen,  @MovOrigen, @MovIDOrigen)
							
	  FETCH NEXT FROM crRelacionAnticipos INTO @IDOrigen, @MovOrigen, @MovIDOrigen, @AnticipoSaldo, @AnticipoAplicar2
	END
	CLOSE crRelacionAnticipos
	DEALLOCATE crRelacionAnticipos

    DECLARE crAnticiposFacturados CURSOR FOR
     SELECT Moneda, ISNULL(TipoCambio,0.0), SUM(ISNULL(Importe,0.0)), SUM(ISNULL(Impuestos,0.0)), SUM(ISNULL(Retencion,0.0)), ROUND((ISNULL(Retencion,0.0)/ISNULL(Importe,0.0))*100.0,0), SUM(ISNULL(AnticipoAplicar,0.0)), SUM(ISNULL(Retencion2,0.0)), ROUND((ISNULL(Retencion2,0.0)/ISNULL(Importe,0.0))*100.0,0) 
       FROM Cxc
      WHERE Empresa = @Empresa
        AND AnticipoSaldo > 0.0
        AND Estatus IN ('PENDIENTE','CONCLUIDO')
        AND Cliente = @Cliente
        AND ISNULL(AnticipoAplicar,0.0) > 0.0
        AND AnticipoAplicaID = @ID
      GROUP BY Moneda, ISNULL(TipoCambio,0.0), ROUND((ISNULL(Retencion,0.0)/ISNULL(Importe,0.0))*100.0,0), ROUND((ISNULL(Retencion2,0.0)/ISNULL(Importe,0.0))*100.0,0)
      
    OPEN crAnticiposFacturados
    FETCH NEXT FROM crAnticiposFacturados INTO @Moneda, @TipoCambio, @Importe, @Impuestos, @Retencion, @PorcentajeRetencion, @AnticipoAplicar, @Retencion2, @PorcentajeRetencion2
    WHILE @@FETCH_STATUS = 0 AND @Ok IS NULL
    BEGIN
    
	  IF @AnticipoAplicar >= @ImporteVenta SELECT @Ok = 30100, @OkRef = 'El Importe a Aplicar debe ser menor que el Importe Total del Movimiento'
      
      SET @FactorAplicar = @AnticipoAplicar / (@Importe + @Impuestos - @Retencion - @Retencion2)
      
      IF @MovMoneda = @Moneda
      BEGIN
        SET @MovAnticipoAplicar = @AnticipoAplicar
        SET @MovAnticipoAplicar = @MovAnticipoAplicar + (@Retencion * @FactorAplicar) + (@Retencion2 * @FactorAplicar)
        SET @Retencion = @MovAnticipoAplicar*(@PorcentajeRetencion/100.0)
        SET @Retencion2 = @MovAnticipoAplicar*(@PorcentajeRetencion2/100.0)
      END
      ELSE
      BEGIN
        SET @MovAnticipoAplicar = (@AnticipoAplicar*@TipoCambio)/@MovTipoCambio
        SET @MovAnticipoAplicar = @MovAnticipoAplicar + (((@Retencion*@TipoCambio)/@MovTipoCambio) * @FactorAplicar) + (((@Retencion2*@TipoCambio)/@MovTipoCambio) * @FactorAplicar)
        SET @Retencion = @MovAnticipoAplicar*(@PorcentajeRetencion/100.0)
        SET @Retencion2 = @MovAnticipoAplicar*(@PorcentajeRetencion2/100.0)
      END
      
	  SELECT @DescuentoLinea = ((@MovAnticipoAplicar * 100) / (@ImporteVenta - @RetencionVenta))
      
      UPDATE VentaD SET DescuentoLinea = @DescuentoLinea WHERE ID = @ID AND RenglonTipo <> 'C'
      
	  DECLARE crDescuentoImporte CURSOR FOR
	   SELECT RenglonID, DescuentosTotales
		 FROM VentaTCalc
	    WHERE Empresa = @Empresa
          AND ID = @ID
         
	  OPEN crDescuentoImporte
	  FETCH NEXT FROM crDescuentoImporte INTO @RenglonID, @DescuentoImporte
	  WHILE @@FETCH_STATUS = 0 AND @Ok IS NULL
	  BEGIN
		UPDATE VentaD
		   SET DescuentoImporte = @DescuentoImporte
		 WHERE ID = @ID
		   AND RenglonID = @RenglonID
		   AND RenglonTipo <> 'C'
	  
		FETCH NEXT FROM crDescuentoImporte INTO @RenglonID, @DescuentoImporte
	  END
	  CLOSE crDescuentoImporte
	  DEALLOCATE crDescuentoImporte
    
      SET @AsignoAnticipo = 1
      FETCH NEXT FROM crAnticiposFacturados INTO @Moneda, @TipoCambio, @Importe, @Impuestos, @Retencion, @PorcentajeRetencion, @AnticipoAplicar, @Retencion2, @PorcentajeRetencion2    
    END
    CLOSE crAnticiposFacturados
    DEALLOCATE crAnticiposFacturados

    IF @AsignoAnticipo = 1 UPDATE Venta SET AnticipoFacturadoTipoServicio = 1 WHERE ID = @ID
  END

  IF @Ok IS NULL
  BEGIN
    COMMIT TRANSACTION @Transaccion
    SELECT 'Proceso Exitoso...'
  END ELSE
  BEGIN
    ROLLBACK TRANSACTION @Transaccion
    SELECT 'ERROR ' + CONVERT(varchar,@Ok) + ': ' + (SELECT Descripcion FROM MensajeLista WHERE Mensaje = @Ok) + '. ' + ISNULL(@OkRef,'')
  END

END
GO
--EXEC spAplicarAnticiposCFDI 1, 149