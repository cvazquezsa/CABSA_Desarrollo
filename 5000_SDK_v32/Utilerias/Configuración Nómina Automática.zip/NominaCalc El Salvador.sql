EXEC xpConfigSQL
SET ANSI_NULLS OFF
GO
if exists (select * from sysobjects where id = object_id('dbo.spNominaCalcElSalvador') and type = 'P') drop procedure dbo.spNominaCalcElSalvador
go
CREATE PROCEDURE dbo.spNominaCalcElSalvador  
  
   @Empresa                        char(5),    
   @FechaTrabajo                   datetime,    
   @Sucursal                       int,    
   @ID                             int,    
   @Mov                            varchar(20),    
   @Moneda                         char(10),    
   @TipoCambio                     float,    
   @Personal                       char(10),    
   @FechaD                         datetime,    
   @FechaA                         datetime,    
   @PeriodoTipo                    varchar(20),    
   @CfgAjusteMensualISR            bit,    
   @CfgSueldoMinimo                varchar(20),    
   @CfgTablaVacaciones             varchar(50),    
   @CfgSubsidioIncapacidadEG       bit,    
   @CfgPrimaDominicalAuto          bit,    
   @CfgISRReglamentoAguinaldo      bit,    
   @CfgISRReglamentoPTU            bit,    
   @CfgISRLiquidacionSueldoMensual varchar(50),    
   @CfgFactorIntegracionAntiguedad varchar(20),    
   @CfgFactorIntegracionTabla      varchar(50),    
   @NomTipo                        varchar(50),    
   @NomCalcSDI                     bit,     
   @NomCxc                         varchar(20),    
   @RepartirDesde                  datetime,    
   @RepartirHasta                  datetime,    
   @RepartirIngresoTope            money,    
   @RepartirIngresoFactor          float,    
   @RepartirDiasFactor             float,    
   @CalendarioEsp                  bit,     
   @IncidenciaD                    datetime,     
   @IncidenciaA                    datetime,    
   @Ok                             int  OUTPUT,    
   @OkRef                          varchar(255) OUTPUT    
WITH ENCRYPTION 
AS BEGIN    
  DECLARE    
    @RedondeoMonetarios     int,    
    @Dia                    int,    
    @Mes                    int,    
    @Ano                    int,    
    @Calc                   float,    
    @CalcImporte            money,    
    @FechaDAno              int,    
    @FechaAAno              int,    
    @DescansaDomingos       bit,    
    @LaboraDomingos         bit,     
    @EsInicioMes            bit,    
    @EsFinMes               bit,    
    @EsBimestre             bit,    
    @PrimerDiaMes           datetime,    
    @UltimoDiaMes           datetime,    
    @PrimerDiaMesAnterior   datetime,    
    @PrimerDiaBimestre      datetime,    
    @UltimoDiaMesAnterior   datetime,    
    @PersonalEstatus        varchar(15),    
    @PersonalCtaDinero      varchar(20),    
    @SucursalTrabajo        int,    
    @SucursalTrabajoEstado  varchar(50),    
    @Categoria              varchar(50),    
    @Puesto                 varchar(50),    
    @Cliente                varchar(10),    
    @Jornada                varchar(20),    
    @JornadaDiasLibres      int,    
    @JornadaHoras           float,    
    @PersonalDiasPeriodo    varchar(20),    
    @ZonaEconomica          varchar(30),    
    @SMZ                    money,    
    @SMZTopeHorasDobles     float,    
    @SMZPrimaAntiguedad     float,    
    @SMDF                   money,    
    @PrimerDiaAno           datetime,    
    @PrimerDiaAnoReal       datetime,    
    @PrimerDiaAnoAnterior   datetime,    
    @UltimoDiaAno           datetime,    
    @UltimoDiaAnoAnterior   datetime,    
    @FechaAlta              datetime,    
    @FechaBaja              datetime,    
    @FechaAntiguedad        datetime,    
    @FechaAniversario       datetime,    
    @FechaDAntiguedad       datetime,    
    @FechaAAntiguedad       datetime,    
    @UltimoPago             datetime,    
    @EsSocio                bit,    
    @SDI                    money,    
    @SueldoPeriodo          money,    
    @SueldoDiario           money,    
    @SueldoMensual          money,    
    @SueldoMensualPersonal  money,    
    @DiasMes                float,    
    @DiasMesTrabajados      float,    
    @DiasBimestre           float,    
    @DiasBimestreTrabajados  float,    
    @DiasAno              float,    
    @DiasAnoISR            float,    
    @Aguinaldo            money,    
    @AguinaldoAcumulado  money,    
    @DiasAguinaldo         float,    
    @DiasAguinaldoSiguiente  float,    
    @DiasAguinaldoProporcion float,    
    @DiasAguinaldoSt       varchar(50),    
    @DiasPeriodo           float,    
    @DiasPeriodoEstandar    float,    
    @DiasTrabajados         float,    
    @DiasTrabajadosImporte  float,    
    @DiasNaturales         float,    
    @DiasNaturalesTrabajados float,    
    @DiasNaturalesOriginales float,    
    @DiasNaturalesDiferencia float,    
    @DiasPrimaAntiguedad    float,    
    @DomingosLaborados     float,    
    @Faltas                float,    
    @FaltasAcumulado       float,    
    @FaltasImporte         money,    
    @Incapacidades         float,     
    @IncapacidadesAcumulado  float,    
    @IncapacidadesImporte    money,    
    @ISR                   money,     
    @ISRCredito               money,     
    @ISR1                  money,     
    @ISR2                  money,     
    @ISRBaseAcumulado       money,     
    @ISRAcumuladoMensual    money,    
    @ISRAcumulado           money,     
    @ISRBruto              money,    
    @ISRVencimiento         datetime,        
    @ISRProyectado         money,    
    @ISRProyectado2         money,    
    @ISRBase              money,    
    @ISRBaseProyectado     money,    
    @ISRBaseProyectado2     money,    
    @ISRBaseMes            money,    
    @DiasAcumulados         float,    
    @ISRReglamentoBase     float,    
    @ISRReglamentoFactor    float,    
    @ISRSueldoMensual       money,    
    @ISRSueldoMensualReglamento money,    
    @ISRLiquidacion         money,    
    @ISRLiquidacionExcento  money,    
    @ISRLiquidacionGravable  money,    
    @ISRLiquidacionFactor    float,    
    @ISRLiquidacionBase     float,    
    @ISRAnual              money,    
    @ISRAjuste            money,    
    @ISRAjusteMax           money,    
    @ISRAjusteAnual         money,    
    @ISRTabla              varchar(50),    
    @IMSSBase              money,    
    @IMSSBaseAcumulado     money,    
    @IMSSBaseMes           money,    
    @ImpuestoEstatalBase    money,    
    @CedularBase           money,    
    @AcreedorIMSS           varchar(10),    
    @AcreedorISR           varchar(10),    
    @AcreedorInfonavit     varchar(10),    
    @AcreedorFonacot       varchar(10),    
    @AcreedorImpuestoEstatal varchar(10),    
    @IMSSVencimiento       datetime,    
    @IMSSVencimientoBimestre datetime,    
    @IMSSObrero            money,     
    @IMSSObreroCV           money,    
    @IMSSObreroSinCV        money,    
    @IMSSPatron            money,    
    @IMSSPatronMensual     money,     
    @IMSSPatronCV          money,     
    @IMSSPatronRetiro      money,    
    @IMSSPatronInfonavit    money,     
    @Antiguedad            float,    
    @AntiguedadFlotante     float,    
    @AntiguedadSiguiente    float,    
    @AntiguedadDia         int,     
    @AntiguedadMes         int,     
    @PrimaDominicalPct     float,    
    @PrimaDominical         money,    
    @PrimaVacacionalPct     float,    
    @Vacaciones            money,     
    @VacacionesTomadas     float,    
    @PrimaAntiguedad       money,    
    @PrimaVacacional       money,     
    @PrimaVacacionalProporcion money,     
    @PrimaVacacionalTope    money,     
    @PrimaVacacionalExcenta  money,     
    @DiasVacaciones         float,    
    @DiasVacaciones2         float,    
    @DiasVacaciones3        float,    
    @MasVacaciones             bit,    
    @DiasVacacionesProporcion float,    
    @DiasVacacionesSiguiente float,    
    @DiasVacacionesAcumulado float,     
    @FactorIntegracion     float,    
    @ImpuestoEstatal       money,     
    @ImpuestoEstatalPct     float,    
    @ImpuestoEstatalGastoOperacionPct float,      
    @ImpuestoEstatalVencimiento datetime,    
    @InfonavitObrero       money,    
    @InfonavitSDI           float,    
    @InfonavitSMGDF         float,    
    @PensionASueldoBruto    float,    
    @PensionASueldoBruto2    float,    
    @PensionASueldoBruto3    float,    
    @PensionASueldoNeto     float,    
    @PensionASueldoNeto2    float,    
    @PensionASueldoNeto3    float,    
    @PensionA              float,    
    @PensionA2              float,    
    @PensionA3              float,    
    @PensionAAcreedor       varchar(10),    
    @PensionAAcreedor2     varchar(10),    
    @PensionAAcreedor3     varchar(10),    
    @PercepcionBruta       money,    
    @CajaAhorro            money,    
    @CajaAhorroDesde       datetime,    
    @CajaAhorroHasta       datetime,    
    @CajaAhorroLiquidacion  datetime,    
    @CajaAhorroInteresTotalPct float,    
    @CajaAhorroAcumulado    money,    
    @CajaAhorroAcumuladoDias float,    
    @CajaAhorroIngresosTopados money,    
    @CajaAhorroDiasTrabajados  money,    
    @FondoAhorroPct         float,    
    @FondoAhorro           money,    
    @FondoAhorroAnticipoPct  float,    
    @FondoAhorroDesde       datetime,    
    @FondoAhorroHasta       datetime,    
    @FondoAhorroLiquidacion  datetime,    
    @FondoAhorroInteresTotal money,     
    @FondoAhorroInteresTotalPct float,    
    @FondoAhorroDiasAcumulado  float,    
    @FondoAhorroAcumulado    money,    
    @FondoAhorroAcumuladoDias float,    
    @FondoAhorroPatronAcumulado money,    
    @FondoAhorroPatronAcumuladoDias float,    
    @FondoAhorroAnticipoAcumulado money,    
    @FondoAhorroAnticipoAcumuladoDias float,    
    @FondoAhorroIngresosTopados money,    
    @FondoAhorroDiasTrabajados money,    
    @EsAniversario           bit,    
    @OtorgarDiasVacacionesAniversario bit,    
    @OtorgarPrimaVacacionalAniversario bit,    
    @TieneValesDespensa       bit,    
    @ValesDespensaPct         float,    
    @ValesDespensaImporte      money,    
    @PremioPuntualidadPct      float,    
    @PremioAsistenciaPct      float,    
    @PersonalNeto             money,    
    @PersonalPercepciones      money,    
    @PersonalDeducciones      money,    
    @SueldoMinimo             money,    
    @IndemnizacionPct         float,    
    @Indemnizacion           money,    
    @IndemnizacionTope       money,    
    @Indemnizacion3Meses      money,    
    @Indemnizacion20Dias      money,    
    @SueldoVariable           money,     
    @SueldoVariableAcumulado  money,    
    @SueldoVariableDias       float,    
    @SueldoVariablePromedio    money,    
    @SueldoVariablePTUDesde    datetime,    
    @SueldoVariablePTUHasta    datetime,    
    @SueldoVariableAguinaldoD   datetime,    
    @SueldoVariableAguinaldoA   datetime,    
    @SueldoVariableAguinaldoD1 datetime,    
    @SueldoVariableAguinaldoA1 datetime,    
    @SueldoVariableVacacionesD datetime,    
    @SueldoVariableVacacionesA datetime,    
    @PTUIngresosTopados       money,    
    @PTUDiasTrabajados       money,    
    @DescuentoISRAjusteAnualPct float,    
    @FiniquitoNetoEnCeros      bit,    
    @ConSueldoMinimo         bit,    
    @BeneficiarioSueldoNeto    varchar(100),    
    @MontoNoGravablePersonal   money,    
    @MontoNoGravableConyugue   money,    
    @MontoNoGravableDependientes  money,    
    @TieneConyugue            bit,    
    @CantidadDependientes     float,    
    @SSEmpleado              money,    
    @SSEmpleadoPct            float,    
    @SSJubiladoPct              float,    
    @SSPatron                 money,    
    @SSPatronPct              float,    
    @SEEmpleado                      money,    
    @SEEmpleadoPct                    float,    
    @SEPatron                         money,    
    @SEPatronPct                      float,    
    @SEEmpleadoAnualizado               money,    
    @RiesgoProfesional                money,    
    @RiesgoProfesionalPct             float,    
    @PctISRGR                           float,    
    @AcumuladoDiasMesXII                int,    
    @NumeroDeSemanasPorAntiguedad       float,    
    @MesesPorAno                        float,    
    @PctPrimaAntiguedad                 float,    
    @PctPrimaVacacional                 float,    
    @IngresoCincoAnosPrima              money,    
    @IngresoCincoAnosPrimaRemanente     money,    
    @SemanasPorMes                      float,    
    @Fecha                              datetime,    
    @AcumuladoSE                        money,    
    @DiasAcumuladosSE                   float,    
    @AcumuladoDiasVacaciones            int,    
    @GastosAcumulado                    money,    
    @GastosAcumuladoXIII                money,    
    @AguinaldoA                         money,    
    @DiasFaltantes                      money,    
    @Periodos                           float,    
    @FactorAusentismo                   float,    
    @SueldoDiarioVariable      money,    
    @PreavisoImporte                    money,    
    @Preaviso                           bit,    
    @PAdicionalIndemni                  bit,    
    @PorcentajePAdicionalIndemni        money,    
    @Gastos                             money,    
    @AcumuladoAguinaldo                 money,    
    @AcumuladoVacacionesGR              money,    
    @Valor                              money,    
    @FechaIniVacaciones                 datetime,    
    @FechaFinVacaciones                 datetime,    
    @PeriodosPagadosPersonal            int,    
    @PeriodosPagadosEmpresa             int,    
    @TipoCalculoISR                     varchar(20),    
    @SEBase                             money,                                                     
    @RataHora                           money,    
    @HorasSemana                        float,    
    @BaseISRExtra                       money,                              
    @ISRFijoPeriodo                     money,                              
    @BasePrimaAntiguedad                money,    
    @BaseIndemnizacion                  money,    
    @BasePreelaborada                   money,    
    @BaseSeguroEducativo                money,    
    @BaseVacaciones                     money,    
    @ImporteComisiones                  money,           
    @ImporteViaticos                    money,    
    @ImportePrimProd                    money,    
    @FrecuenciaComisiones               varchar(20),           
    @FrecuenciaViaticos                 varchar(20),    
    @FrecuenciaPrimProd                 varchar(20),    
    @Sueldo                             money,    
    @SindicatoMetodo                    varchar(50),    
    @SindicatoAcreedorPr                varchar(50),    
    @SindicatoAcreedor$                 varchar(50),    
    @SindicatoFrecuencia                varchar(50),    
    @AdministradoraFondoPension         varchar(50),    
    @Sindicato$                         money,    
    @Sindicatopr                        float,    
    @SindicatoImporte                   money,    
    @SueldomesIndem                     money,    
    @SueldoSemanaPrima                  money,    
    @SemanasLiq                         float,    
    @SemanasIndem                       float,    
    @UsaPrima                           bit,    
    @UsaIndemnizacion                   bit,    
    @GastosLiquidacion                  varchar(50),    
    @LiquidacionPanama                  varchar(50),    
    @Dias                               int,    
    @MaxID                           int,    
    @MaxRID                         float,    
    @IncapacidadesD                  int,    
    @Compromisos                        varchar(50),    
    @Cantidad                           float,    
    @Importe                            money,    
    @RIDImporte                         money,    
    @RID                                int,    
    @DiasTrabajados2                    float,    
    @HorasPeriodo                       float,    
    @HorasMes                           float,    
    @FechaD1                            datetime,    
    @FechaA1                            datetime,    
    @MovTipo                            varchar(20),    
    @IncentivoAsistencia               bit,    
    @AguinaldoNavidad                 bit,    
    @ImporteInCentivoAsistencia         money,    
    @Ejercicio                          int,    
    @EjercicioAnterior                  int,    
    @AdeudoTotalVacaciones              float,    
    @ImporteAdeudoTotalVacaciones       money,    
    @Import                             money,    
    @TopeIMSS                           money,    
    @ImporteVacaciones                  money,    
    @pctAFPEmpleadoComision             float,     
    @pctAFPEmpleadoCot                  float,    
    @pctAFPPatron                       float,    
    @afpTopeMinimo                      float,    
    @afpTopeMAximo                      float,    
    @AFPEmpleadoComision                float,     
    @AFPEmpleadoCot                     float,    
    @AFPPatron                          float,    
    @AFPEmpleado             float,    
    @AFPBASE                            money,    
    @ValorC                             varchar(50),    
    @BaseAguinaldo                      varchar(50),    
    @Aguinaldo2                         money,    
    @pctPagoAguinaldo                   float,   
    @IPSFAEmpleadoComision        float,  
    @IPSFAPatron         float  
    
  SET DATEFIRST 7  
    
  SELECT @MovTipo = Clave FROM Movtipo WHERE Modulo='NOM' AND Mov=@Mov    
  SELECT @FechaD1 = @FechaD,     
         @FechaA1 = @FechaA    
    
    
  SELECT @EsInicioMes = 0, @EsFinMes = 0, @EsBimestre = 0,            @Incapacidades = 0,     
         @Faltas = 0, @EsAniversario = 0, @DiasNaturalesDiferencia = 0,    
         @ISRBase = 0.0, @IMSSBase = 0.0, @ImpuestoEstatalBase = 0.0, @CedularBase = 0.0,    
         @ISR = 0.0, @IMSSObrero = 0.0,   @IMSSPatron = 0.0,          @SueldoMinimo = 0.0,     
         @DomingosLaborados = 0.0,        @DiasAguinaldo = 0.0,       @DiasAguinaldoSiguiente = 0.0,    
         @SueldoVariable = 0.0,           @AcumuladodiasmesXII = 0,   @SEEmpleadoAnualizado = 0    
    
  SELECT @SucursalTrabajo       = p.SucursalTrabajo,    
         @SucursalTrabajoEstado = s.Estado,    
         @Categoria           = p.Categoria,    
         @Puesto              = p.Puesto,    
         @Cliente              = p.Cliente,    
         @PersonalEstatus       = p.Estatus,    
         @PersonalCtaDinero     = p.CtaDinero,    
         @SDI                 = ISNULL(p.SDI, 0.0),    
         @SueldoDiario        = ISNULL(p.SueldoDiario, 0.0),    
         @FechaAlta            = p.FechaAlta,    
         @FechaAntiguedad       = ISNULL(p.FechaAntiguedad, p.FechaAlta),    
         @FechaBaja            = p.FechaBaja,    
         @Jornada              = p.Jornada,    
         @JornadaHoras        = NULLIF(j.HorasPromedio, 0.0),    
         @PersonalDiasPeriodo   = UPPER(p.DiasPeriodo),    
         @ZonaEconomica        = p.ZonaEconomica,    
         @UltimoPago          = p.UltimoPago,    
         @EsSocio              = ISNULL(p.EsSocio, 0),    
         @DiasPeriodoEstandar   = ISNULL(pt.DiasPeriodo, 0),    
         @DescansaDomingos     = ISNULL(j.Domingo, 0),    
         @IndemnizacionPct     = ISNULL(p.IndemnizacionPct, 100.0),    
         @CantidadDependientes  = ISNULL(p.Dependientes, 0),    
         @FactorAusentismo      = NULLIF(j.FactorAusentismo, 0.0),    
         @SueldoMensual         = ISNULL(p.SueldoMensual, 0),    
         @SueldoMensualPersonal = ISNULL(p.SueldoMensual, 0),    
--         @RataHora              = ISNULL(p.RataHora, 0),    
         @HorasSemana           = ISNULL(j.HorasSemana, 0)--,    
--         @ISRFijoPeriodo        = ISNULL(p.ISRFijoPeriodo, 0)                      
    FROM Personal p    
    LEFT OUTER JOIN PeriodoTipo pt ON pt.PeriodoTipo = p.PeriodoTipo    
    LEFT OUTER JOIN Jornada j      ON j.Jornada      = p.Jornada     
    LEFT OUTER JOIN Sucursal s     ON s.Sucursal     = p.SucursalTrabajo    
   WHERE p.Personal = @Personal AND p.PeriodoTipo = @PeriodoTipo    
    
  IF @FechaA     < @FechaAlta SELECT @Ok = 45010    
    
  IF  @MovTipo ='NOM.N'    
    IF @UltimoPago > @FechaA    SELECT @Ok = 45020    
    
  SELECT @DiasNaturalesOriginales = DATEDIFF(day, @FechaD, @FechaA) + 1    
    
  IF @UltimoPago IS NULL SELECT @FechaD = @FechaAlta     
    
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')    
  BEGIN    
    UPDATE Nomina SET Concepto = @LiquidacionPanama WHERE ID = @ID    
    IF @UltimoPago IS NULL SELECT @FechaD = @FechaAlta ELSE SELECT @FechaD = DATEADD(day, 1, @UltimoPago)    
    IF @PersonalEstatus = 'BAJA' SELECT @FechaA = ISNULL(@FechaBaja, @FechaTrabajo) ELSE SELECT @FechaA = FechaOrigen FROM Nomina WHERE ID = @ID    
  END     
  IF @UltimoPago IS NULL SELECT @OK=1, @OkRef ='El empleado ('+@Personal+') Necesita Fecha de ULTIMOPAGO.'    
  IF @CalendarioEsp = 0 SELECT @IncidenciaD = @FechaD, @IncidenciaA = @FechaA    
    
  IF @NomTipo IN ('VACACIONES')    
  BEGIN    
 SELECT @DiasVacaciones =@DiasVacaciones     
/*    SELECT @DiasVacaciones = SUM (d.Cantidad)    
      FROM IncidenciaD d    
      JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'    
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto    
      JOIN CFGNominaConcepto cfg ON nc.NominaConcepto = cfg.NominaConcepto     
     WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA    
       AND cfg.ClaveInterna = 'VacacionesTomadas'    
*/    
/*    IF ISNULL(@DiasVacaciones,0) >0     
    BEGIN    
      SELECT @FechaIniVacaciones = Min(i.FechaD)    
        FROM IncidenciaD d    
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus in( 'PENDIENTE', 'CONCLUIDO' )    
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto --AND RequiereDiasTrabajados = 0    
        JOIN CFGNominaConcepto cfg ON nc.NominaConcepto = cfg.NominaConcepto     
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA    
         AND cfg.ClaveInterna = 'Vacaciones'    
     
     SELECT @FechaFinVacaciones = Max(i.FechaA)    
        FROM IncidenciaD d    
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus in( 'PENDIENTE', 'CONCLUIDO' )    
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto --AND RequiereDiasTrabajados = 0    
        JOIN CFGNominaConcepto cfg ON nc.NominaConcepto = cfg.NominaConcepto     
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA    
         AND cfg.ClaveInterna = 'Vacaciones'    
    
      SELECT @DiasVacaciones=0--  se usa mas abajo y traeria un valor basura    
    END ELSE    
      SELECT @OK=1, @OKREF = 'El Empleado' + @Personal + 'No tiene vacaciones capturadas'   */    
  END ELSE    
  IF @NomTipo IN ('NORMAL')    
  BEGIN    
    SELECT @DiasVacaciones = @DiasVacaciones    
/*    
    SELECT @DiasVacaciones = SUM (d.Cantidad)    
      FROM IncidenciaD d    
      JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'    
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND RequiereDiasTrabajados = 0    
      JOIN CFGNominaConcepto cfg ON nc.NominaConcepto = cfg.NominaConcepto     
     WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA    
       AND cfg.ClaveInterna = 'VacacionesTomadas'    
    
    IF ISNULL(@DiasVacaciones,0) > 0     
      SELECT @OK=1, @OKREF = '<BR> El Empleado '+ @Personal +' Tiene Vacaciones Pendientes<BR> Tienes Que afectar la planilla de VACACIONES <BR> antes que la NORMAL.'       
*/    
  END    
  SELECT @Ejercicio = YEAR(@IncidenciaA)    
  SELECT @EjercicioAnterior = @Ejercicio - 1    
  SELECT @RedondeoMonetarios = RedondeoMonetarios FROM Version    
  SELECT @SMDF = SueldoMinimo FROM ZonaEconomica WHERE Zona = 'A'    
  SELECT @SMZ =  SueldoMinimo FROM ZonaEconomica WHERE Zona = @ZonaEconomica    
    
--  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Tipo de Calculo ISR',           @TipoCalculoISR OUTPUT     
    
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Mes',               @DiasMes OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Ano',                @DiasAno OUTPUT     
--  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Ano ISR',            @DiasAnoISR OUTPUT     
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Aguinaldo',          @DiasAguinaldoSt OUTPUT       
--  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Prima Dominical',          @PrimaDominicalPct OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Prima Vacacional',        @PrimaVacacionalPct OUTPUT     
--  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor SHCP',             @AcreedorISR OUTPUT     
 -- EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor IMSS',             @AcreedorIMSS OUTPUT     
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia',        @PensionAAcreedor OUTPUT     
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia 2',      @PensionAAcreedor2 OUTPUT     
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia 3',      @PensionAAcreedor3 OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto',   @PensionASueldoBruto OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto 2', @PensionASueldoBruto2 OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto 3', @PensionASueldoBruto3 OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto',    @PensionASueldoNeto OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto 2',  @PensionASueldoNeto2 OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto 3',  @PensionASueldoNeto3 OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Pension Alimenticia',    @PensionA OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Pension Alimenticia 2',  @PensionA2 OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Pension Alimenticia 3',  @PensionA3 OUTPUT     
    
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Tope Seguro Social',  @TopeIMSS OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Prima Vacacional',    @pctPrimaVacacional OUTPUT     
    
--EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Gastos Representacion liquidacion(S/N)',  @GastosLiquidacion OUTPUT     
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Beneficiario Sueldo Neto',   @BeneficiarioSueldoNeto OUTPUT     
/* EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ No Gravable Personal',   @MontoNoGravablePersonal OUTPUT     
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ No Gravable Conyugue',   @MontoNoGravableConyugue OUTPUT     
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ No Gravable Dependientes',  @MontoNoGravableDependientes OUTPUT     
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Tiene Conyugue (S/N)',   @TieneConyugue OUTPUT     
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Usar Incentivo Asistencia(S/N)',   @IncentivoAsistencia OUTPUT     
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Usar Aguinaldo de Navidad(S/N)',   @AguinaldoNavidad OUTPUT */    
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Dias Vacaciones Aniversario (S/N)',   @OtorgarDiasVacacionesAniversario OUTPUT     
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Vacaciones',     @DiasVacaciones OUTPUT     
--  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Cuenta',   @BeneficiarioSueldoNeto OUTPUT     
    
    
--  IF @TieneConyugue = 0  SELECT @MontoNoGravableConyugue = 0.0    
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Tabla ISR',    @ISRTabla OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Social Empleado',   @SSEmpleadoPct OUTPUT     
--  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Social Jubilado',   @SSJubiladoPct OUTPUT     
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Base para Aguinaldo',   @BaseAguinaldo OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% de Aguinaldo a Pagar',   @pctPagoAguinaldo OUTPUT     
    
    
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Social Parton',    @SSPatronPct OUTPUT     
--  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Educativo Empleado',   @SEEmpleadoPct OUTPUT     
--  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Educativo Parton',   @SEPatronPct OUTPUT     
 -- EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Riesgo Profesional',    @RiesgoProfesionalPct OUTPUT     
--  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% ISR GR',            @PctISRGR OUTPUT     
    
--  IF EXISTS (SELECT * FROM Personal WHERE Tipo='Jubilado' AND Personal = @Personal) SELECT @SSEmpleadoPct = @SSJubiladoPct, @SEEmpleadoPct=0, @SEPatronPct=0    
    
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Importe Comisiones',   @ImporteComisiones OUTPUT     
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Importe PRIM.PRODUCC.', @ImportePrimProd OUTPUT     
  -- EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Importe VIATICOS',     @ImporteViaticos OUTPUT     
  -- EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Frecuencia Comisiones',     @FrecuenciaComisiones OUTPUT     
  -- EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Frecuencia PRIM.PRODUCC.',   @FrecuenciaPrimProd OUTPUT     
  -- EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Frecuencia VIATICOS',       @FrecuenciaViaticos OUTPUT     
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Sindicato',     @Sindicato$ OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Sindicato',       @SindicatoPr OUTPUT     
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Metodo % Sindicato',    @SindicatoMetodo OUTPUT     
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Frecuencia % Sindicato', @SindicatoFrecuencia OUTPUT      
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Acreedor % Sindicato',   @SindicatoAcreedorPr OUTPUT     
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Acreedor $ Sindicato',   @SindicatoAcreedor$ OUTPUT     
    
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Administradora Fondo Pension',   @AdministradoraFondoPension OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'AFP Tope Minimo',       @afpTopeMinimo OUTPUT     
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'AFP Tope Maximo',       @afpTopeMaximo OUTPUT     
      
  IF @AdministradoraFondoPension ='CONFIA'    
  BEGIN    
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% AFP Confia Empleado Comision',  @pctAFPEmpleadoComision OUTPUT     
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% AFP Confia Empleado Cot',       @pctAFPEmpleadoCot OUTPUT     
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% AFP Confia Patron',             @pctAFPPatron OUTPUT     
  END    
    
  IF @AdministradoraFondoPension ='CRECER'    
  BEGIN    
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% AFP Crecer Empleado Comision',  @pctAFPEmpleadoComision OUTPUT     
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% AFP Crecer Empleado Cot',       @pctAFPEmpleadoCot OUTPUT     
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% AFP Crecer Patron',             @pctAFPPatron OUTPUT     
  END      
    
  IF @AdministradoraFondoPension ='PUBLICO'    
  BEGIN    
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% AFP Publico Empleado Cot',     @pctAFPEmpleadoCot OUTPUT     
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% AFP Publico Patron',           @pctAFPPatron OUTPUT     
    SELECT @pctAFPEmpleadoComision = 0    
  END      
  
  IF @AdministradoraFondoPension ='IPSFA'    
  BEGIN    
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% IPSFA Empleado Comision',  @IPSFAEmpleadoComision OUTPUT     
    EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% IPSFA Patron',             @IPSFAPatron OUTPUT     
  END      
  
  
  SELECT @Dia = DAY(@FechaA), @Mes = MONTH(@FechaA), @Ano = YEAR(@FechaA)    
  EXEC spIntToDateTime  1,  1, @Ano, @PrimerDiaAnoREAL OUTPUT    
  SELECT @PrimerDiaAno=@PrimerDiaAnoREAL    
  EXEC spIntToDateTime 31, 12, @Ano, @UltimoDiaAno OUTPUT    
  SELECT @PrimerDiaAnoAnterior = DATEADD(year, -1, @PrimerDiaAno),  @UltimoDiaAnoAnterior = DATEADD(year, -1, @UltimoDiaAno)    
  IF @FechaAntiguedad > @PrimerDiaAno SELECT @PrimerDiaAno = @FechaAntiguedad    
  IF ISNUMERIC(@DiasAguinaldoSt) = 1     
    SELECT @DiasAguinaldo = CONVERT(float, @DiasAguinaldoSt),     
           @DiasAguinaldoSiguiente = CONVERT(float, @DiasAguinaldoSt)    
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')    
    SELECT @SueldoMinimo = 0.0    
  ELSE    
  IF @CfgSueldoMinimo = 'OFICIAL'     
    SELECT @SueldoMinimo = @SMDF * @DiasMes * 1.3    
  IF @FechaAlta > @FechaD SELECT @FechaD = @FechaAlta    
  SELECT @DiasNaturales = DATEDIFF(day, @FechaD, @FechaA) + 1    
  SELECT @DiasNaturalesDiferencia = @DiasNaturalesOriginales - @DiasNaturales    
  SELECT @DiasPeriodo = @DiasNaturales    
  IF @NomTipo = 'NORMAL'    
  BEGIN    
    IF @PersonalDiasPeriodo = 'DIAS PERIODO'    
      SELECT @DiasPeriodo = @DiasPeriodoEstandar - @DiasNaturalesDiferencia    
    ELSE    
    IF @PersonalDiasPeriodo = 'DIAS JORNADA'    
    BEGIN    
      EXEC spJornadaDiasLibres @Jornada, @FechaD, @FechaA, @JornadaDiasLibres OUTPUT    
      SELECT @DiasPeriodo = dbo.fnMayor(0, @DiasNaturales - @JornadaDiasLibres)    
    END    
    ELSE BEGIN     
      IF @PersonalDiasPeriodo = 'RATA POR HORA'    
      BEGIN    
          
        SELECT @HorasPeriodo = ISNULL(SUM(DATEDIFF(mi, Entrada, Salida)/60.0),0)     
          FROM PersonalJornadaTiemposPanama     
         WHERE Entrada BETWEEN @FechaD1 and @FechaA1    
           AND Personal = @Personal    
    
        SELECT @DiasPeriodo= ISNULL(COUNT(Entrada),0)     
          FROM PersonalJornadaTiemposPanama     
         WHERE Entrada BETWEEN @FechaD1 and @FechaA1    
           AND Personal = @Personal    
    
    
        IF ISNULL(@HorasPeriodo,0) = 0     
        BEGIN     
          SELECT @HorasPeriodo= ISNULL(SUM(DATEDIFF(mi, Entrada, Salida)/60.0),0)     
            FROM JornadaTiempo     
           WHERE Entrada BETWEEN @FechaD1 and @FechaA1    
             AND Jornada = @Jornada    
    
          SELECT @DiasPeriodo = ISNULL(COUNT( Entrada),0)     
            FROM JornadaTiempo     
           WHERE Entrada BETWEEN @FechaD1 and @FechaA1    
             AND Jornada = @Jornada    
        END     
-- si no encontre suficentes horas en las tablas tomo el "estandar"    
        IF ISNULL(@HorasPeriodo,0) < 70     
          SELECT @HorasPeriodo = @HorasSemana * 4.33 / 2.0    
    
        IF ISNULL(@HorasPeriodo,0) < 70     
        BEGIN    
          SELECT @OK=1, @OKRef='la Jornada(' + @Jornada +') esta mal generada para el personal -' + @Personal    
          RETURN    
        END    
      END    
    END    
  END    
  SELECT @Antiguedad = dbo.fnAntiguedad(@FechaAntiguedad, @FechaA)    
  SELECT @AntiguedadSiguiente = dbo.fnAntiguedad(@FechaAntiguedad, @FechaA) + 1      
  SELECT @AntiguedadFlotante = ROUND(dbo.fnAntiguedadFloat(@FechaAntiguedad, @FechaA),2)    
    
  IF @NomTipo = 'AGUINALDO'    
  BEGIN    
    EXEC spPersonalPropValor @Empresa, @Sucursal, @Categoria, @Puesto, @Personal, '# Dias Aguinaldo', @ValorC OUTPUT    
    IF (SELECT ISNUMERIC(@ValorC)  )=1    
      SELECT @DiasAguinaldo = CONVERT(float, @ValorC)        
    ELSE    
      SELECT @DiasAguinaldo = Valor FROM TablaNumD WHERE TablaNum=@ValorC AND Numero = @Antiguedad    
    
    SELECT  @DiasPeriodo = @DiasAguinaldo    
  END    
    
  EXEC spFechaAniversario @FechaAntiguedad, @FechaA, @FechaAniversario OUTPUT    
  /* Para que pague la quincena de maximo 15 dias y no de 16 */    
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') AND @PeriodoTipo IN ('QUINCENAL', 'MENSUAL') AND (SELECT dbo.fnEsFinMes(@FechaA)) = 0    
   SELECT @DiasPeriodo = @DiasNaturales    
    
  SELECT @DiasMes = NULLIF(@DiasMes, 0), @DiasMesTrabajados = NULLIF(@DiasMesTrabajados, 0), @DiasBimestre = NULLIF(@DiasBimestre, 0),    
         @DiasBimestreTrabajados = NULLIF(@DiasBimestreTrabajados, 0), @DiasAno = NULLIF(@DiasAno, 0),     
         @DiasPeriodo = NULLIF(@DiasPeriodo, 0), @DiasTrabajados = NULLIF(@DiasTrabajados, 0), @DiasNaturales = NULLIF(@DiasNaturales, 0),    
         @DiasNaturalesTrabajados = NULLIF(@DiasNaturalesTrabajados, 0), @DiasNaturalesOriginales = NULLIF(@DiasNaturalesOriginales, 0),    
         @DiasNaturalesDiferencia = NULLIF(@DiasNaturalesDiferencia, 0)    
    
--- ojo    
  SELECT @AntiguedadDia = DAY(@FechaAntiguedad), @AntiguedadMes = MONTH(@FechaAntiguedad), @FechaDAno = YEAR(@FechaD), @FechaAAno = YEAR(@FechaA)    
  EXEC spIntToDateTime @AntiguedadDia, @AntiguedadMes, @FechaDAno, @FechaDAntiguedad OUTPUT    
  EXEC spIntToDateTime @AntiguedadDia, @AntiguedadMes, @FechaAAno, @FechaAAntiguedad OUTPUT    
  IF ISNUMERIC(@DiasVacaciones) = 0    
  BEGIN    
  EXEC spTablaNum @DiasVacaciones, @Antiguedad, @DiasVacaciones OUTPUT    
    EXEC spTablaNum @CfgTablaVacaciones, @AntiguedadSiguiente, @DiasVacacionesSiguiente OUTPUT    
  END    
  IF @Antiguedad > 0 AND (@FechaDAntiguedad BETWEEN @FechaD AND @FechaA OR @FechaAAntiguedad BETWEEN @FechaD AND @FechaA)    
    SELECT @EsAniversario = 1    
    
  IF @EsAniversario = 1 AND @NomTipo = 'NORMAL' -- no sepaga la nomina normal en el aniversario se tiene que pagar la de vacaciones    
    RETURN     
    
  IF @EsAniversario = 0 AND @NomTipo = 'Vacaciones' -- no sepaga nada si no es aniversario     
    RETURN     
    
  IF ISNUMERIC(@DiasAguinaldoSt) = 0     
  BEGIN    
    EXEC spTablaNum @DiasAguinaldoSt, @Antiguedad,          @DiasAguinaldo OUTPUT    
    EXEC spTablaNum @DiasAguinaldoSt, @AntiguedadSiguiente, @DiasAguinaldoSiguiente OUTPUT    
  END    
    
  SELECT @IndemnizacionTope = @SMZ*90*ROUND(@AntiguedadFlotante, 0)    
  SELECT @PrimaVacacional = @SueldoDiario * @DiasVacaciones * (@PrimaVacacionalPct/100.0)    
    
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')    
  BEGIN    
    SELECT @DiasVacacionesProporcion = @DiasVacacionesSiguiente * dbo.fnAntiguedadFloat(@FechaAniversario, @FechaA)    
    SELECT @PrimaVacacionalProporcion = @SueldoDiario * @DiasVacacionesProporcion * (@PrimaVacacionalPct/100.0)    
  END     
 --- SELECT @SueldoMensual = @SueldoDiario * @DiasMes    
  SELECT @PrimerDiaMes  = DATEADD(day, 1-DAY(@FechaD), @FechaD)    
  SELECT @UltimoDiaMes = DATEADD(dd, -1, DATEADD(mm, 1, @PrimerDiaMes))    
  SELECT @PrimerDiaMesAnterior = DATEADD(month, -1, @PrimerDiaMes)    
  SELECT @UltimoDiaMesAnterior = DATEADD(day, -1, @PrimerDiaMes)    
  SELECT @ISRVencimiento = DATEADD(day, 16, DATEADD(month, 1, @PrimerDiaMes))    
  SELECT @IMSSVencimiento = @ISRVencimiento, @IMSSVencimientoBimestre = @ISRVencimiento, @ImpuestoEstatalVencimiento = @ISRVencimiento    
  IF MONTH(@FechaA) % 2 <> 0 SELECT @IMSSVencimientoBimestre = DATEADD(month, 1, @IMSSVencimientoBimestre)    
  IF MONTH(@FechaA) <> MONTH(DATEADD(day, @DiasNaturalesOriginales, @FechaA))     
  BEGIN    
    SELECT @EsFinMes = 1      
    IF MONTH(@FechaA) % 2 = 0 SELECT @EsBimestre = 1, @PrimerDiaBimestre = DATEADD(month, -1, @PrimerDiaMes)    
  END    
     
  IF @PrimerDiaMes BETWEEN @FechaD AND @FechaA SELECT @EsInicioMes = 1    
     
  IF @NomTipo IN ('NORMAL', 'AJUSTE', 'FINIQUITO', 'LIQUIDACION', 'VACACIONES')    
  BEGIN    
--- gatos representacion     
      IF @DiasPeriodo >= 13 AND MONTH(@FechaD1) = 2 AND @EsFinMes = 1 -- para el caso de febrero 28    
        SELECT @Gastos = @SDI / 30.0 * @DiasPeriodoEstandar    
      ELSE    
        SELECT @Gastos = @SDI / 30.0 * DBO.fnMenor(@DiasPeriodoEstandar, @DiasPeriodo)    
-- Sueldo    
    IF @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')    
    BEGIN    
      IF @PeriodoTipo = 'Quincenal' AND @NomTipo IN ('NORMAL')     
      BEGIN    
        IF @PersonalDiasPeriodo = 'RATA POR HORA'      
        BEGIN    
    
          SELECT @SueldoMensual =  ROUND(dbo.fnSalvadorSueldoMensual(@Personal, @FechaD1),2)    
    
--          SELECT @SueldoPeriodo = dbo.fnMayor(@RataHora * @HorasPeriodo, dbo.fnSalvadorSueldoMensual(@Personal, @FechaD1) / 2.0)    
          SELECT @SueldoPeriodo = @RataHora * @HorasPeriodo    
        END    
        ELSE            
          SELECT @SueldoPeriodo = ROUND(dbo.fnSalvadorSueldoMensual(@Personal, @FechaD1) / 2.0,2)    
      END    
      ELSE      
        IF @PeriodoTipo = 'Semanal' AND @NomTipo IN ('NORMAL')    
          SELECT @SueldoPeriodo = @RataHora * @HorasPeriodo    
-- select @SueldoPeriodo         
      IF @EsFinMes = 1 AND @PeriodoTipo = 'Quincenal'-- esto es para Ajustar los centavo para que cuadre conel sueldo mensual al centavo    
      BEGIN    
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Sueldo', @PrimerDiames, @FechaA, NULL,@sueldo OUTPUT, @DiasTrabajados OUTPUT     
        SELECT @Sueldo= ISNULL(@Sueldo,0)    
        IF ABS(ROUND(@SueldoMensual,2) -( ROUND(ROUND(@Sueldo,2) + ROUND(@SueldoPeriodo,2),2))) < 0.05 AND @PersonalDiasPeriodo <> 'RATA POR HORA'    
          SELECT @SueldoPeriodo =ROUND(    ROUND(@SueldoPeriodo,2) +ROUND(@SueldoMensual,2) -( ROUND(ROUND(@Sueldo,2) + ROUND(@SueldoPeriodo,2),2)),2)    
      END    
      IF @NomTipo IN ('LIQUIDACION')    
      BEGIN    
--        EXEC spDiasLibresSalida @Jornada, @Fechad, @FechaA, @Dias output    
        SELECT @DiasPeriodo = ABS(DATEDIFF( DAY, @FechaA, @FechaD)) + 1 - @Dias    
        SELECT @SueldoPeriodo = @DiasPeriodo * @SueldoDiario -- ojo rata por hora?    
      END    
    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Sueldo', @Empresa, @Personal, @DiasPeriodo, @SueldoPeriodo    
    
/*      IF @NomTipo IN ('LIQUIDACION')    
      BEGIN    
        IF @GastosLiquidacion ='S'     
           EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, NULL, @Gastos    
      END ELSE    
        IF @NomTipo ='AGUINALDO'    
          EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacionXIII', @Empresa, @Personal, NULL, @Gastos    
        ELSE    
           EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, NULL, @Gastos    
   */            
      SELECT @Valor = 0    
      IF @FrecuenciaComisiones = 'Cada Nomina' SELECT @Valor = @ImporteComisiones / 2.0    
      IF @FrecuenciaComisiones = 'Inicio mes' and @FechaA = 15 SELECT @Valor = @ImporteComisiones      
      IF @FrecuenciaComisiones = 'Fin mes' and @FechaA <> 15   SELECT @Valor = @ImporteComisiones      
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ComisionesFijos', @Empresa, @Personal, NULL, @Valor    
      SELECT @Valor = 0    
      IF @FrecuenciaViaticos = 'Cada Nomina' SELECT @Valor = @ImporteViaticos / 2.0    
      IF @FrecuenciaViaticos = 'Inicio mes' and @FechaA = 15 SELECT @Valor = @ImporteViaticos    
      IF @FrecuenciaViaticos = 'Fin mes' and @FechaA <> 15   SELECT @Valor = @ImporteViaticos    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ViaticosFijos', @Empresa, @Personal, NULL,   @Valor    
      SELECT @Valor = 0    
      IF @FrecuenciaPrimProd = 'Cada Nomina' SELECT @Valor = @ImportePrimProd / 2.0    
      IF @FrecuenciaPrimProd = 'Inicio mes' and @FechaA = 15 SELECT @Valor = @ImportePrimProd    
      IF @FrecuenciaPrimProd = 'Fin mes' and @FechaA <> 15   SELECT @Valor = @ImportePrimProd    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimasProdFijos', @Empresa, @Personal, NULL, @Valor    
    END    
  --  IF @NomTipo IN ('AJUSTE')    
  --    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, NULL, @Gastos    
    -- Incentivo De Asistencia    
/*    IF @IncentivoAsistencia = 1    
    BEGIN    
      EXEC spNominaInsentivosAsistencia @Empresa, @Personal,  @EjercicioAnterior,  'FALTAS',  @Cantidad       OUTPUT    
      SELECT @ImporteInCentivoAsistencia = @Cantidad * @SueldoDiario    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'InsentivoAsistencia', @Empresa, @Personal, @Cantidad, @ImporteInCentivoAsistencia    
    END    
*/    
    -- Incidencias Manuales    
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')    
    BEGIN    
      INSERT #Nomina (    
             Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)     
      SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)    
        FROM IncidenciaD d    
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'    
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto /*AND ISNULL(nc.Especial, '') <> 'Horas Extras' AND RequiereDiasTrabajados = 0 */    
         AND nc.Movimiento = 'Percepcion'    
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion <= @FechaBaja    
    
      IF @Compromisos <>'Ninguno'    
        INSERT #Nomina (    
               Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)     
        SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)    
          FROM IncidenciaD d    
          JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'    
          JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto /*AND ISNULL(nc.Especial, '') <> 'Horas Extras' AND RequiereDiasTrabajados = 0 */    
           AND nc.Movimiento <> 'Percepcion'    
          LEFT OUTER JOIN incidenciapanama on incidenciapanama.id =i.id    
          LEFT OUTER JOIN TipoDeduccion on IncidenciaPanama.TipoDeduccion = TipoDeduccion.TipoDeduccion     
          LEFT OUTER JOIN TipoRetencion on IncidenciaPanama.TipoRetencion = TipoRetencion.TipoRetencion    
                      AND IncidenciaPanama.TipoRetencion like 'COMPROMISO%'    
         WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL /*AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA*/    
    END ELSE    
      INSERT #Nomina (    
             Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)     
      SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)    
        FROM IncidenciaD d    
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'    
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto /*AND ISNULL(nc.Especial, '') <> 'Horas Extras' */AND RequiereDiasTrabajados = 0    
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA    
    
---se borran todos los conceptos que no aplican para este MOV    
    DELETE #Nomina    
      FROM #Nomina n    
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto    
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)    
       AND n.Personal = @Personal    
    
    EXEC xpNominaCalcIncidencia @NomTipo, @Empresa, @Personal, @FechaD, @FechaA, @IncidenciaD, @IncidenciaA, @TipoCambio, @Ok OUTPUT, @OkRef OUTPUT      
    
-- Faltas     
    SELECT @Faltas = ISNULL(SUM(d.Cantidad), 0), @FaltasImporte = ISNULL(SUM(d.Importe), 0)    
      FROM #Nomina d    
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Especial = 'Faltas'    
     WHERE d.Personal = @Personal     
-- Incapacidades    
    SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)    
      FROM #Nomina d    
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Especial = 'Incapacidades'    
     WHERE d.Personal = @Personal     
    
-- ojo esto lo agregue para borrar las incapacidads de mas de dias del peridoo    
    WHILE @Incapacidades > @DiasPeriodo and @incapacidades > 0 AND @PersonalEstatus='ALTA'    
    BEGIN    
      SELECT @MaxID = ISNULL(MAX (IncidenciaID), 0), @MaxRID= ISNULL(MAX (IncidenciaRID), 0)    
        FROM #Nomina d    
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'    
       WHERE d.Personal = @Personal    
    
      DELETE #Nomina WHERE IncidenciaID = @Maxid AND IncidenciaRID=@MaxRid    
      SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)    
        FROM #Nomina d    
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'    
       WHERE d.Personal = @Personal    
    END    
    
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Incapacidades', @FechaD, @FechaA, NULL, NULL, @IncapacidadesD OUTPUT    
    
    WHILE (@Incapacidades+@IncapacidadesD) > @DiasPeriodo and (@Incapacidades+@IncapacidadesD) > 0  and (@IncapacidadesD <= @DiasPeriodo) AND @PersonalEstatus='ALTA'    
    BEGIN    
      SELECT @MaxID = ISNULL(MAX (IncidenciaID), 0), @MaxRID= ISNULL(MAX (IncidenciaRID), 0)    
        FROM #Nomina d    
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'    
       WHERE d.Personal = @Personal     
      DELETE #Nomina WHERE IncidenciaID = @Maxid AND IncidenciaRID=@MaxRid    
      SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)    
        FROM #Nomina d    
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'    
       WHERE d.Personal = @Personal    
    END    
    
    
    -- Registrar Faltas e Incapacidades    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Faltas',        @Empresa, @Personal, @Faltas,        @FaltasImporte    
    
    -- Sueldo Variable (XIII)    
    SELECT @SueldoVariable = ISNULL(SUM(d.Importe), 0)    
      FROM #Nomina d    
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.SueldoVariable = 1    
     WHERE d.Personal = @Personal     
    
    EXEC spNominaClaveInternaEstaNomina @Personal, 'VacacionesTomadas', @VacacionesTomadas OUTPUT    
    
--- vacaciones cambio    
    IF @NomTipo IN ('VACACIONES')    
    BEGIN    
      SELECT @SDI = @SDI / @Diasmes * @VacacionesTomadas    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, NULL, @SDI    
      EXEC spNominaPanamaSueldoDiarioVariableVacaciones  @Empresa, @Personal, @FechaAlta, @SueldoMensual/*@SueldoMensualPersonal*/, @ImporteComisiones, @ImportePrimProd, @FechaD1, @SueldoDiarioVariable OUTPUT          
    
      UPDATE #Nomina SET Importe = Cantidad * @SueldoDiarioVariable        
       WHERE Nominaconcepto  IN(SELECT NominaConcepto FROM Nominaconcepto WHERE ValorBase = 'Sueldo Diario Vac')     
         AND #Nomina.Personal = @Personal    
    
      UPDATE Incidenciad  SET Incidenciad.Importe = n.Importe,     
                              Incidenciad.Saldo   = n.Importe    
        FROM Incidenciad, #Nomina  n      
       WHERE n.Nominaconcepto  IN(SELECT NominaConcepto FROM Nominaconcepto WHERE ValorBase = 'Sueldo Diario Vac')     
         AND n.Personal           = @Personal    
         AND n.IncidenciaiD       = IncidenciaD.ID     
         AND n.IncidenciaRID      = IncidenciaD.RID      
         AND IncidenciaD.Importe  = IncidenciaD.Saldo      
    END    
    
    IF @NomTipo = 'AJUSTE'    
    BEGIN    
      EXEC spNominaClaveInternaEstaNomina @Personal, 'Sueldo', @DiasNaturales OUTPUT    
      SELECT @DiasPeriodo = @DiasNaturales    
    END    
    
    SELECT @Calc = -@VacacionesTomadas    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @Calc    
    SELECT @DiasNaturalesTrabajados = dbo.fnMayor(0, @DiasNaturales - @Faltas - @Incapacidades)    
    SELECT @DiasTrabajados = @DiasPeriodo - @Incapacidades - @Faltas    
    IF @NomTipo <> 'AJUSTE' AND @DiasTrabajados<0.0  SELECT @DiasTrabajados = 0.0    
    SELECT @DiasTrabajadosImporte = (@SueldoDiario*@DiasPeriodo) + @SueldoVariable - @FaltasImporte - @IncapacidadesImporte    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasPeriodo',     @Empresa, @Personal, @DiasPeriodo    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasNaturales',   @Empresa, @Personal, @DiasNaturales    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasTrabajados',   @Empresa, @Personal, @DiasTrabajados, @DiasTrabajadosImporte    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/SueldoDiario',   @Empresa, @Personal, @Importe = @SueldoDiario    
    IF @DiasTrabajados > 0    
    BEGIN    
      IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')    
        INSERT #Nomina (    
               Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Cuenta,     Vencimiento,   Cantidad,   Importe)     
        SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)    
          FROM IncidenciaD d    
          JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'    
          JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND RequiereDiasTrabajados = 1    
         WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL     
      ELSE    
        INSERT #Nomina (    
               Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Cuenta,     Vencimiento,   Cantidad,   Importe)     
        SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)    
          FROM IncidenciaD d    
          JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'    
          JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND RequiereDiasTrabajados = 1    
         WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA    
    END    
    
    IF @CfgPrimaDominicalAuto = 1 AND (@DescansaDomingos = 0 OR @LaboraDomingos = 1)    
    BEGIN    
      EXEC spNominaDomingosLaborados @Empresa, @Personal, @FechaD, @FechaA, @IncidenciaD, @IncidenciaA, @DomingosLaborados OUTPUT    
      SELECT @PrimaDominical = @DomingosLaborados * (@SueldoDiario * (@PrimaDominicalPct/100.0))    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaDominical', @Empresa, @Personal, @DomingosLaborados, @PrimaDominical    
    END    
    
    -- Prima Vacacional y vacaciones    
    IF @NomTipo = 'VACACIONES' AND @EsAniversario = 1    
    BEGIN    
      IF @OtorgarDiasVacacionesAniversario = 1    
      BEGIN    
        SELECT @SueldoVariableVacacionesD = DATEADD(month, -6, @FechaA)    
        EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableVacacionesD, @FechaA, @SueldoVariableAcumulado OUTPUT    
        SELECT @SueldoVariableAcumulado = @SueldoVariableAcumulado / 6.0 / 30.0    
        SELECT @ImporteVacaciones = (@SueldoDiario + @SueldoVariableAcumulado) * @DiasVacaciones    
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @DiasVacaciones    
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Vacaciones', @Empresa, @Personal, @DiasVacaciones, @ImporteVacaciones    
      END    
      SELECT @PrimaVacacional= @ImporteVacaciones* @pctPrimaVacacional /100.0    
      IF @OtorgarDiasVacacionesAniversario = 1     
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaVacacional', @Empresa, @Personal, @DiasVacaciones, @PrimaVacacional    
    END ELSE    
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')    
    BEGIN    
      IF @Antiguedadflotante < = 2 AND @Preaviso = 1    
      BEGIN    
        SELECT @SueldoVariableVacacionesD = DATEADD(mm, -6, @IncidenciaA)    
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'SUELDO', @SueldoVariableVacacionesD, @IncidenciaA, NULL, NULL, @DiasTrabajados OUTPUT    
        EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableVacacionesD, @IncidenciaA, @SueldoVariableAcumulado OUTPUT    
        SELECT @PreavisoImporte = @SueldoVariableAcumulado * 30.0 / @DiasTrabajados    
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Preaviso', @Empresa, @Personal, @DiasTrabajados, @PreavisoImporte    
      END    
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'DiasVacaciones', @FechaAntiguedad, @FechaA, NULL, NULL, @DiasVacacionesAcumulado OUTPUT    
      SELECT @Calc = -@DiasVacacionesAcumulado    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @Calc    
      IF @FechaAlta > (DATEADD(mm, -11, @FechaA) + 1)    
        SELECT @SueldoVariableVacacionesD = @FechaAlta -- se toman 11 meses menos de la fecha de calculo sueldo variable o la fecha de alta    
      ELSE    
        SELECT @SueldoVariableVacacionesD = (DATEADD(mm, -11, @FechaA) + 1) --se toman 11 meses menos de la fecha de calculo sueldo variable o la fecha de alta    
    
    
      SELECT @DiasVacaciones = SUM(VacacionesDias) FROM AcumuladosPersonalPanamaejercicio WHERE Personal = @PErsonal    
      EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableVacacionesD, @SueldoVariableVacacionesA, @SueldoVariableAcumulado OUTPUT    
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'GastosRepresentacion',@SueldoVariableVacacionesD, @SueldoVariableVacacionesA, NULL, @Gastos OUTPUT, NULL    
      SELECT @Gastos = @Gastos / 11.0 / 30.0 * @DiasVacaciones    
      SELECT @SueldoVariableAcumulado =(@SueldoVariableAcumulado / 11.0 /30.0 * @DiasVacaciones) + (@BaseVacaciones/11.0)    
      IF @Nomtipo = 'Liquidacion'     
        IF @GastosLiquidacion ='S'     
          EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion',      @Empresa, @Personal, @SueldoVariableAcumulado, @Gastos    
      SELECT @Vacaciones = @SueldoVariableAcumulado --/ 11.0    
      SELECT @SueldoDiarioVariable = @SueldoVariableAcumulado --/ (ABS(DATEDIFF(dd,@SueldoVariableVacacionesD, @SueldoVariableVacacionesA)) + 1)      
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Vacaciones',      @Empresa, @Personal, @SueldoVariableAcumulado, @Vacaciones    
    END    
    
    IF @TieneValesDespensa = 1 AND @EsFinMes = 1 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')    
    BEGIN    
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Faltas',        @PrimerDiaMes, @FechaA, NULL, NULL, @FaltasAcumulado OUTPUT    
-- ojo      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Incapacidades', @PrimerDiaMes, @FechaA, NULL, NULL, @IncapacidadesAcumulado OUTPUT    
      SELECT @DiasMesTrabajados = dbo.fnMayor(0, @DiasMes - @Faltas - @FaltasAcumulado - @Incapacidades - @IncapacidadesAcumulado)    
      SELECT @ValesDespensaImporte = @ValesDespensaImporte + (@SueldoDiario*@DiasMesTrabajados*(@ValesDespensaPct/100.0))    
--      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ValesDespensa', @Empresa, @Personal, @Importe = @ValesDespensaImporte    
    END    
    
    IF @PremioPuntualidadPct > 0.0 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')    
    BEGIN    
      SELECT @CalcImporte = @DiasTrabajados*@SDI*(@PremioPuntualidadPct/100.0)    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PremioPuntualidad', @Empresa, @Personal, @DiasTrabajados, @CalcImporte    
    END    
     
    IF @PremioAsistenciaPct > 0.0 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')    
    BEGIN    
      SELECT @CalcImporte = @DiasTrabajados*@SDI*(@PremioAsistenciaPct/100.0)    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PremioAsistencia', @Empresa, @Personal, @DiasTrabajados, @CalcImporte    
    END    
    
    
    -- Subsidio Incapacidad EG    
    IF @CfgSubsidioIncapacidadEG = 1 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')    
      EXEC spNominaSubsidioIncapacidadEG @Empresa, @Personal, @SueldoDiario, @SDI, @Ok OUTPUT, @OkRef OUTPUT    
    
  END  -- Nominas Normales    
  IF @NomTipo = 'LIQUIDACION'    
  BEGIN      
    EXEC   spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Vacaciones', @FechaAntiguedad, @FechaA, NULL, NULL, @AcumuladoDiasVacaciones OUTPUT                  
    SELECT @AdeudoTotalVacaciones = ((DATEDIFF(dd,@FechaAntiguedad, @FechaA)+1) / 11.0) - @AcumuladoDiasVacaciones    
    EXEC spNominaPanamaSueldoDiarioVariableVacaciones  @Empresa, @Personal, @FechaAlta, @SueldoMensual , @ImporteComisiones, @ImportePrimProd, @FechaA, @SueldoDiarioVariable OUTPUT    
    SELECT @ImporteAdeudoTotalVacaciones=@SueldoDiarioVariable * @AdeudoTotalVacaciones    
    EXEC   spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Vacaciones', @Empresa, @Personal, @AdeudoTotalVacaciones, @ImporteAdeudoTotalVacaciones    
  END    
    
  IF @NomTipo in('AGUINALDO', 'LIQUIDACION')    
  BEGIN-- puse esto para que el aguinaldo tambien jale incidencias manuales    
    INSERT #Nomina (    
           Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)     
    SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)    
      FROM IncidenciaD d    
      JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'    
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto /*AND ISNULL(nc.Especial, '') <> 'Horas Extras' */AND RequiereDiasTrabajados = 0    
     WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA    
    
    DELETE #Nomina    
      FROM #Nomina n    
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto    
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)    
       AND n.Personal = @Personal    
    
    SELECT @SueldoVariableDias = 120 -- por que en panama lo redondean siempre    
    SELECT @SueldoVariableAguinaldoA = @FechaA     
    
 -- pago aguinaldo    
      SELECT @Aguinaldo = @SueldoDiario * @DiasPeriodo    
    
      SELECT @SueldoVariableVacacionesD = DATEADD(month, -6, @UltimoDiaAno)    
      IF @SueldoVariableVacacionesD < @FechaAntiguedad    
        SELECT @SueldoVariableVacacionesD = @FechaAntiguedad    
      SELECT @Dias = ABS(DATEDIFF(dd, @SueldoVariableVacacionesD, @UltimoDiaAno)) + 1      
      EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableVacacionesD, @UltimoDiaAno, @SueldoVariableAcumulado OUTPUT    
      SELECT @SueldoVariableAcumulado = @SueldoVariableAcumulado / @Dias     
      SELECT @Aguinaldo2 = (@SueldoDiario + @SueldoVariableAcumulado) * @DiasPeriodo    
-- SELECT @Aguinaldo,@Aguinaldo2,@dias,@SueldoVariableVacacionesD,@UltimoDiaAno,@SueldoVariableAcumulado,@SueldoDiario,@DiasPeriodo    
    
    IF @BaseAguinaldo = 'Sueldo'    
      SELECT @Aguinaldo= @Aguinaldo     
    
    IF @BaseAguinaldo = 'Sueldo Mas Comisiones'    
      SELECT @Aguinaldo = @Aguinaldo2    
    
    IF @BaseAguinaldo = 'El Mayor'    
      SELECT @Aguinaldo = dbo.fnmayor(@Aguinaldo,@Aguinaldo2)    
         
    SELECT @Aguinaldo= @Aguinaldo * @pctPagoAguinaldo / 100.0      
         
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Aguinaldo', @Empresa, @Personal, @DiasPeriodo , @Aguinaldo    
  END     
    
-- se duplica por que se necesita para el calculo de la prima de antiguedad    
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')     
  BEGIN    
    
    SELECT  @ISRBase = 0, @IMSSBase = 0, @ImpuestoEstatalBase = 0, @CedularBase = 0, @BasePrimaAntiguedad  = 0,    
            @BaseIndemnizacion = 0, @BasePreelaborada = 0, @BaseSeguroEducativo = 0, @BaseVacaciones= 0    
    
    EXEC spNominaGrava @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, @FechaA, @Moneda, @TipoCambio,     
                       @SMZ, @SMZTopeHorasDobles, @SDI, @DiasPeriodo, @DiasMes, @DiasAno, @Antiguedad, @IndemnizacionTope,    
--@SueldoMensual,    
                       @ISRBase OUTPUT, @IMSSBase OUTPUT, @ImpuestoEstatalBase OUTPUT, @CedularBase OUTPUT,    
                       @Ok OUTPUT, @OkRef OUTPUT    
    
    EXEC spNominaGravaSalvador @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD,     
                             @FechaA, @Moneda, @TipoCambio,     
                             @BasePrimaAntiguedad  OUTPUT,    
                             @BaseIndemnizacion    OUTPUT,    
                             @BasePreelaborada     OUTPUT,    
                             @BaseSeguroEducativo  OUTPUT,    
                             @BaseVacaciones       OUTPUT,    
                          @Ok               OUTPUT,    
                          @OkRef             OUTPUT    
    
  END    
    
    
    
  IF @NomTipo = 'LIQUIDACION'    
  BEGIN      
    SELECT @Indemnizacion = @AntiguedadFlotante * 30.0 * @SueldoDiario    
    SELECT @Indemnizacion = dbo.FnMayor(ISNULL(@Indemnizacion,0), 15.0 * @SueldoDiario)    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Indemnizacion', @Empresa, @Personal, @semanasIndem, @Indemnizacion    
  END    
    
  -- Parte Gravable    
  SELECT  @ISRBase =0, @IMSSBase =0, @ImpuestoEstatalBase =0, @CedularBase =0,                          @BasePrimaAntiguedad  =0,    
                           @BaseIndemnizacion    =0,    
                           @BasePreelaborada     =0,    
                           @BaseSeguroEducativo  =0,    
                           @BaseVacaciones       =0    
    
  EXEC spNominaGrava @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, @FechaA, @Moneda, @TipoCambio,     
                     @SMZ, @SMZTopeHorasDobles, @SDI, @DiasPeriodo, @DiasMes, @DiasAno, @Antiguedad, @IndemnizacionTope,    
--@SueldoMensual,    
                     @ISRBase OUTPUT, @IMSSBase OUTPUT, @ImpuestoEstatalBase OUTPUT, @CedularBase OUTPUT,    
                     @Ok OUTPUT, @OkRef OUTPUT    
--select @ISRBase    
  EXEC spNominaGravaSalvador @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD,     
                           @FechaA, @Moneda, @TipoCambio,     
                           @BasePrimaAntiguedad  OUTPUT,    
                           @BaseIndemnizacion    OUTPUT,    
                           @BasePreelaborada     OUTPUT,    
                           @BaseSeguroEducativo  OUTPUT,    
                           @BaseVacaciones       OUTPUT,    
                        @Ok               OUTPUT,    
                        @OkRef             OUTPUT    
    
  -- Totaliza Percepciones antes de Impuestos    
  SELECT @PercepcionBruta = 0.0    
  SELECT @PercepcionBruta = @PercepcionBruta + ISNULL(SUM(d.Importe), 0.0)     
    FROM #Nomina d     
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'     
   WHERE d.Personal = @Personal AND d.Movimiento = 'Percepcion'     
    
   SELECT @AFPBASE = @IMSSBase    
   IF  (@IMSSBase / @DiasPeriodo * 30.0) > @TopeIMSS       
     SELECT  @IMSSBase = @TopeIMSS/ 30.0 * @DiasPeriodo       
    
   EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/Base',   @Empresa, @Personal, @Importe = @IMSSBase    
   EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR GR/Base',          @Empresa, @Personal, @Importe = @CedularBase    
    
-- select @IMSSBase    
    
-- delete nominad where id=10644    
     
-- select nominaconcepto,* from nominad where id=10644    
-- select * from movespecificonomina    
-- insert movespecificonomina (movespecificonomina,Nominaconcepto) select 'Vacaiones',nominaconcepto from nominaconcepto    
    
    
  IF @NomTipo IN ('NORMAL', 'AJUSTE', 'FINIQUITO', 'LIQUIDACION', 'AGUINALDO', 'VACACIONES')     
  BEGIN    
 -- IMSS    
    SELECT @SSEmpleado     =    @IMSSBase * (@SSEmpleadoPct        / 100.0),    
           @SSPatron       =    @IMSSBase * (@SSPatronPct          / 100.0),    
           @SEEmpleado     =   (@BaseSeguroEducativo - ( SELECT ISNULL(SUM(Importe),0) FROM #Nomina WHERE Personal = @Personal and nominaconcepto='190'  and id=@id))* (  @SEEmpleadoPct        / 100.0),    
           @SEPatron       =   (@BaseSeguroEducativo - ( SELECT ISNULL(SUM(Importe),0) FROM #Nomina WHERE Personal = @Personal and nominaconcepto='190'  and id=@id )) * (@SEPatronPct          / 100.0),    
           @RiesgoProfesional =  @IMSSBase  * ( @RiesgoProfesionalPct / 100.0)    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/Obrero',       @Empresa, @Personal, /*@DiasTrabajados*/@BaseSeguroEducativo, @SSEmpleado,@Cuenta = @AcreedorIMSS    
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/Patron',         @Empresa, @Personal, @Importe = @SSPatron, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimiento    
    
    
    IF @NomTipo NOT IN ('AGUINALDO')    
    BEGIN    
  
      IF (@AFPBASE/ @diasPEriodo * 30.0)  > @afpTopeMaximo    
        SELECT @AFPBASE = @afpTopeMaximo / 30.0 * @DiasPeriodo    
        
      IF (@AFPBASE/ @diasPEriodo * 30.0) < @afpTopeMinimo    
        SELECT @AFPBASE = @afpTopeMinimo/30.0 * @DiasPeriodo    
    
      SELECT @IPSFAEmpleadoComision = @AFPBASE * @IPSFAEmpleadoComision / 100.0    
      SELECT @IPSFAPatron           = @AFPBASE * @IPSFAPatron     / 100.0    
      SELECT @AFPEmpleadoComision = @AFPBASE * @pctAFPEmpleadoComision / 100.0    
      SELECT @AFPEmpleadoCot      = @AFPBASE * @pctAFPEmpleadoCot / 100.0    
      SELECT @AFPPatron           = @AFPBASE * @pctAFPPatron     / 100.0    
      SELECT @AFPEmpleado         = @AFPEmpleadoCot + @AFPEmpleadoComision    
      SELECT @ISRBase = @ISRBase - isnull(@AFPEmpleado,0) --  se deduces para el ISR lo que paga el empleado    
    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Base',                 @Empresa, @Personal, NULL, @Importe = @ISRBase    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'AFP/EmpeadoComision',       @Empresa, @Personal, NULL, @Importe = @AFPEmpleadoComision    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'AFP/EmpeadoCot',            @Empresa, @Personal, NULL, @Importe = @AFPEmpleadoCot    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'AFP/Empeado',               @Empresa, @Personal, NULL, @Importe = @AFPEmpleado    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'AFP/Patron',                @Empresa, @Personal, NULL, @Importe = @AFPPatron    
    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT,'IPSFA/FAEmpeado',               @Empresa, @Personal, NULL, @Importe = @IPSFAEmpleadoComision    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IPSFA/FAPatron',                @Empresa, @Personal, NULL, @Importe = @IPSFAPatron    
   END    
 --   EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'RiesgoProfesional', @Empresa, @Personal, @Importe = @RiesgoProfesional, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimiento    
    IF @NomTipo NOT IN ('AGUINALDO')    
    BEGIN    
   --   EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SE/Empleado',       @Empresa, @Personal, @DiasTrabajados, @SEEmpleado,@Cuenta = @AcreedorIMSS    
   --   EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SE/Patron',         @Empresa, @Personal, @Importe = @SEPatron, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimiento    
        SELECT @NomTipo=@NomTipo    
    END ELSE    
    BEGIN  --  en el MES XII NO SE DESCUENTA SE    
      SELECT @SEEmpleado = 0,    
               @SEPatron = 0    
    END    
    -- Provisiones    
    IF @NomTipo IN ('NORMAL', 'AJUSTE')     
    BEGIN    
      SELECT @CalcImporte = @PrimaVacacional / @DiasAno * @DiasNaturales    
      --EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Vacaciones', @Empresa, @Personal, @Importe = @CalcImporte    
      SELECT @CalcImporte = (@DiasAguinaldo*@SueldoDiario/@DiasAno)*@DiasNaturales    
--      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Aguinaldo',  @Empresa, @Personal, @Importe = @CalcImporte    
      IF (@SMZ*@SMZPrimaAntiguedad) < @SueldoDiario    
      SELECT @CalcImporte = (@DiasPrimaAntiguedad*@SMZ*@SMZPrimaAntiguedad*@Antiguedad)/@DiasAno*@DiasNaturales    
      ELSE    
         SELECT @CalcImporte =(@DiasPrimaAntiguedad*@SueldoDiario*@Antiguedad)/@DiasAno*@DiasNaturales    
--      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Antiguedad', @Empresa, @Personal, @Importe = @CalcImporte    
    END    
  END    
  SELECT @DiasPeriodo=isnull(@DiasPeriodo,0)    
    
  -- Baje esta parte por que necesito el SE para el calculo de ISR    
    
  -- ISR      
  BEGIN    
    IF @EsFinMes = 1    
    BEGIN    
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/BASE', @PrimerDiaMes, @FechaA, NULL, @ISRBaseMes OUTPUT,NULL    
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/ISR', @PrimerDiaMes, @FechaA, NULL, @ISRAcumuladoMensual OUTPUT,NULL    
    
      SELECT @ISRBaseAcumulado = @ISRBaseMes + @ISRBASE    
      EXEC SPTablaImpuesto @ISRTabla, NULL,'Mensual',@ISRBaseAcumulado, @ISR Output, NULL    
      SELECT @ISR = @ISR - @ISRAcumuladoMensual    
    END    
    ELSE BEGIN    
         EXEC SPTablaImpuesto @ISRTabla, NULL,'Quincenal',@ISRBase, @ISR Output, NULL    
    END    
        
    IF @ISRFijoPeriodo > 0  -- por que en panama algunos empleados deciden cuanto les descuenten de renta    
      SELECT @ISR = @ISRFijoPeriodo    
    
    EXEC  spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR', @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento     
  END    
    
  IF  @NomTipo in('NORMAL','VACACIONES')     
  BEGIN    
  -- SINDICATO     
    SELECT @SindicatoImporte = 0    
    IF @SindicatoPr > 0 AND @SindicatoFrecuencia='FIN MES' AND @EsFinMes=1    
    BEGIN    
      IF @SindicatoMetodo= 'TOTAL DEVENGADO'    
         SELECT @SindicatoImporte = (@PercepcionBruta - @FaltasImporte) * @SindicatoPr / 100.0    
      ELSE    
         SELECT @SindicatoImporte = @SueldoMensual * @SindicatoPr / 100.0    
    END  ELSE    
    IF @Sindicato$ > 0 AND @SindicatoFrecuencia='INICIO MES' AND @EsFinMes=0    
      IF @SindicatoMetodo= 'TOTAL DEVENGADO'    
         SELECT @SindicatoImporte= (@PercepcionBruta-@FaltasImporte)  * @SindicatoPr / 100.0    
      ELSE    
         SELECT @SindicatoImporte= @SueldoMensual * @SindicatoPr / 100.0    
    ELSE     
      IF @Sindicatopr > 0         
      IF @SindicatoMetodo= 'TOTAL DEVENGADO'    
         SELECT @SindicatoImporte= @PercepcionBruta * @SindicatoPr / 100.0    
      ELSE    
         SELECT @SindicatoImporte= @SueldoMensual * @SindicatoPr / 100.0 / 2.0     
    IF @NomTipo='VACACIONES'     
      SELECT @SindicatoImporte =@SindicatoImporte * ROUND(DATEDIFF(dd, @Incidenciad, @IncidenciaA) / 15.0, 0) --- por que es cada quincena    
    
    IF EXISTS(SELECT * FROM Personal  WHERE Personal = @Personal AND ISNULL(NULLIF(ISNULL(Sindicato,''),'Ninguno'),'(Confianza)') <> '(Confianza)')    
    BEGIN    
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Sindicato', @Empresa, @Personal, @Importe = @SindicatoImporte, @Cuenta = @SindicatoAcreedorPr    
      IF @Sindicato$ > 0      
      BEGIN    
        SELECT @SindicatoImporte=        @Sindicato$    
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Sindicato', @Empresa, @Personal, @Importe = @SindicatoImporte, @Cuenta = @SindicatoAcreedor$    
      END    
    END    
  END     
    
  -- Pension Alimenticia 'PensionA/SueldoBruto','PensionA/SueldoNeto'    
  SELECT @CalcImporte = (@PensionASueldoBruto / 100.0) * @PercepcionBruta     
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor    
  SELECT @CalcImporte = (@PensionASueldoNeto / 100.0)* (@PercepcionBruta-ISNULL(@ISR, 0.0) - ISNULL(@IMSSObrero, 0.0)) + @PensionA    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto',  @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor    
    
  SELECT @CalcImporte = (@PensionASueldoBruto2 / 100.0) * @PercepcionBruta    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor2    
  SELECT @CalcImporte = (@PensionASueldoNeto2 / 100.0)*(@PercepcionBruta - ISNULL(@ISR, 0.0) - ISNULL(@IMSSObrero, 0.0))+ @PensionA2    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto',  @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor2    
    
  SELECT @CalcImporte = (@PensionASueldoBruto3 / 100.0)* @PercepcionBruta    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor3    
  SELECT @CalcImporte = (@PensionASueldoNeto3/100.0)*(@PercepcionBruta-ISNULL(@ISR, 0.0) - ISNULL(@IMSSObrero, 0.0))+ + @PensionA3    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto',  @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor3    
    
  SELECT @PersonalPercepciones = 0.0, @PersonalDeducciones = 0.0    
  SELECT @PersonalPercepciones = ISNULL(SUM(d.Importe), 0.0)    
    FROM #Nomina d     
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'    
   WHERE d.Personal = @Personal AND d.Movimiento = 'Percepcion'    
    
  SELECT @PersonalDeducciones = ISNULL(SUM(d.Importe), 0.0)    
    FROM #Nomina d     
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Deduccion'    
   WHERE d.Personal = @Personal AND d.Movimiento = 'Deduccion'    
    
  SELECT @PersonalNeto = @PersonalPercepciones - @PersonalDeducciones    
    
  -- Cuentas por Cobrar (Cxc/Faltantes Caja/Faltantes Inv/Etc.)    
  IF @NomCxc IN ('PARCIALES', 'COMPLETAS') AND @NomTipo <> 'AJUSTE'    
  BEGIN    
    SELECT @ConSueldoMinimo = 1     
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') AND @FiniquitoNetoEnCeros = 0 SELECT @ConSueldoMinimo = 0    
    IF @PersonalNeto > @SueldoMinimo OR @ConSueldoMinimo = 0    
      EXEC spNominaCxc @NomCxc, @NomTipo, @Empresa, @Sucursal, @ID, @Personal, @Cliente, @IncidenciaD, @IncidenciaA, @Moneda, @TipoCambio, @ConSueldoMinimo, @SueldoMinimo, @PersonalNeto OUTPUT, @Ok OUTPUT, @OkRef OUTPUT    
  END    
    
-- ojo aqui borro lo que no quieran    
--  EXEC xpNominaAutoQuitarCXC @Personal    
  SELECT @calc =@SueldoVariable /12.0    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ProvisionMesXIII', @Empresa, @Personal, @Importe = @calc    
  SELECT @calc = @BaseVacaciones /11.0     
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ProvisionVacaciones', @Empresa, @Personal, @Importe = @calc    
  SELECT @calc = @BasePrimaAntiguedad /52.0     
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ProvisionPrimaAntiguedad', @Empresa, @Personal, @Importe = @calc    
  SELECT @calc = @BaseIndemnizacion * .0654    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ProvisionIndemnizacion', @Empresa, @Personal,   @Importe = @calc    
    
/*    
-- se manda fondo de cesantia que se emite a la entidad adminsitradora del fondo falta clave interna    
*/    
    
-- se recalcula por que las cxc    
  SELECT @PersonalPercepciones = 0.0, @PersonalDeducciones = 0.0    
    
  SELECT @PersonalPercepciones = ISNULL(SUM(d.Importe), 0.0)    
    FROM #Nomina d     
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'    
   WHERE d.Personal = @Personal AND d.Movimiento = 'Percepcion'    
    
  SELECT @PersonalDeducciones = ISNULL(SUM(d.Importe), 0.0)    
    FROM #Nomina d     
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Deduccion'    
   WHERE d.Personal = @Personal AND d.Movimiento = 'Deduccion'    
    
  SELECT @PersonalNeto = @PersonalPercepciones - @PersonalDeducciones    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Percepciones', @Empresa, @Personal, @Importe = @PersonalPercepciones    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Deducciones', @Empresa, @Personal, @Importe = @PersonalDeducciones    
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Neto', @Empresa, @Personal, @Importe = @PersonalNeto, @Cuenta = @PersonalCtaDinero, @Beneficiario = @BeneficiarioSueldoNeto    
    
  IF ISNULL(@PersonalNeto,0) = 0 AND @MovTipo = 'NOM.NE' -- si es especial y su neto es 0 se borra el empleado    
     DELETE #Nomina WHERE Personal = @Personal      
    
  IF @Ok IS NOT NULL AND @OkRef IS NULL SELECT @OkRef = @Personal    
  RETURN    
END     
GO
