EXEC xpConfigSQL
SET ANSI_NULLS OFF
GO
/**************** spNominaCalcPanama ****************/
if exists (select * from sysobjects where id = object_id('dbo.spNominaCalcPanama') and type = 'P') drop procedure dbo.spNominaCalcPanama
go
CREATE PROCEDURE spNominaCalcPanama
			@Empresa                        char(5),
			@FechaTrabajo                   datetime,
			@Sucursal                       int,
			@ID                             int,
			@Mov                            varchar(20),
			@Moneda                         char(10),
			@TipoCambio                     float,
			@Personal                       char(10),
			@FechaD                         datetime,
			@FechaA                         datetime,
			@PeriodoTipo                    varchar(20),
			@CfgAjusteMensualISR            bit,
			@CfgSueldoMinimo                varchar(20),
			@CfgTablaVacaciones             varchar(50),
			@CfgSubsidioIncapacidadEG       bit,
			@CfgPrimaDominicalAuto          bit,
			@CfgISRReglamentoAguinaldo      bit,
			@CfgISRReglamentoPTU            bit,
			@CfgISRLiquidacionSueldoMensual	varchar(50),
			@CfgFactorIntegracionAntiguedad	varchar(20),
			@CfgFactorIntegracionTabla      varchar(50),
			@NomTipo                        varchar(50),
      			@NomCalcSDI                     bit, 
    			@NomCxc				varchar(20),
			@RepartirDesde                  datetime,
			@RepartirHasta                  datetime,
      			@RepartirIngresoTope		money,
			@RepartirIngresoFactor          float,
			@RepartirDiasFactor             float,
			@CalendarioEsp                  bit, 
			@IncidenciaD                    datetime, 
			@IncidenciaA                    datetime,
			@Ok                             int		OUTPUT,
			@OkRef                          varchar(255)	OUTPUT
WITH ENCRYPTION 
AS BEGIN
  DECLARE
    @RedondeoMonetarios 		  int,
    @Dia            				  int,
    @Mes				              int,
    @Ano				              int,
    @Calc				              float,
    @CalcImporte			        money,
    @FechaDAno 				        int,
    @FechaAAno 				        int,
    @DescansaDomingos			    bit,
    @LaboraDomingos			      bit,	
    @EsInicioMes			        bit,
    @EsFinMes				          bit,
    @EsBimestre				        bit,
    @PrimerDiaMes			        datetime,
    @UltimoDiaMes			        datetime,
    @PrimerDiaMesAnterior		  datetime,
    @PrimerDiaBimestre			  datetime,
    @UltimoDiaMesAnterior		  datetime,
    @PersonalEstatus			    varchar(15),
    @PersonalCtaDinero			  varchar(20),
    @SucursalTrabajo			    int,
    @SucursalTrabajoEstado	  varchar(50),
    @Categoria				        varchar(50),
    @Puesto				            varchar(50),
    @Cliente				          varchar(10),
    @Jornada				          varchar(20),
    @JornadaDiasLibres			  int,
    @JornadaHoras			        float,
    @PersonalDiasPeriodo		  varchar(20),
    @ZonaEconomica			      varchar(30),
    @SMZ				              money,
    @SMZTopeHorasDobles			  float,
    @SMZPrimaAntiguedad			  float,
    @SMDF				              money,
    @PrimerDiaAno			        datetime,
    @PrimerDiaAnoReal         datetime,
    @PrimerDiaAnoAnterior		  datetime,
    @UltimoDiaAno			        datetime,
    @UltimoDiaAnoAnterior		  datetime,
    @FechaAlta				        datetime,
    @FechaBaja				        datetime,
    @FechaAntiguedad			    datetime,
    @FechaAniversario			    datetime,
    @FechaDAntiguedad			    datetime,
    @FechaAAntiguedad			    datetime,
    @UltimoPago				        datetime,
    @EsSocio				          bit,
    @SDI				              money,
    @SueldoPeriodo			      money,
    @SueldoDiario			        money,
    @SueldoMensual			      money,
    @SueldoMensualPersonal    money,
    @DiasMes				          float,
    @DiasMesTrabajados			  float,
    @DiasBimestre			        float,
    @DiasBimestreTrabajados		float,
    @DiasAno				          float,
    @DiasAnoISR				        float,
    @Aguinaldo				        money,
    @AguinaldoAcumulado			  money,
    @DiasAguinaldo			      float,
    @DiasAguinaldoSiguiente		float,
    @DiasAguinaldoProporcion	float,
    @DiasAguinaldoSt			    varchar(50),
    @DiasPeriodo			        float,
    @DiasPeriodoEstandar		  float,
    @DiasTrabajados			      float,
    @DiasTrabajadosImporte		float,
    @DiasNaturales			      float,
    @DiasNaturalesTrabajados	float,
    @DiasNaturalesOriginales	float,
    @DiasNaturalesDiferencia	float,
    @DiasPrimaAntiguedad		  float,
    @DomingosLaborados			  float,
    @Faltas				            float,
    @FaltasAcumulado			    float,
    @FaltasImporte			      money,
    @Incapacidades			      float, 
    @IncapacidadesAcumulado		float,
    @IncapacidadesImporte		  money,
    @ISR 				              money, 
    @ISRCredito	              money, 
    @ISR1				              money, 
    @ISR2				              money, 
    @ISRBaseAcumulado			    money, 
    @ISRAcumuladoMensual		  money,
    @ISRAcumulado			        money, 
    @ISRAcumuladoAnterior     money, 
    @ISRAcumuladoAjuste       money,
    @ISRBruto				          money,
    @ISRVencimiento			      datetime,    
    @ISRProyectado			      money,
    @ISRProyectado2			      money,
    @ISRBase				          money,
    @ISRBaseProyectado			  money,
    @ISRBaseProyectado2			  money,
    @ISRBaseMes				        money,
    @DiasAcumulados			      float,
    @ISRReglamentoBase			  float,
    @ISRReglamentoFactor		  float,
    @ISRSueldoMensual			    money,
    @ISRSueldoMensualReglamento	money,
    @ISRLiquidacion			      money,
    @ISRLiquidacionExcento		money,
    @ISRLiquidacionGravable		money,
    @ISRLiquidacionFactor		  float,
    @ISRLiquidacionBase			  float,
    @ISRAnual				          money,
    @ISRAjuste				        money,
    @ISRAjusteMax			        money,
    @ISRAjusteAnual			      money,
    @ISRTabla				          varchar(50),
    @IMSSBase				          money,
    @IMSSBaseAcumulado			  money,
    @IMSSBaseMes			        money,
    @ImpuestoEstatalBase		  money,
    @CedularBase			        money,
    @AcreedorIMSS			        varchar(10),
    @AcreedorISR			        varchar(10),
    @AcreedorInfonavit			  varchar(10),
    @AcreedorFonacot			    varchar(10),
    @AcreedorImpuestoEstatal	varchar(10),
    @IMSSVencimiento			    datetime,
    @IMSSVencimientoBimestre	datetime,
    @IMSSObrero				        money, 
    @IMSSObreroCV			        money,
    @IMSSObreroSinCV 			    money,
    @IMSSPatron 			        money,
    @IMSSPatronMensual			  money, 
    @IMSSPatronCV 			      money, 
    @IMSSPatronRetiro 			  money,
    @IMSSPatronInfonavit		  money, 
    @Antiguedad				        float,
    @AntiguedadFlotante			  float,
    @AntiguedadFlotantePrima              float,
    @AntiguedadSiguiente		  float,
    @AntiguedadDia			      int, 
    @AntiguedadMes			      int, 
    @PrimaDominicalPct			  float,
    @PrimaDominical			      money,
    @PrimaVacacionalPct			  float,
    @Vacaciones				        money, 
    @VacacionesTomadas			  float,
    @PrimaAntiguedad			    money,
    @PrimaAntiguedadAdicional		    money,
    @PrimaVacacional			    money, 
    @PrimaVacacionalProporcion money, 
    @PrimaVacacionalTope		  money, 
    @PrimaVacacionalExcenta		money, 
    @DiasVacaciones			      float,
    @DiasVacaciones2  	      float,
    @DiasVacaciones3		      float,
    @MasVacaciones             bit,
    @DiasVacacionesProporcion	float,
    @DiasVacacionesSiguiente	float,
    @DiasVacacionesAcumulado	float, 
    @FactorIntegracion			  float,
    @ImpuestoEstatal			    money, 
    @ImpuestoEstatalPct			  float,
    @ImpuestoEstatalGastoOperacionPct	float,  
    @ImpuestoEstatalVencimiento	datetime,
    @InfonavitObrero			    money,
    @InfonavitSDI			        float,
    @InfonavitSMGDF			      float,
    @PensionASueldoBruto		  float,
    @PensionASueldoBruto2		  float,
    @PensionASueldoBruto3		  float,
    @PensionASueldoNeto			  float,
    @PensionASueldoNeto2		  float,
    @PensionASueldoNeto3		  float,
    @PensionA       			    float,
    @PensionA2          		  float,
    @PensionA3		            float,
    @PensionAAcreedor			    varchar(10),
    @PensionAAcreedor2			  varchar(10),
    @PensionAAcreedor3			  varchar(10),
    @PercepcionBruta			    money,
    @CajaAhorro				        money,
    @CajaAhorroDesde			    datetime,
    @CajaAhorroHasta			    datetime,
    @CajaAhorroLiquidacion		datetime,
    @CajaAhorroInteresTotalPct float,
    @CajaAhorroAcumulado		  money,
    @CajaAhorroAcumuladoDias	float,
    @CajaAhorroIngresosTopados money,
    @CajaAhorroDiasTrabajados	 money,
    @FondoAhorroPct			      float,
    @FondoAhorro			        money,
    @FondoAhorroAnticipoPct		float,
    @FondoAhorroDesde			    datetime,
    @FondoAhorroHasta			    datetime,
    @FondoAhorroLiquidacion 	datetime,
    @FondoAhorroInteresTotal	money, 
    @FondoAhorroInteresTotalPct	float,
    @FondoAhorroDiasAcumulado		float,
    @FondoAhorroAcumulado		  money,
    @FondoAhorroAcumuladoDias	float,
    @FondoAhorroPatronAcumulado	money,
    @FondoAhorroPatronAcumuladoDias	float,
    @FondoAhorroAnticipoAcumulado money,
    @FondoAhorroAnticipoAcumuladoDias	float,
    @FondoAhorroIngresosTopados	money,
    @FondoAhorroDiasTrabajados	money,
    @EsAniversario			        bit,
    @OtorgarDiasVacacionesAniversario	bit,
    @OtorgarPrimaVacacionalAniversario	bit,
    @TieneValesDespensa			    bit,
    @ValesDespensaPct			      float,
    @ValesDespensaImporte		    money,
    @PremioPuntualidadPct		    float,
    @PremioAsistenciaPct		    float,
    @PersonalNeto			          money,
    @PersonalPercepciones		    money,
    @PersonalDeducciones		    money,
    @SueldoMinimo			          money,
    @IndemnizacionPct			      float,
    @Indemnizacion			        money,
    @IndemnizacionTope			    money,
    @Indemnizacion3Meses		    money,
    @Indemnizacion20Dias		    money,
    @SueldoVariable			        money, 
    @SueldoVariableAcumulado		money,
    @SueldoVariableDias			    float,
    @SueldoVariablePromedio		  money,
    @SueldoVariablePTUDesde		  datetime,
    @SueldoVariablePTUHasta		  datetime,
    @SueldoVariableAguinaldoD	  datetime,
    @SueldoVariableAguinaldoA	  datetime,
    @SueldoVariableAguinaldoD1	datetime,
    @SueldoVariableAguinaldoA1	datetime,
    @SueldoVariableVacacionesD	datetime,
    @SueldoVariableVacacionesA	datetime,
    @SueldoVariableAguinaldoLicenciaA datetime,
    @PTUIngresosTopados			    money,
    @PTUDiasTrabajados			    money,
    @DescuentoISRAjusteAnualPct	float,
    @FiniquitoNetoEnCeros		    bit,
    @ConSueldoMinimo			      bit,
    @BeneficiarioSueldoNeto		  varchar(100),
    @MontoNoGravablePersonal 		money,
    @MontoNoGravableConyugue 		money,
    @MontoNoGravableDependientes 	money,
    @TieneConyugue 			        bit,
    @CantidadDependientes 		  float,
    @SSEmpleado 			          money,
    @SSEmpleadoPct 			        float,
    @SSJubiladoPct              float,
    @SSPatron	 			            money,
    @SSPatronPct 			          float,
    @SEEmpleado 			                  money,
    @SEEmpleadoPct 			                float,
    @SEPatron	 			                    money,
    @SEPatronPct 			                  float,
    @SEEmpleadoAnualizado               money,
    @RiesgoProfesional		 	            money,
    @RiesgoProfesionalPct 		          float,
    @PctISRGR                           float,
    @AcumuladoDiasMesXII                int,
    @NumeroDeSemanasPorAntiguedad       float,
    @MesesPorAno                        float,
    @PctPrimaAntiguedad                 float,
    @IngresoCincoAnosPrima              money,
    @IngresoCincoAnosPrimaRemanente     money,
    @SemanasPorMes                      float,
    @Fecha                              datetime,
    @AcumuladoSE                        money,
    @DiasAcumuladosSE                   float,
    @AcumuladoDiasVacaciones            int,
    @GastosAcumulado                    money,
    @GastosAcumuladoXIII                money,
    @AguinaldoA                         money,
    @DiasFaltantes                      money,
    @Periodos                           float,
    @FactorAusentismo                   float,
    @SueldoDiarioVariable               money,
    @PreavisoImporte                    money,
    @Preaviso                           bit,
    @PAdicionalIndemni                  bit,
    @PorcentajePAdicionalIndemni        money,
    @Gastos                             money,
    @AcumuladoAguinaldo                 money,
    @AcumuladoVacacionesGR              money,
    @Valor                              money,
    @FechaIniVacaciones                 datetime,
    @FechaFinVacaciones                 datetime,
    @PeriodosPagadosPersonal            int,
    @PeriodosPagadosEmpresa             int,
    @TipoCalculoISR                     varchar(20),
    @SEBase                             money,                                                 
    @RataHora                           money,
    @HorasSemana                        float,
    @BaseISRExtra                       money,                          
    @ISRFijoPeriodo                     money,                          
    @BasePrimaAntiguedad                money,
    @BaseIndemnizacion                  money,
    @BasePreelaborada                   money,
    @BaseSeguroEducativo                money,
    @BaseVacaciones                     money,
    @ImporteComisiones                  money,       
    @ImporteViaticos                    money,
    @ImportePrimProd                    money,
    @FrecuenciaComisiones               varchar(20),       
    @FrecuenciaViaticos                 varchar(20),
    @FrecuenciaPrimProd                 varchar(20),
    @Sueldo                             money,
    @SindicatoMetodo                    varchar(50),
    @SindicatoAcreedorPr                varchar(50),
    @SindicatoAcreedor$                 varchar(50),
    @SindicatoFrecuencia                varchar(50),
    @Sindicato$                         money,
    @Sindicatopr                        float,
    @SindicatoImporte                   money,
    @SueldomesIndem                     money,
    @SueldoSemanaPrima                  money,
    @SemanasLiq                         float,
    @SemanasIndem                       float,
    @UsaPrima                           bit,
    @UsaIndemnizacion                   bit,
    @GastosLiquidacion                  varchar(50),
    @LiquidacionPanama                  varchar(50),
    @Dias                               int,
    @MaxID 				                      int,
    @MaxRID 				                    float,
    @IncapacidadesD 			              int,
    @Compromisos                        varchar(50),
    @Cantidad                           float,
    @Importe                            money,
    @RIDImporte                         money,
    @RID                                int,
    @DiasTrabajados2                    float,
    @HorasPeriodo                       float,
    @HorasMes                           float,
    @FechaD1                            datetime,
    @FechaA1                            datetime,
    @MovTipo                            varchar(20),
    @IncentivoAsistencia 		            bit,
    @AguinaldoNavidad 		              bit,
    @ImporteInCentivoAsistencia         money, 
    @Ejercicio                          int,
    @EjercicioAnterior                  int,
    @AdeudoTotalVacaciones              float,
    @ImporteAdeudoTotalVacaciones       money,
    @BaseXIII                           money,
    @TipoContrato                       varchar(50),
    @VencimientoContrato                datetime,
    @SinAviso                           bit,
    @PeriodosFaltantes                  float,
    @AjusteAnual                        varchar(10),
    @Antiguedad1                        float,
    @AntiguedadMes1                     float,
    @Indemnizacion1                     money,                   
    @FechaAntiguedad1                   datetime,
    @CreditoAnterior                    money,
    @AcumuladoCreditoAnterior           money,
    @ImporteLicencias                   money,
    @CantidadLicencias                  money


  SELECT @MovTipo = Clave FROM Movtipo WHERE Modulo='NOM' AND Mov=@Mov
  SELECT @FechaD1 = @FechaD, 
         @FechaA1 = @FechaA

  SELECT  TOP 1
             @Compromisos       = Compromisos,
             @Preaviso          = Preaviso, 
             @PAdicionalIndemni = PadicionalIndemni,
             @UsaPrima          = PrimaAntiguedad,
             @UsaIndemnizacion  = Indemnizacion,
             @LiquidacionPanama = OPCIONESLIQUIDACIONPANAMA.LiquidacionPanama,
             @SinAviso          = SinAvisar
      FROM OPCIONESLIQUIDACIONPANAMA
      JOIN TipoLiquidacionPanama  ON  OPCIONESLIQUIDACIONPANAMA.LiquidacionPanama=TipoLiquidacionPanama.LiquidacionPanama
-- select *  FROM OPCIONESLIQUIDACIONPANAMA
  SELECT @EsInicioMes = 0, @EsFinMes = 0, @EsBimestre = 0,            @Incapacidades = 0, 
         @Faltas = 0, @EsAniversario = 0, @DiasNaturalesDiferencia = 0,
         @ISRBase = 0.0, @IMSSBase = 0.0, @ImpuestoEstatalBase = 0.0, @CedularBase = 0.0,
         @ISR = 0.0, @IMSSObrero = 0.0,   @IMSSPatron = 0.0,          @SueldoMinimo = 0.0, 
         @DomingosLaborados = 0.0,        @DiasAguinaldo = 0.0,       @DiasAguinaldoSiguiente = 0.0,
         @SueldoVariable = 0.0,           @AcumuladodiasmesXII = 0,   @SEEmpleadoAnualizado = 0

  SELECT @SucursalTrabajo	      = p.SucursalTrabajo,
         @SucursalTrabajoEstado        = s.Estado,
         @Categoria 		        = p.Categoria,
         @Puesto		            = p.Puesto,
         @Cliente		            = p.Cliente,
         @PersonalEstatus	      = p.Estatus,
         @PersonalCtaDinero	    = p.CtaDinero,
         @SDI	    		          = ISNULL(p.SDI, 0.0),
         @SueldoDiario		      = ISNULL(p.SueldoDiario, 0.0),
         @FechaAlta     	      = p.FechaAlta,
         @FechaAntiguedad	      = ISNULL(p.FechaAntiguedad, p.FechaAlta),
         @FechaBaja		          = p.FechaBaja,
         @Jornada		            = p.Jornada,
         @JornadaHoras		      = NULLIF(j.HorasPromedio, 0.0),
         @PersonalDiasPeriodo	  = UPPER(p.DiasPeriodo),
         @ZonaEconomica		      = p.ZonaEconomica,
         @UltimoPago		        = p.UltimoPago,
         @EsSocio		            = ISNULL(p.EsSocio, 0),
         @DiasPeriodoEstandar   = ISNULL(pt.DiasPeriodo, 0),
         @DescansaDomingos	    = ISNULL(j.Domingo, 0),
         @IndemnizacionPct	    = ISNULL(p.IndemnizacionPct, 100.0),
         @CantidadDependientes  = ISNULL(p.Dependientes, 0),
         @FactorAusentismo      = NULLIF(j.FactorAusentismo, 0.0),
         @SueldoMensual         = ISNULL(p.SueldoMensual, 0),
         @SueldoMensualPersonal = ISNULL(p.SueldoMensual, 0),
         @RataHora              = ISNULL(p.RataHora, 0),
         @HorasSemana           = ISNULL(j.HorasSemana, 0),
         @ISRFijoPeriodo        = ISNULL(p.ISRFijoPeriodo, 0),
         @TipoContrato          = TipoContrato,
         @VencimientoContrato   = p.VencimientoContrato              
    FROM Personal p
    LEFT OUTER JOIN PeriodoTipo pt ON pt.PeriodoTipo = p.PeriodoTipo
    LEFT OUTER JOIN Jornada j      ON j.Jornada      = p.Jornada 
    LEFT OUTER JOIN Sucursal s     ON s.Sucursal     = p.SucursalTrabajo
   WHERE p.Personal = @Personal AND p.PeriodoTipo = @PeriodoTipo

  IF @FechaA < @FechaAlta SELECT @Ok = 45010

--  IF  @MovTipo ='NOM.N'
 --   IF @UltimoPago > @FechaA    SELECT @Ok = 45020

  SELECT @DiasNaturalesOriginales = DATEDIFF(day, @FechaD, @FechaA) + 1

  IF @UltimoPago IS NULL SELECT @FechaD = @FechaAlta 

  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')
  BEGIN
    UPDATE Nomina SET Concepto = @LiquidacionPanama WHERE ID = @ID
    IF @UltimoPago IS NULL SELECT @FechaD = @FechaAlta ELSE SELECT @FechaD = DATEADD(day, 1, @UltimoPago)
    IF @PersonalEstatus = 'BAJA' SELECT @FechaA = ISNULL(@FechaBaja, @FechaTrabajo) ELSE SELECT @FechaA = FechaOrigen FROM Nomina WHERE ID = @ID
  END 
  IF @UltimoPago IS NULL SELECT @OK=1, @OkRef ='El empleado ('+@Personal+') Necesita Fecha de ULTIMOPAGO.'
  IF @CalendarioEsp = 0 SELECT @IncidenciaD = @FechaD, @IncidenciaA = @FechaA

  IF @NomTipo IN ('VACACIONES')
  BEGIN

    SELECT @DiasVacaciones = SUM (d.Cantidad)
      FROM IncidenciaD d
      JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto
      JOIN CFGNominaConcepto cfg ON nc.NominaConcepto = cfg.NominaConcepto 
     WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA
       AND (cfg.ClaveInterna = 'VacacionesTomadas' or especial='vacaciones')

    IF ISNULL(@DiasVacaciones,0) >0 
    BEGIN
      SELECT @FechaIniVacaciones = Min(i.FechaD)
        FROM IncidenciaD d
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus in( 'PENDIENTE', 'CONCLUIDO' )
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto --AND RequiereDiasTrabajados = 0
        JOIN CFGNominaConcepto cfg ON nc.NominaConcepto = cfg.NominaConcepto 
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA
         AND cfg.ClaveInterna = 'Vacaciones'
      
      SELECT @FechaFinVacaciones = Max(i.FechaA)
        FROM IncidenciaD d
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus in( 'PENDIENTE', 'CONCLUIDO' )
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto --AND RequiereDiasTrabajados = 0
        JOIN CFGNominaConcepto cfg ON nc.NominaConcepto = cfg.NominaConcepto 
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA
         AND cfg.ClaveInterna = 'Vacaciones'

      SELECT @DiasVacaciones = 0 --  se usa mas abajo y traeria un valor basura
    END ELSE
      SELECT @OK = 1, @OKREF = 'El Empleado' + @Personal + 'No Tiene Vacaciones Capturadas'   
  END ELSE
  IF @NomTipo IN ('NORMAL')
  BEGIN
    SELECT @DiasVacaciones = 0

    SELECT @DiasVacaciones = SUM (d.Cantidad)
      FROM IncidenciaD d
      JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND RequiereDiasTrabajados = 0
      JOIN CFGNominaConcepto cfg ON nc.NominaConcepto = cfg.NominaConcepto 
     WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA
       AND cfg.ClaveInterna = 'VacacionesTomadas'

    IF ISNULL(@DiasVacaciones,0) > 0 
      SELECT @OK=1, @OKREF = '<BR> El Empleado '+ @Personal +' Tiene Vacaciones Pendientes<BR> Tienes Que afectar la planilla de VACACIONES <BR> antes que la NORMAL.'   
  END
  SELECT @Ejercicio = YEAR(@IncidenciaA)
  SELECT @EjercicioAnterior = @Ejercicio - 1
  SELECT @RedondeoMonetarios = RedondeoMonetarios FROM Version
  SELECT @SMDF = SueldoMinimo FROM ZonaEconomica WHERE Zona = 'A'
  SELECT @SMZ =  SueldoMinimo FROM ZonaEconomica WHERE Zona = @ZonaEconomica
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Tipo de Calculo ISR', 	      			@TipoCalculoISR OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Mes', 	      			    @DiasMes OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Ano',         			    @DiasAno OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Ano ISR',         			@DiasAnoISR OUTPUT 
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Aguinaldo', 			      @DiasAguinaldoSt OUTPUT   
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Prima Dominical', 			      @PrimaDominicalPct OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Prima Vacacional', 			    @PrimaVacacionalPct OUTPUT 
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor SHCP',          			@AcreedorISR OUTPUT 
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor IMSS',          			@AcreedorIMSS OUTPUT 
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia',		      @PensionAAcreedor OUTPUT 
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia 2',		    @PensionAAcreedor2 OUTPUT 
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia 3',		    @PensionAAcreedor3 OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto',  	@PensionASueldoBruto OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto 2',	@PensionASueldoBruto2 OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto 3',	@PensionASueldoBruto3 OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto',   	@PensionASueldoNeto OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto 2', 	@PensionASueldoNeto2 OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto 3', 	@PensionASueldoNeto3 OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Pension Alimenticia',   	@PensionA OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Pension Alimenticia 2', 	@PensionA2 OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Pension Alimenticia 3', 	@PensionA3 OUTPUT 
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Gastos Representacion liquidacion(S/N)',		@GastosLiquidacion OUTPUT 
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Usar Ajuste ISR Anual(S/N)',		@AjusteAnual OUTPUT 

  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Beneficiario Sueldo Neto',			@BeneficiarioSueldoNeto OUTPUT 
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ No Gravable Personal',			@MontoNoGravablePersonal OUTPUT 
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ No Gravable Conyugue',			@MontoNoGravableConyugue OUTPUT 
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ No Gravable Dependientes',		@MontoNoGravableDependientes OUTPUT 
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Tiene Conyugue (S/N)',			@TieneConyugue OUTPUT 
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Usar Incentivo Asistencia(S/N)',			@IncentivoAsistencia OUTPUT 
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Usar Aguinaldo de Navidad(S/N)',			@AguinaldoNavidad OUTPUT 
  IF @TieneConyugue = 0  SELECT @MontoNoGravableConyugue = 0.0
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Tabla ISR',				@ISRTabla OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Social Empleado', 		@SSEmpleadoPct OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Social Jubilado', 		@SSJubiladoPct OUTPUT 
  IF @FECHAA < CONVERT(datetime,'1/1/2008',103) SELECT @SSEmpleadoPct = 7.25 ELSE
  IF @FECHAA < CONVERT(datetime,'1/1/2011',103) SELECT @SSEmpleadoPct = 8 ELSE
  IF @FECHAA < CONVERT(datetime,'1/1/2013',103) SELECT @SSEmpleadoPct = 9   ELSE SELECT @SSEmpleadoPct = 9.75
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Social Parton', 			@SSPatronPct OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Educativo Empleado', 		@SEEmpleadoPct OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Seguro Educativo Parton', 		@SEPatronPct OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Riesgo Profesional', 			@RiesgoProfesionalPct OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% ISR GR', 			        @PctISRGR OUTPUT 
  IF EXISTS (SELECT * FROM Personal WHERE Tipo='Jubilado' AND Personal = @Personal) SELECT @SSEmpleadoPct = @SSJubiladoPct, @SEEmpleadoPct=0, @SEPatronPct=0
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Importe Comisiones',		 @ImporteComisiones OUTPUT 
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Importe PRIM.PRODUCC.', @ImportePrimProd OUTPUT 
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Importe VIATICOS',		   @ImporteViaticos OUTPUT 
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Frecuencia Comisiones',		   @FrecuenciaComisiones OUTPUT 
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Frecuencia PRIM.PRODUCC.',   @FrecuenciaPrimProd OUTPUT 
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Frecuencia VIATICOS',		     @FrecuenciaViaticos OUTPUT 
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Sindicato',			  @Sindicato$ OUTPUT 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Sindicato', 		    @SindicatoPr OUTPUT 
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Metodo % Sindicato',		  @SindicatoMetodo OUTPUT 
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Frecuencia % Sindicato', @SindicatoFrecuencia OUTPUT  
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Acreedor % Sindicato',   @SindicatoAcreedorPr OUTPUT 
  EXEC spPersonalPropValor @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal,  'Acreedor $ Sindicato',   @SindicatoAcreedor$ OUTPUT 
  SELECT @Dia = DAY(@FechaA), @Mes = MONTH(@FechaA), @Ano = YEAR(@FechaA)
  EXEC spIntToDateTime  1,  1, @Ano, @PrimerDiaAnoREAL OUTPUT
  SELECT @PrimerDiaAno=@PrimerDiaAnoREAL
  EXEC spIntToDateTime 31, 12, @Ano, @UltimoDiaAno OUTPUT
  SELECT @PrimerDiaAnoAnterior = DATEADD(year, -1, @PrimerDiaAno),  @UltimoDiaAnoAnterior = DATEADD(year, -1, @UltimoDiaAno)
  IF @FechaAntiguedad > @PrimerDiaAno SELECT @PrimerDiaAno = @FechaAntiguedad
  IF ISNUMERIC(@DiasAguinaldoSt) = 1 
    SELECT @DiasAguinaldo = CONVERT(float, @DiasAguinaldoSt), 
           @DiasAguinaldoSiguiente = CONVERT(float, @DiasAguinaldoSt)
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')
    SELECT @SueldoMinimo = 0.0
  ELSE
  IF @CfgSueldoMinimo = 'OFICIAL' 
    SELECT @SueldoMinimo = @SMDF * @DiasMes * 1.3
  IF @FechaAlta > @FechaD SELECT @FechaD = @FechaAlta
  SELECT @DiasNaturales = DATEDIFF(day, @FechaD, @FechaA) + 1
  SELECT @DiasNaturalesDiferencia = @DiasNaturalesOriginales - @DiasNaturales
  SELECT @DiasPeriodo = @DiasNaturales
  IF @NomTipo = 'NORMAL'
  BEGIN
    IF @PersonalDiasPeriodo = 'DIAS PERIODO'
      SELECT @DiasPeriodo = @DiasPeriodoEstandar - @DiasNaturalesDiferencia
    ELSE
    IF @PersonalDiasPeriodo = 'DIAS JORNADA'
    BEGIN
      EXEC spJornadaDiasLibres @Jornada, @FechaD, @FechaA, @JornadaDiasLibres OUTPUT
      SELECT @DiasPeriodo = dbo.fnMayor(0, @DiasNaturales - @JornadaDiasLibres)
    END
    ELSE BEGIN 
      IF @PersonalDiasPeriodo = 'RATA POR HORA'
      BEGIN
      
        SELECT @HorasPeriodo = ISNULL(SUM(DATEDIFF(mi, Entrada, Salida)/60.0),0) 
          FROM PersonalJornadaTiemposPanama 
         WHERE Entrada BETWEEN @FechaD1 and @FechaA1
           AND Personal = @Personal

        SELECT @DiasPeriodo= ISNULL(COUNT(Entrada),0) 
          FROM PersonalJornadaTiemposPanama 
         WHERE Entrada BETWEEN @FechaD1 and @FechaA1
           AND Personal = @Personal

        IF ISNULL(@HorasPeriodo,0) = 0 
        BEGIN 
          SELECT @HorasPeriodo= ISNULL(SUM(DATEDIFF(mi, Entrada, Salida)/60.0),0) 
            FROM JornadaTiempo 
           WHERE Entrada BETWEEN @FechaD1 and @FechaA1
             AND Jornada = @Jornada

          SELECT @DiasPeriodo = ISNULL(COUNT( Entrada),0) 
            FROM JornadaTiempo 
           WHERE Entrada BETWEEN @FechaD1 and @FechaA1
             AND Jornada = @Jornada
        END 
-- si no encontre suficentes horas en las tablas tomo el "estandar"
        IF ISNULL(@HorasPeriodo,0) < 70 
          SELECT @HorasPeriodo = @HorasSemana * 4.33 / 2.0

        IF ISNULL(@HorasPeriodo,0) < 70 
        BEGIN
          SELECT @OK=1, @OKRef='la Jornada(' + @Jornada +') esta mal generada para el personal -' + @Personal
          RETURN
        END
      END
    END
  END

  IF @NomTipo = 'AGUINALDO'
    SELECT  @DiasPeriodo = dbo.fnMenor(@DiasAguinaldo, @DiasPeriodo)
  EXEC spFechaAniversario @FechaAntiguedad, @FechaA, @FechaAniversario OUTPUT
  /* Para que pague la quincena de maximo 15 dias y no de 16 */
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') AND @PeriodoTipo IN ('QUINCENAL', 'MENSUAL') AND (SELECT dbo.fnEsFinMes(@FechaA)) = 0
   SELECT @DiasPeriodo = @DiasNaturales

  SELECT @DiasMes = NULLIF(@DiasMes, 0), @DiasMesTrabajados = NULLIF(@DiasMesTrabajados, 0), @DiasBimestre = NULLIF(@DiasBimestre, 0),
         @DiasBimestreTrabajados = NULLIF(@DiasBimestreTrabajados, 0), @DiasAno = NULLIF(@DiasAno, 0), 
         @DiasPeriodo = NULLIF(@DiasPeriodo, 0), @DiasTrabajados = NULLIF(@DiasTrabajados, 0), @DiasNaturales = NULLIF(@DiasNaturales, 0),
         @DiasNaturalesTrabajados = NULLIF(@DiasNaturalesTrabajados, 0), @DiasNaturalesOriginales = NULLIF(@DiasNaturalesOriginales, 0),
         @DiasNaturalesDiferencia = NULLIF(@DiasNaturalesDiferencia, 0)

  SELECT @Antiguedad = dbo.fnAntiguedad(@FechaAntiguedad, @FechaA)
  SELECT @AntiguedadSiguiente = dbo.fnAntiguedad(@FechaAntiguedad, @FechaA) + 1  
  SELECT @AntiguedadFlotante = ROUND(dbo.fnAntiguedadFloat(@FechaAntiguedad, @FechaA),2)

  SELECT @AntiguedadDia = DAY(@FechaAntiguedad), @AntiguedadMes = MONTH(@FechaAntiguedad), @FechaDAno = YEAR(@FechaD), @FechaAAno = YEAR(@FechaA)
  EXEC spIntToDateTime @AntiguedadDia, @AntiguedadMes, @FechaDAno, @FechaDAntiguedad OUTPUT
  EXEC spIntToDateTime @AntiguedadDia, @AntiguedadMes, @FechaAAno, @FechaAAntiguedad OUTPUT
  EXEC spTablaNum @CfgTablaVacaciones, @Antiguedad, @DiasVacaciones OUTPUT
  EXEC spTablaNum @CfgTablaVacaciones, @AntiguedadSiguiente, @DiasVacacionesSiguiente OUTPUT
  IF @Antiguedad > 0 AND (@FechaDAntiguedad BETWEEN @FechaD AND @FechaA OR @FechaAAntiguedad BETWEEN @FechaD AND @FechaA)
    SELECT @EsAniversario = 1

  IF ISNUMERIC(@DiasAguinaldoSt) = 0 
  BEGIN
    EXEC spTablaNum @DiasAguinaldoSt, @Antiguedad,          @DiasAguinaldo OUTPUT
    EXEC spTablaNum @DiasAguinaldoSt, @AntiguedadSiguiente, @DiasAguinaldoSiguiente OUTPUT
  END

  IF @NomTipo IN ('AJUSTE ANUAL')
  BEGIN
    SELECT @ISRBaseAcumulado=SUM(ISNULL(CASE WHEN D.MOVIMIENTO='DEDUCCION'THEN D.IMPORTE*-1 ELSE D.IMPORTE END,0))
      FROM Nomina n, NominaD d, MovTipo mt
     WHERE n.ID       = d.ID
       AND n.Estatus IN('CONCLUIDO')
       AND n.Empresa  = @EMPRESA
       AND n.FechaA BETWEEN @PrimerDiaAno and @UltimoDiaAno AND mt.Clave IN ('NOM.N', 'NOM.NE') 
       AND n.Mov      = mt.Mov
       AND mt.Modulo  = 'NOM'
       AND d.Personal = @Personal
       AND d.NominaConcepto IN(SELECT NominaConcepto FROM NominaConcepto WHERE GravaISR = 'SI' )
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'SE/Empleado',   @PrimerDiaAno, @UltimoDiaAno, NULL, @AcumuladoSE OUTPUT, @DiasAcumuladosSE OUTPUT


    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/ISR',       @PrimerDiaAno, @UltimoDiaAno, NULL, @ISRAcumulado OUTPUT, NULL
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/ISRAjuste',       @PrimerDiaAno, @UltimoDiaAno, NULL, @ISRAcumuladoAjuste OUTPUT, NULL

    SELECT @AcumuladoSE      = @AcumuladoSE + ISNULL(@SEEmpleado,0)
    SELECT @ISRBaseAcumulado = @ISRBaseAcumulado - (
                                      @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                   + (@MontoNoGravableDependientes * @CantidadDependientes)
                                   +  @AcumuladoSE )

    SELECT @ISRBaseAcumulado = @ISRBaseAcumulado + ISNULL(@ISRBase,0)

    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/BaseAcumAnual', @Empresa, @Personal, NULL, @ISRBaseAcumulado 
    EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseAcumulado, @ISRProyectado OUTPUT
    SELECT @ISR = @ISRProyectado - (@ISRAcumulado + @ISRAcumuladoAjuste)
   EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Anual', @Empresa, @Personal, NULL, @ISR 
    IF @ISR < 0   --- salio a favor del trabajador si no ni se usa
    BEGIN
      SELECT  @ISR = ABS(@ISR) 
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/AjusteAnual', @Empresa, @Personal, NULL, @ISR 
-- select * from cfgnominaconcepto
    END
    RETURN
  END

  SELECT @PrimaVacacional = @SueldoDiario * @DiasVacaciones * (@PrimaVacacionalPct/100.0)

  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')
  BEGIN
    SELECT @DiasVacacionesProporcion = @DiasVacacionesSiguiente * dbo.fnAntiguedadFloat(@FechaAniversario, @FechaA)
    SELECT @PrimaVacacionalProporcion = @SueldoDiario * @DiasVacacionesProporcion * (@PrimaVacacionalPct/100.0)
  END 
 --- SELECT @SueldoMensual = @SueldoDiario * @DiasMes
  SELECT @PrimerDiaMes  = DATEADD(day, 1-DAY(@FechaD), @FechaD)
  SELECT @UltimoDiaMes = DATEADD(dd, -1, DATEADD(mm, 1, @PrimerDiaMes))
  SELECT @PrimerDiaMesAnterior = DATEADD(month, -1, @PrimerDiaMes)
  SELECT @UltimoDiaMesAnterior = DATEADD(day, -1, @PrimerDiaMes)
  SELECT @ISRVencimiento = DATEADD(DAY, 5, DATEADD(MONTH, 2, @PrimerDiaMes))
  SELECT @IMSSVencimiento = @ISRVencimiento, @IMSSVencimientoBimestre = @ISRVencimiento, @ImpuestoEstatalVencimiento = @ISRVencimiento
  IF MONTH(@FechaA) % 2 <> 0 SELECT @IMSSVencimientoBimestre = DATEADD(month, 1, @IMSSVencimientoBimestre)
  IF MONTH(@FechaA) <> MONTH(DATEADD(day, @DiasNaturalesOriginales, @FechaA)) 
  BEGIN
    SELECT @EsFinMes = 1  
    IF MONTH(@FechaA) % 2 = 0 SELECT @EsBimestre = 1, @PrimerDiaBimestre = DATEADD(month, -1, @PrimerDiaMes)
  END
 
  IF @PrimerDiaMes BETWEEN @FechaD AND @FechaA SELECT @EsInicioMes = 1
 
  IF @NomTipo IN ('NORMAL', 'AJUSTE', 'FINIQUITO', 'LIQUIDACION', 'VACACIONES')
  BEGIN
--- gatos representacion 
      IF @DiasPeriodo >= 13 AND MONTH(@FechaD1) = 2 AND @EsFinMes = 1 -- para el caso de febrero 28
        SELECT @Gastos = @SDI / 30.0 * @DiasPeriodoEstandar
      ELSE
        SELECT @Gastos = @SDI / 30.0 * DBO.fnMenor(@DiasPeriodoEstandar, @DiasPeriodo)
-- Sueldo
    IF @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')
    BEGIN
      IF @PeriodoTipo = 'Quincenal' AND @NomTipo IN ('NORMAL') 
      BEGIN
        IF @PersonalDiasPeriodo = 'RATA POR HORA'  
        BEGIN

          SELECT @SueldoMensual =  ROUND(dbo.fnPanamaSueldoMensual(@Personal, @FechaD1),2)
--          SELECT @SueldoPeriodo = dbo.fnMayor(@RataHora * @HorasPeriodo, dbo.fnPanamaSueldoMensual(@Personal, @FechaD1) / 2.0)
          SELECT @SueldoPeriodo = @RataHora * @HorasPeriodo
        END
        ELSE        
          SELECT @SueldoPeriodo = ROUND(dbo.fnPanamaSueldoMensual(@Personal, @FechaD1) / 2.0,2)
      END
      ELSE  
        IF @PeriodoTipo = 'Semanal' AND @NomTipo IN ('NORMAL')
          SELECT @SueldoPeriodo = @RataHora * @HorasPeriodo
     
      IF @EsFinMes = 1 AND @PeriodoTipo = 'Quincenal' -- esto es para Ajustar los centavo para que cuadre conel sueldo mensual al centavo
      BEGIN
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Sueldo', @PrimerDiames, @FechaA, NULL, @Sueldo OUTPUT, @DiasTrabajados OUTPUT 
        SELECT @Sueldo= ISNULL(@Sueldo,0)
        IF ABS(ROUND(@SueldoMensual,2) -( ROUND(ROUND(@Sueldo, 2) + ROUND(@SueldoPeriodo, 2), 2))) < 0.05 AND @PersonalDiasPeriodo <> 'RATA POR HORA'
          SELECT @SueldoPeriodo =ROUND(ROUND(@SueldoPeriodo, 2) +ROUND(@SueldoMensual, 2) -( ROUND(ROUND(@Sueldo, 2) + ROUND(@SueldoPeriodo, 2), 2)), 2)
      END
      IF @NomTipo IN ('LIQUIDACION')
      BEGIN
        EXEC spDiasHabilesPanama @personal, @FechaD, @FechaA, @Dias output
        SELECT @DiasPeriodo=@Dias
        SELECT @SueldoPeriodo = @DiasPeriodo * @SueldoDiario
        IF @TipoContrato = 'Eventual' AND exists(Select 1 where  @LiquidacionPanama  like '%injustificado%')
        BEGIN
          SELECT @VencimientoContrato = CONVERT(datetime, dbo.fnMayor(CONVERT(float, @VencimientoContrato), CONVERT(float, @FechaA)))
          EXEC spDiasHabilesPanama @personal, @FechaD, @VencimientoContrato, @Dias output
          SELECT @DiasPeriodo =  @Dias
          SELECT @SueldoPeriodo = @DiasPeriodo * @SueldoDiario
        END

-- update personal set tipocontrato = 'Eventual', Vencimientocontrato='2007-06-10' where personal='e00076'
-- select * from opcionesliquidacionpanama where  personal='e00076'
-- select * from tIPOlIQUIDACIONpANAMA where id=1251
-- select * from personal where personal='e00076'
-- update opcionesliquidacionpanama set liquidacionpanama='Despido InJustificado - Permanente'  
       
      END

      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Sueldo', @Empresa, @Personal, @DiasPeriodo, @SueldoPeriodo
      IF @NomTipo IN ('LIQUIDACION')
      BEGIN
         IF @GastosLiquidacion ='S' 
           EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, NULL, @Gastos
      END ELSE
        IF @NomTipo ='AGUINALDO'
          EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacionXIII', @Empresa, @Personal, NULL, @Gastos
        ELSE
           EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, NULL, @Gastos
           
      SELECT @Valor = 0
      IF @FrecuenciaComisiones = 'Cada Nomina' SELECT @Valor = @ImporteComisiones / 2.0
      IF @FrecuenciaComisiones = 'Inicio mes' AND @FechaA = 15 SELECT @Valor = @ImporteComisiones  
      IF @FrecuenciaComisiones = 'Fin mes' AND @FechaA <> 15   SELECT @Valor = @ImporteComisiones  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ComisionesFijos', @Empresa, @Personal, NULL, @Valor
      SELECT @Valor = 0
      IF @FrecuenciaViaticos = 'Cada Nomina' SELECT @Valor = @ImporteViaticos / 2.0
      IF @FrecuenciaViaticos = 'Inicio mes' and @FechaA = 15 SELECT @Valor = @ImporteViaticos
      IF @FrecuenciaViaticos = 'Fin mes' and @FechaA <> 15   SELECT @Valor = @ImporteViaticos
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ViaticosFijos', @Empresa, @Personal, NULL,   @Valor
      SELECT @Valor = 0
      IF @FrecuenciaPrimProd = 'Cada Nomina' SELECT @Valor = @ImportePrimProd / 2.0
      IF @FrecuenciaPrimProd = 'Inicio mes' and @FechaA = 15 SELECT @Valor = @ImportePrimProd
      IF @FrecuenciaPrimProd = 'Fin mes' and @FechaA <> 15   SELECT @Valor = @ImportePrimProd
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimasProdFijos', @Empresa, @Personal, NULL, @Valor
    END
    IF @NomTipo IN ('AJUSTE')
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, NULL, @Gastos

    -- Incentivo De Asistencia
    IF @IncentivoAsistencia = 1 AND EXISTS(SELECT * FROM Personal  WHERE Personal = @Personal AND ISNULL(NULLIF(ISNULL(Sindicato,''),'Ninguno'),'(Confianza)') <> '(Confianza)')
    BEGIN
      EXEC spNominaincentivosAsistencia	@Empresa, @Personal,  @Ejercicio,  'Ausentismo',  @Cantidad OUTPUT
      SELECT @ImporteInCentivoAsistencia = @Cantidad * @RataHora 
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'incentivoAsistencia', @Empresa, @Personal, @Cantidad, @ImporteInCentivoAsistencia
    END

    -- Incidencias Manuales
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')
    BEGIN
      INSERT #Nomina (
             Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe) 
      SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)
        FROM IncidenciaD d
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto /*AND ISNULL(nc.Especial, '') <> 'Horas Extras' AND RequiereDiasTrabajados = 0 */
         AND nc.Movimiento = 'Percepcion'
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion <= @FechaBaja

      IF @Compromisos <>'Ninguno'
        INSERT #Nomina (
               Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe) 
        SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)
          FROM IncidenciaD d
          JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'
          JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto /*AND ISNULL(nc.Especial, '') <> 'Horas Extras' AND RequiereDiasTrabajados = 0 */
           AND nc.Movimiento <> 'Percepcion'
          LEFT OUTER JOIN incidenciapanama on incidenciapanama.id =i.id
          LEFT OUTER JOIN TipoDeduccion on IncidenciaPanama.TipoDeduccion = TipoDeduccion.TipoDeduccion 
          LEFT OUTER JOIN TipoRetencion on IncidenciaPanama.TipoRetencion = TipoRetencion.TipoRetencion
                      AND IncidenciaPanama.TipoRetencion like 'COMPROMISO%'
         WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL /*AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA*/
    END ELSE
      INSERT #Nomina (
             Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe) 
      SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)
        FROM IncidenciaD d
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto /*AND ISNULL(nc.Especial, '') <> 'Horas Extras' */
         AND RequiereDiasTrabajados = 0
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA

---se borran todos los conceptos que no aplican para este MOV
    DELETE #Nomina
      FROM #Nomina n
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)
       AND n.Personal = @Personal
    EXEC xpNominaCalcIncidencia @NomTipo, @Empresa, @Personal, @FechaD, @FechaA, @IncidenciaD, @IncidenciaA, @TipoCambio, @Ok OUTPUT, @OkRef OUTPUT  

-- Faltas 
    SELECT @Faltas = ISNULL(SUM(d.Cantidad), 0), @FaltasImporte = ISNULL(SUM(d.Importe), 0)
      FROM #Nomina d
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Especial = 'Faltas'
     WHERE d.Personal = @Personal 
-- Incapacidades
    SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)
      FROM #Nomina d
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Especial = 'Incapacidades'
     WHERE d.Personal = @Personal 

-- ojo esto lo agregue para borrar las incapacidads de mas de dias del peridoo
    WHILE @Incapacidades > @DiasPeriodo and @incapacidades > 0 AND @PersonalEstatus='ALTA'
    BEGIN
      SELECT @MaxID = ISNULL(MAX (IncidenciaID), 0), @MaxRID= ISNULL(MAX (IncidenciaRID), 0)
        FROM #Nomina d
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'
       WHERE d.Personal = @Personal

      DELETE #Nomina WHERE IncidenciaID = @Maxid AND IncidenciaRID=@MaxRid
      SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)
        FROM #Nomina d
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'
       WHERE d.Personal = @Personal
    END

    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Incapacidades', @FechaD, @FechaA, NULL, NULL, @IncapacidadesD OUTPUT

    WHILE (@Incapacidades+@IncapacidadesD) > @DiasPeriodo and (@Incapacidades+@IncapacidadesD) > 0  and (@IncapacidadesD <= @DiasPeriodo) AND @PersonalEstatus='ALTA'
    BEGIN
      SELECT @MaxID = ISNULL(MAX (IncidenciaID), 0), @MaxRID= ISNULL(MAX (IncidenciaRID), 0)
        FROM #Nomina d
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'
       WHERE d.Personal = @Personal 
      DELETE #Nomina WHERE IncidenciaID = @Maxid AND IncidenciaRID=@MaxRid
      SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)
        FROM #Nomina d
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'
       WHERE d.Personal = @Personal
    END


    -- Registrar Faltas e Incapacidades
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Faltas',        @Empresa, @Personal, @Faltas,        @FaltasImporte

    -- Sueldo Variable (XIII)
    SELECT @SueldoVariable = ISNULL(SUM(d.Importe), 0)
      FROM #Nomina d
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.SueldoVariable = 1
     WHERE d.Personal = @Personal 

    EXEC spNominaClaveInternaEstaNomina @Personal, 'VacacionesTomadas', @VacacionesTomadas OUTPUT
    --SELECT @SueldoPeriodo = @SueldoDiario * @DiasPeriodo

--- vacaciones cambio
    IF @NomTipo IN ('VACACIONES')
    BEGIN
      SELECT @SDI = @SDI / @Diasmes * @VacacionesTomadas
      EXEC spNominaPanamaSueldoDiarioVariableVacaciones  @Empresa, @Personal, @FechaAlta, @SueldoMensual, @ImporteComisiones, @ImportePrimProd, @FechaD1, @SueldoDiarioVariable OUTPUT      
    END

    IF @NomTipo = 'AJUSTE'
    BEGIN
      EXEC spNominaClaveInternaEstaNomina @Personal, 'Sueldo', @DiasNaturales OUTPUT
      SELECT @DiasPeriodo = @DiasNaturales
    END

    SELECT @Calc = -@VacacionesTomadas
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @Calc
    SELECT @DiasNaturalesTrabajados = dbo.fnMayor(0, @DiasNaturales - @Faltas - @Incapacidades)
    SELECT @DiasTrabajados = @DiasPeriodo - @Incapacidades - @Faltas
    IF @NomTipo <> 'AJUSTE' AND @DiasTrabajados<0.0  SELECT @DiasTrabajados = 0.0
    SELECT @DiasTrabajadosImporte = (@SueldoDiario*@DiasPeriodo) + @SueldoVariable - @FaltasImporte - @IncapacidadesImporte
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasPeriodo',   		@Empresa, @Personal, @DiasPeriodo
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasNaturales', 		@Empresa, @Personal, @DiasNaturales
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasTrabajados', 		@Empresa, @Personal, @DiasTrabajados, @DiasTrabajadosImporte
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/SueldoDiario',  	@Empresa, @Personal, @Importe = @SueldoDiario
    IF @DiasTrabajados > 0
    BEGIN
      IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')
        INSERT #Nomina (
               Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Cuenta,     Vencimiento,   Cantidad,   Importe) 
        SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)
          FROM IncidenciaD d
          JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'
          JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND RequiereDiasTrabajados = 1
         WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL 
      ELSE
        INSERT #Nomina (
               Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Cuenta,     Vencimiento,   Cantidad,   Importe) 
        SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)
          FROM IncidenciaD d
          JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'
          JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND RequiereDiasTrabajados = 1
         WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA
    END

    IF @CfgPrimaDominicalAuto = 1 AND (@DescansaDomingos = 0 OR @LaboraDomingos = 1)
    BEGIN
      EXEC spNominaDomingosLaborados @Empresa, @Personal, @FechaD, @FechaA, @IncidenciaD, @IncidenciaA, @DomingosLaborados OUTPUT
      SELECT @PrimaDominical = @DomingosLaborados * (@SueldoDiario * (@PrimaDominicalPct/100.0))
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaDominical', @Empresa, @Personal, @DomingosLaborados, @PrimaDominical
    END

    -- Prima Vacacional
    IF @NomTipo = 'NORMAL' AND @EsAniversario = 1
    BEGIN
      IF @OtorgarDiasVacacionesAniversario = 1
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @DiasVacaciones
      IF @OtorgarPrimaVacacionalAniversario = 1 
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaVacacional', @Empresa, @Personal, @DiasVacaciones, @PrimaVacacional
    END ELSE
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')
    BEGIN
      IF @Antiguedadflotante < = 2 AND @Preaviso = 1
      BEGIN
        SELECT @SueldoVariableVacacionesD = DATEADD(mm, -6, @IncidenciaA)
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'SUELDO', @SueldoVariableVacacionesD, @IncidenciaA, NULL, NULL, @DiasTrabajados OUTPUT
        EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableVacacionesD, @IncidenciaA, @SueldoVariableAcumulado OUTPUT
        SELECT @PreavisoImporte = @SueldoMensual
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Preaviso', @Empresa, @Personal, @DiasTrabajados, @PreavisoImporte
      END
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'DiasVacaciones', @FechaAntiguedad, @FechaA, NULL, NULL, @DiasVacacionesAcumulado OUTPUT
      SELECT @Calc = -@DiasVacacionesAcumulado
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @Calc
      IF @FechaAlta > (DATEADD(mm, -11, @FechaA) + 1)
        SELECT @SueldoVariableVacacionesD = @FechaAlta -- se toman 11 meses menos de la fecha de calculo sueldo variable o la fecha de alta
      ELSE
        SELECT @SueldoVariableVacacionesD = (DATEADD(mm, -11, @FechaA) + 1) --se toman 11 meses menos de la fecha de calculo sueldo variable o la fecha de alta
      SELECT @DiasVacaciones = SUM(VacacionesDias) FROM AcumuladosPersonalPanamaejercicio WHERE Personal = @PErsonal

      EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableVacacionesD, @SueldoVariableVacacionesA, @SueldoVariableAcumulado OUTPUT
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'GastosRepresentacion',@SueldoVariableVacacionesD, @SueldoVariableVacacionesA, NULL, @Gastos OUTPUT, NULL

      SELECT @Gastos = @Gastos / 11.0 / 30.0 * @DiasVacaciones


      SELECT @SueldoVariableAcumulado =(@SueldoVariableAcumulado / 11.0 /30.0 * @DiasVacaciones) + (@BaseVacaciones/11.0)

      IF @Nomtipo = 'Liquidacion' 
        IF @GastosLiquidacion ='S' 
          EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion',      @Empresa, @Personal, @SueldoVariableAcumulado, @Gastos
      SELECT @Vacaciones = @SueldoVariableAcumulado --/ 11.0
      SELECT @SueldoDiarioVariable = @SueldoVariableAcumulado --/ (ABS(DATEDIFF(dd,@SueldoVariableVacacionesD, @SueldoVariableVacacionesA)) + 1)  

--select @SueldoVariableAcumulado, @Vacaciones
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Vacaciones',      @Empresa, @Personal, @SueldoVariableAcumulado, @Vacaciones
      UPDATE #Nomina SET Movimiento = 'Estadistica' -- esto es por que en la liquidacion las vacaciones son siempre una percepcion 
       WHERE Personal       = @Personal 
         AND NominaConcepto = '172'
    END

    IF @TieneValesDespensa = 1 AND @EsFinMes = 1 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')
    BEGIN
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Faltas',        @PrimerDiaMes, @FechaA, NULL, NULL, @FaltasAcumulado OUTPUT
-- ojo      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Incapacidades', @PrimerDiaMes, @FechaA, NULL, NULL, @IncapacidadesAcumulado OUTPUT
      SELECT @DiasMesTrabajados = dbo.fnMayor(0, @DiasMes - @Faltas - @FaltasAcumulado - @Incapacidades - @IncapacidadesAcumulado)
      SELECT @ValesDespensaImporte = @ValesDespensaImporte + (@SueldoDiario*@DiasMesTrabajados*(@ValesDespensaPct/100.0))
--      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ValesDespensa', @Empresa, @Personal, @Importe = @ValesDespensaImporte
    END

    IF @PremioPuntualidadPct > 0.0 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')
    BEGIN
      SELECT @CalcImporte = @DiasTrabajados*@SDI*(@PremioPuntualidadPct/100.0)
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PremioPuntualidad', @Empresa, @Personal, @DiasTrabajados, @CalcImporte
    END
 
    IF @PremioAsistenciaPct > 0.0 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')
    BEGIN
      SELECT @CalcImporte = @DiasTrabajados * @SDI * (@PremioAsistenciaPct / 100.0)
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PremioAsistencia', @Empresa, @Personal, @DiasTrabajados, @CalcImporte
    END

    -- Subsidio Incapacidad EG
    IF @CfgSubsidioIncapacidadEG = 1 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')
      EXEC spNominaSubsidioIncapacidadEG @Empresa, @Personal, @SueldoDiario, @SDI, @Ok OUTPUT, @OkRef OUTPUT

  END  -- Nominas Normales

  -- Aguinaldo   es el mes XIII en panama se paga 3 veces al a�o 10 dias cada ves el importe se saca del promedio de los 4 meses use el check sueldo variable para este fin
  --             se paga en la 1-15 abril, 1-15 de agosto y 1-15 de diciembre.        

  IF @NomTipo in('AGUINALDO', 'LIQUIDACION')
  BEGIN-- puse esto para que el aguinaldo tambien jale incidencias manuales
    INSERT #Nomina (
           Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Movimiento,    Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe) 
    SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, nc.Movimiento, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)
      FROM IncidenciaD d
      JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto /*AND ISNULL(nc.Especial, '') <> 'Horas Extras' */AND RequiereDiasTrabajados = 0
     WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion BETWEEN @IncidenciaD AND @IncidenciaA

    DELETE #Nomina
      FROM #Nomina n
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)
       AND n.Personal = @Personal



    SELECT @SueldoVariableDias = 120 -- por que en panama lo redondean siempre
    SELECT @SueldoVariableAguinaldoA = @FechaA 

 -- para saber en que mes corre el mes XIII
    SELECT @Ano = YEAR(@SueldoVariableAguinaldoA) 
    IF MONTH(@SueldoVariableAguinaldoA) <= 4 -- DE ACUERDO A EL MES EN QUE SE CORRE ES EL PERIODO DE 
    BEGIN
      EXEC spIntToDateTime  15,  4,  @Ano, @SueldoVariableAguinaldoA OUTPUT 
      SELECT @Ano = @Ano - 1
      EXEC spIntToDateTime  16,  12, @Ano, @SueldoVariableAguinaldoD OUTPUT 
      EXEC spIntToDateTime  16,  8,  @Ano, @SueldoVariableAguinaldoD1 OUTPUT 
      EXEC spIntToDateTime  15,  12, @Ano, @SueldoVariableAguinaldoA1 OUTPUT 
    END ELSE
    IF MONTH(@SueldoVariableAguinaldoA) <= 8 
    BEGIN
      EXEC spIntToDateTime  16,  4,  @Ano, @SueldoVariableAguinaldoD OUTPUT 
      EXEC spIntToDateTime  15,  8,  @Ano, @SueldoVariableAguinaldoA OUTPUT 
      EXEC spIntToDateTime  15,  4,  @Ano, @SueldoVariableAguinaldoA1 OUTPUT 
      SELECT @Ano = @Ano - 1
      EXEC spIntToDateTime  16,  12, @Ano, @SueldoVariableAguinaldoD1 OUTPUT 
    END ELSE
    BEGIN
      EXEC spIntToDateTime  16,  8,  @Ano, @SueldoVariableAguinaldoD OUTPUT 
      EXEC spIntToDateTime  15,  12, @Ano, @SueldoVariableAguinaldoA OUTPUT 
      EXEC spIntToDateTime  16,  4,  @Ano, @SueldoVariableAguinaldoD1 OUTPUT 
      EXEC spIntToDateTime  15,  8,  @Ano, @SueldoVariableAguinaldoA1 OUTPUT 
    END
    IF DATEPART(dd, @FechaD) <> 1  AND @NomTipo <> 'Liquidacion' SELECT @Ok=1, @Okref='<BR>LAS FECHAS DEBEN SER DEL 01 AL 15( '+ convert(varchar,@Fechad,103)+')<BR> o la fecha de alta no coincide '+ @Personal 
    -- aqui se calcula el pago ANTERIOR
    SELECT @CantidadLicencias=0, @ImporteLicencias=0,@SueldoVariableAguinaldoLicenciaA = case when @Ultimopago < @SueldoVariableAguinaldoA1  then @Ultimopago else @SueldoVariableAguinaldoA END
    EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableAguinaldoD1, @SueldoVariableAguinaldoA1, @SueldoVariableAcumulado OUTPUT
    EXEC spIncidenciaClaveInternaAcumuladoFechas @Empresa, @Personal, 'LicenciaMaternidad', @SueldoVariableAguinaldoD1, @SueldoVariableAguinaldoLicenciaA, NULL ,NULL, @CantidadLicencias OUTPUT
    SELECT @ImporteLicencias = isnull((@CantidadLicencias * @SueldoMensual/30.0),0)
    SELECT @CantidadLicencias=0
    EXEC spIncidenciaClaveInternaAcumuladoFechas @Empresa, @Personal, 'LicenciaRiesgoProfesional', @SueldoVariableAguinaldoD1, @SueldoVariableAguinaldoA1, NULL ,NULL , @CantidadLicencias OUTPUT
-- EXEC ComprobacionXIII 'AIT',       'E00256', 1374

    SELECT @ImporteLicencias = @ImporteLicencias + isnull((@CantidadLicencias * @SueldoMensualPersonal/30.0),0)
    SELECT @SueldoVariableAcumulado =@SueldoVariableAcumulado +  @ImporteLicencias

    SELECT @SueldoVariablePromedio = @SueldoVariableAcumulado / NULLIF(@SueldoVariableDias, 0)
    SELECT @Aguinaldo = ( ISNULL(@SueldoVariablePromedio, 0.0)) * @DiasAguinaldo
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Aguinaldo', @SueldoVariableAguinaldoD1, @SueldoVariableAguinaldoA1, NULL ,@AguinaldoA OUTPUT, NULL
    IF @AguinaldoA > 0 
    BEGIN
      SELECT @Aguinaldo  = ROUND( @Aguinaldo - @AguinaldoA,2) -- la diferencia es lo que se tiene que sumar despues al aguinaldo actuald
      SELECT @AguinaldoA = dbo.fnMayor(@Aguinaldo ,0)
    END

-- aqui se calcula el pago actual 
    SELECT @CantidadLicencias=0, @ImporteLicencias=0,@SueldoVariableAguinaldoLicenciaA = case when @Ultimopago < @SueldoVariableAguinaldoA  then @Ultimopago else @SueldoVariableAguinaldoA END
    EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoA, @SueldoVariableAcumulado OUTPUT
    EXEC spIncidenciaClaveInternaAcumuladoFechas @Empresa, @Personal, 'LicenciaMaternidad', @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoLicenciaA, NULL ,NULL, @CantidadLicencias OUTPUT
    SELECT @ImporteLicencias = isnull((@CantidadLicencias * @SueldoMensual/30.0),0)

    SELECT @CantidadLicencias=0
    EXEC spIncidenciaClaveInternaAcumuladoFechas @Empresa, @Personal, 'LicenciaRiesgoProfesional', @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoLicenciaA, NULL ,NULL , @CantidadLicencias OUTPUT
    SELECT @ImporteLicencias = @ImporteLicencias + isnull((@CantidadLicencias * @SueldoMensual/30.0),0)

    SELECT @SueldoVariableAcumulado =@SueldoVariableAcumulado +  @ImporteLicencias

    IF @NomTipo = 'Liquidacion'
    BEGIN 
      DELETE #Nomina
        FROM #Nomina n
        JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto
       WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)
         AND n.Personal = @Personal

      EXEC spNominaGravaEstandarpanama @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, @FechaA, @Moneda, @TipoCambio, 
                       @SMZ, @SMZTopeHorasDobles, @SDI, @DiasPeriodo, @DiasMes, @DiasAno, @Antiguedad, @IndemnizacionTope,@SueldoMensual,
                       @ISRBase OUTPUT, @IMSSBase OUTPUT, @ImpuestoEstatalBase OUTPUT, @CedularBase OUTPUT,
                       @Ok OUTPUT, @OkRef OUTPUT
      EXEC spNominaGravaPanama @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, 
                             @FechaA, @Moneda, @TipoCambio, 
                             @BasePrimaAntiguedad  OUTPUT,
                             @BaseIndemnizacion    OUTPUT,
                             @BasePreelaborada     OUTPUT,
                             @BaseSeguroEducativo  OUTPUT,
                             @BaseVacaciones       OUTPUT,
      	                     @Ok				           OUTPUT,
      	                     @OkRef				         OUTPUT, @BaseXIII OUTPUT

      IF @NomTipo = 'LIQUIDACION'
      BEGIN  
        EXEC   spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Vacaciones', @FechaAntiguedad, @FechaA, NULL, NULL, @AcumuladoDiasVacaciones OUTPUT              
        SELECT @AdeudoTotalVacaciones = ((DATEDIFF(dd,@FechaAntiguedad, @FechaA)+1) / 11.0) - @AcumuladoDiasVacaciones
        EXEC spNominaPanamaSueldoDiarioVariableVacaciones  @Empresa, @Personal, @FechaAlta, @SueldoMensual, @ImporteComisiones, @ImportePrimProd, @FechaA, @SueldoDiarioVariable OUTPUT
        SELECT @AntiguedadMes = DATEDIFF(month, @FechaAntiguedad, @FechaA)
        IF @Antiguedadmes < 11 
          SELECT @ImporteAdeudoTotalVacaciones = @SueldoDiarioVariable + (@BaseVacaciones/11.0)
        ELSE
          SELECT @ImporteAdeudoTotalVacaciones = @SueldoDiarioVariable * @AdeudoTotalVacaciones +  (@BaseVacaciones/11.0)
        EXEC   spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Vacaciones', @Empresa, @Personal, @AdeudoTotalVacaciones, @ImporteAdeudoTotalVacaciones
      END
      SELECT @SueldoVariableAcumulado = @SueldoVariableAcumulado  + ISNULL(@BaseXIII, 0)
    END

    IF @UltimoPago < @SueldoVariableAguinaldoA and @NomTipo <> 'Liquidacion' -- adelanto el mes XIII se tene que sumar el sueldo por lo dias que faltan
    BEGIN
       if @SueldoVariableAguinaldoD > @UltimoPago
         SELECT @DiasFaltantes           = DATEDIFF(dd,  @SueldoVariableAguinaldoD,@SueldoVariableAguinaldoA) + 1
       ELSE 
         SELECT @DiasFaltantes           = DATEDIFF(dd,  @UltimoPago,@SueldoVariableAguinaldoA) + 1
       SELECT @Periodos                = FLOOR(@DiasFaltantes / @DiasPeriodoEstandar) -- para sacar redondear a multiplos del periodo
       SELECT @SueldoVariableAcumulado = @SueldoVariableAcumulado +  (@Periodos *((@SueldoMensual+@ImporteComisiones+@ImporteViaticos+ @ImportePrimProd)/2.0) )
    END
    SELECT @SueldoVariablePromedio = (@SueldoVariableAcumulado + ISNULL(@ImporteAdeudoTotalVacaciones, 0))/ NULLIF(@SueldoVariableDias, 0)
-- select @CantidadLicencias,@ImporteLicencias,@SueldoVariableAcumulado

    SELECT @Aguinaldo = (( ISNULL(@SueldoVariablePromedio, 0.0)) * @DiasAguinaldo) + @AguinaldoA -- ojo lo puse de nuevo para  ver el pasado + @AguinaldoA


    IF @AguinaldoNavidad = 1 AND MONTH(@SueldoVariableAguinaldoA) = 12 -- solo se paga en diciembre
    BEGIN 
      SELECT @importe = 0
      EXEC spNominaPanamaAguinaldoNavidad @Empresa, @Personal, @Ejercicio, @Aguinaldo, @SueldoMensual, @Importe OUTPUT           
      IF ISNULL(@Importe, 0) > ISNULL(@Aguinaldo, 0)
      BEGIN
        SELECT @Importe = @Importe - @Aguinaldo
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'AguinaldoNavidad', @Empresa, @Personal, /*@SueldoVariableAcumulado*/ @DiasAguinaldo, @Importe
      END
    END

    -- se resta lo ya pagado en ese periodo
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Aguinaldo', @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoA, NULL, @AguinaldoAcumulado OUTPUT, NULL
    SELECT @Aguinaldo = @Aguinaldo - @AguinaldoAcumulado
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Aguinaldo', @Empresa, @Personal, @SueldoVariableAcumulado , @Aguinaldo
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'GastosRepresentacion', @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoA, NULL, @GastosAcumulado OUTPUT, NULL
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'GastosRepresentacionXIII', @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoA, NULL, @GastosAcumuladoXIII OUTPUT, NULL
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'GastosRepresentacionVacaciones', @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoA, NULL, @AcumuladoVacacionesGR OUTPUT, NULL
    SELECT @GastosAcumulado = isnull(@GastosAcumulado,0) + isnull(@AcumuladoVacacionesGR,0) + isnull(@GastosAcumuladoXIII,0)


    IF @NomTipo = 'Liquidacion' SELECT @GastosAcumulado = @GastosAcumulado + @Gastos
    IF @UltimoPago < @SueldoVariableAguinaldoA and @NomTipo <> 'Liquidacion'  -- adelanto el mes XIII se tene que sumar Los Gastos por lo dias que faltan
    BEGIN
      SELECT @DiasFaltantes   = DATEDIFF(dd, @UltimoPago, @SueldoVariableAguinaldoA) + 1
      SELECT @Periodos        = FLOOR(@DiasFaltantes / @DiasPeriodoEstandar) -- para sacar redondear a multiplos del periodo
      SELECT @GastosAcumulado = @GastosAcumulado +(@Periodos * @SDI/2)-- en sdi tenemos los gr por periodo
    END
    select @CantidadLicencias = 0
    EXEC spIncidenciaClaveInternaAcumuladoFechas @Empresa, @Personal, 'LicenciaMaternidad', @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoLicenciaA, NULL ,NULL, @CantidadLicencias OUTPUT
    SELECT @ImporteLicencias = isnull((@CantidadLicencias * @SDI/30.0),0)
    SELECT @CantidadLicencias=0
    EXEC spIncidenciaClaveInternaAcumuladoFechas @Empresa, @Personal, 'LicenciaRiesgoProfesional', @SueldoVariableAguinaldoD, @SueldoVariableAguinaldoLicenciaA, NULL ,NULL , @CantidadLicencias OUTPUT
    SELECT @ImporteLicencias = @ImporteLicencias + isnull((@CantidadLicencias * @SDI/30.0),0)

    SELECT @GastosAcumulado = @GastosAcumulado +  @ImporteLicencias

    SELECT @SDI = @GastosAcumulado / NULLIF(@SueldoVariableDias, 0) * @DiasAguinaldo

    IF @Nomtipo = 'Liquidacion' 
    BEGIN
      IF @GastosLiquidacion ='S' 
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, @DiasAguinaldo, @SDI
    END ELSE  
    BEGIN
      if @Nomtipo = 'AGUINALDO'
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacionXIII', @Empresa, @Personal, @DiasAguinaldo, @SDI
      ELSE
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'GastosRepresentacion', @Empresa, @Personal, @DiasAguinaldo, @SDI
--- ojo ojo
--select @Sdi
    END
  END ELSE
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') AND @FechaA >= @PrimerDiaAno
  BEGIN
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Aguinaldo', @PrimerDiaAno, @FechaA, NULL, @AguinaldoAcumulado OUTPUT, NULL
    SELECT @Aguinaldo =  -1 * @AguinaldoAcumulado
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Aguinaldo', @Empresa, @Personal, @DiasAguinaldoProporcion, @Aguinaldo
  END

-- se duplica por que se necesita para el calculo de la prima de antiguedad
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') 
  BEGIN
    SELECT  @ISRBase = 0, @IMSSBase = 0, @ImpuestoEstatalBase = 0, @CedularBase = 0, @BasePrimaAntiguedad  = 0,
            @BaseIndemnizacion = 0, @BasePreelaborada = 0, @BaseSeguroEducativo = 0, @BaseVacaciones = 0
-- PARA BORRAR TODOS LOS QUE NO SE USAN
    DELETE #Nomina
      FROM #Nomina n
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)
       AND n.Personal = @Personal

    EXEC spNominaGravaEstandarpanama @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, @FechaA, @Moneda, @TipoCambio, 
                       @SMZ, @SMZTopeHorasDobles, @SDI, @DiasPeriodo, @DiasMes, @DiasAno, @Antiguedad, @IndemnizacionTope,@SueldoMensual,
                       @ISRBase OUTPUT, @IMSSBase OUTPUT, @ImpuestoEstatalBase OUTPUT, @CedularBase OUTPUT,
                       @Ok OUTPUT, @OkRef OUTPUT

    EXEC spNominaGravaPanama @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, 
                             @FechaA, @Moneda, @TipoCambio, 
                             @BasePrimaAntiguedad  OUTPUT,
                             @BaseIndemnizacion    OUTPUT,
                             @BasePreelaborada     OUTPUT,
                             @BaseSeguroEducativo  OUTPUT,
                             @BaseVacaciones       OUTPUT,
			                 @Ok				   OUTPUT,
			                 @OkRef				   OUTPUT, 
                             @BaseXIII OUTPUT

  END
-- nopminaconcepto
  IF @NomTipo = 'LIQUIDACION'
  BEGIN  
    SELECT @Indemnizacion1 = 0
    SELECT @SueldomesIndem  =  SUM(ISNULL(CASE WHEN NominaD.Movimiento = 'DEDUCCION'  THEN NominaD.Importe  * -1 ELSE NominaD.Importe END,0)) / 6.0
      FROM Nomina
      JOIN NominaD ON Nomina.ID=NominaD.ID AND NominaD.Personal=@Personal
      JOIN Movtipo ON MovTipo.Modulo='NOM' AND MovTipo.Mov=Nomina.Mov AND MovTipo.Clave IN('NOM.N','NOM.NE', 'NOM.NA')  
      JOIN NominaConcepto ON NominaConcepto.NominaConcepto = Nominad.NominaConcepto AND NominaConcepto.GravaIndemnizacion = 'SI'
     WHERE Nomina.Estatus='Concluido'  
       AND Nomina.fechaA BETWEEN DATEADD(MONTH,-6,@FechaA) AND @FechaA

-- ojo solo se saca el SULDO BASE de un mes

    SELECT @Indemnizacion =  SUM(ISNULL(CASE WHEN  NominaD.Movimiento = 'DEDUCCION'  THEN NominaD.Importe  * -1 ELSE NominaD.Importe END ,0)) 
       FROM Nomina
       JOIN NominaD ON Nomina.ID=NominaD.ID AND NominaD.Personal=@Personal
       JOIN Movtipo ON MovTipo.Modulo='NOM' AND MovTipo.Mov=Nomina.Mov AND MovTipo.Clave IN('NOM.N','NOM.NE', 'NOM.NA')  
      JOIN NominaConcepto ON NominaConcepto.NominaConcepto = Nominad.NominaConcepto AND NominaConcepto.GravaIndemnizacion = 'SI'
      WHERE Nomina.Estatus='Concluido'  
        AND Nomina.fechaA BETWEEN DATEADD(MONTH,-1,@FechaA) AND @FechaA

    SELECT @SueldoMesIndem= dbo.fnMayor(round(@SueldomesIndem,2),ROUND(@Indemnizacion,2))


    SELECT @SueldoSemanaPRIMA  =  SUM(ISNULL(CASE WHEN  NominaD.Movimiento = 'DEDUCCION'  THEN NominaD.Importe  * -1 ELSE NominaD.Importe END ,0)) 
      FROM Nomina
      JOIN NominaD ON Nomina.ID=NominaD.ID AND NominaD.Personal=@Personal
      JOIN Movtipo ON MovTipo.Modulo='NOM' AND MovTipo.Mov=Nomina.Mov AND MovTipo.Clave IN('NOM.N','NOM.NE', 'NOM.NA')  
      JOIN NominaConcepto ON NominaConcepto.NominaConcepto = Nominad.NominaConcepto AND NominaConcepto.GravaPrimaAntiguedad='SI'
     WHERE Nomina.Estatus='Concluido'  
       AND Nomina.fechaA BETWEEN DATEADD(YEAR,-5,@FechaA) AND @FechaA

    SELECT @SueldoSemanaPRIMA  = ROUND((isNULL(round(@SueldoSemanaPRIMA,2),0)  + isNULL(round(@BasePrimaAntiguedad,2),0) ) / 260.0,2)
    SELECT @FechaAntiguedad1   = @FechaAntiguedad-- para guardarlos
    IF @AntiguedadFlotante < 5.0
    BEGIN
      SELECT @PrimaAntiguedad =  SUM(ISNULL(CASE WHEN  NominaD.Movimiento = 'DEDUCCION'  THEN NominaD.Importe  * -1 ELSE NominaD.Importe END ,0)) 
        FROM Nomina
        JOIN NominaD ON Nomina.ID=NominaD.ID AND NominaD.Personal=@Personal
        JOIN Movtipo ON MovTipo.Modulo='NOM' AND MovTipo.Mov=Nomina.Mov AND MovTipo.Clave IN('NOM.N','NOM.NE', 'NOM.NA')  
        JOIN NominaConcepto ON NominaConcepto.NominaConcepto = Nominad.NominaConcepto AND NominaConcepto.GravaPrimaAntiguedad='SI'
       WHERE Nomina.Estatus='Concluido'  
         AND Nomina.fechaA BETWEEN @FechaAntiguedad AND @FechaA
      
       SELECT @PrimaAntiguedad = ROUND((round(@PrimaAntiguedad,2) + isNULL(@BasePrimaAntiguedad,0))* 1.92 /100.0,2)
    END
    ELSE
    BEGIN          
      SELECT @AntiguedadFlotantePrima = ROUND((datediff(dd, @FechaAntiguedad, @FechaA) + 1) / 7.0 * 1.92 / 100.0, 2)
      SELECT @PrimaAntiguedad = @AntiguedadFlotantePrima *  @SueldoSemanaPRIMA
    END
    BEGIN 
     -- caso para los de 6 meses o menos indemnizacion
      IF DATEDIFF(MONTH,@FechaAntiguedad, @FechaA) <= 6
      BEGIN
        SELECT @Indemnizacion =  SUM(ISNULL(CASE WHEN  NominaD.Movimiento = 'DEDUCCION'  THEN NominaD.Importe  * -1 ELSE NominaD.Importe END ,0)) 
          FROM Nomina
          JOIN NominaD ON Nomina.ID=NominaD.ID AND NominaD.Personal=@Personal
          JOIN Movtipo ON MovTipo.Modulo='NOM' AND MovTipo.Mov=Nomina.Mov AND MovTipo.Clave IN('NOM.N','NOM.NE', 'NOM.NA')  
          JOIN NominaConcepto ON NominaConcepto.NominaConcepto = Nominad.NominaConcepto AND NominaConcepto.GravaIndemnizacion='SI'
         WHERE Nomina.Estatus = 'Concluido'  
           AND Nomina.fechaA BETWEEN @FechaAntiguedad AND @FechaA

         SELECT @Indemnizacion = @Indemnizacion * 6.54 /100.0
      END
      ELSE BEGIN -- mas de 6 meses
        IF @FechaAntiguedad <= CONVERT(datetime,  '2/4/1972', 103) -- para los que son de antes del 2/4/1972
        BEGIN
           SELECT @Antiguedad1    = (DATEDIFF(DAY, @FechaAntiguedad, CONVERT(datetime,  '2/4/1972', 103))+1)/@DiasAno
           SELECT @AntiguedadMes1 = DATEDIFF(Month, @FechaAntiguedad, CONVERT(datetime,  '2/4/1972', 103))
           IF @Antiguedad1 < = 1
              SELECT @Indemnizacion1     = FlOOR(@AntiguedadMes1 / 3.0) * ROUND(@SueldoMesIndem  / 4.333,2) -- se paga un semana por cada 3 meses   
           IF @Antiguedad1 >  1 and  @Antiguedad1 < =  2
             SELECT @Indemnizacion1      = FlOOR(@AntiguedadMes1 / 2.0) * ROUND(@SueldoMesIndem  / 4.333,2) -- se paga un semana por cada 2 meses    
           IF @Antiguedad1 >  2 and  @Antiguedad1 < =  5
               SELECT @Indemnizacion1 =  3 * @SueldoMesINDEM
           IF @Antiguedad1 >  5 and  @Antiguedad1 < =  10
               SELECT @Indemnizacion1 =  4 * @SueldoMesINDEM 
           IF @Antiguedad1 >  10 and  @Antiguedad1 < =  15
               SELECT @Indemnizacion1 =  5 * @SueldoMesINDEM 
           IF @Antiguedad1 >  15 and  @Antiguedad1 < =  20
               SELECT @Indemnizacion1 =  6 * @SueldoMesINDEM 
           IF @Antiguedad1 >  20 and  @Antiguedad1 < =  100
               SELECT @Indemnizacion1 =  7 * @SueldoMesINDEM
           SELECT @FechaAntiguedad1   = @FechaAntiguedad-- para guardarlos
           SELECT @FechaAntiguedad    = CONVERT(datetime,  '2/4/1972', 103)
           SELECT @AntiguedadFlotante = ROUND(dbo.fnAntiguedadFloat(@FechaAntiguedad, @FechaA),2)
        END
        IF @FechaAntiguedad >=    CONVERT(datetime,  '14/08/1995', 103)
        BEGIN
          IF @AntiguedadFlotante <=10.0
          BEGIN 
            SELECT @semanasIndem  = ROUND(@AntiguedadFlotante * 3.4,2)
            SELECT @Indemnizacion = @semanasIndem * ROUND(@SueldoMesIndem / 4.333,2)  
          END       
          ELSE BEGIN
            SELECT @semanasIndem= ROUND(((10.0*3.4) + (@AntiguedadFlotante-10.0)),2)
            SELECT @Indemnizacion =  ROUND(@SemanasIndem * ROUND((@SueldoMesIndem / 4.333 ),2),2)
          END
        END ELSE-- cuando es menor a 14/08/1995 
        BEGIN     
          SELECT @SemanasIndem = 4 + 6 + 24 +(FLOOR(isNULL(@AntiguedadFlotante,0)) - 10)
          SELECT @Indemnizacion= ROUND(@SemanasIndem * ROUND(@SueldoMesIndem / 4.333,2),2)
        END
      END
      SELECT @Indemnizacion = @Indemnizacion*@IndemnizacionPct/100.0
      SELECT @FechaAntiguedad   = @FechaAntiguedad1 -- para regresarlos
      SELECT @AntiguedadFlotante = ROUND(dbo.fnAntiguedadFloat(@FechaAntiguedad, @FechaA),2)
      SELECT @Indemnizacion= @Indemnizacion + @Indemnizacion1
      IF @UsaIndemnizacion=1
         EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Indemnizacion', @Empresa, @Personal, @semanasIndem, @Indemnizacion
      IF @UsaPrima = 1 and @NomTipo IN ('FINIQUITO', 'LIQUIDACION') 
      BEGIN
         EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaAntiguedad', @Empresa, @Personal, @AntiguedadFlotantePrima, @PrimaAntiguedad
         IF @SinAviso = 1
         BEGIN 
           SELECT @Importe = ROUND(@SueldoMensualPersonal / 4.33,2)  
           SELECT @Importe = dbo.fnMenor(@Importe, @PrimaAntiguedad) -- para toparlo a cuando mas la prima
           EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SinAviso', @Empresa, @Personal, 1, @Importe -- es una semana
         END
        IF @PAdicionalIndemni = 1
        BEGIN  
          IF @FechaAntiguedad <= CONVERT(datetime,  '14/8/1995', 103) SELECT @PorcentajePAdicionalIndemni= 50 
          IF @FechaAntiguedad >  CONVERT(datetime,  '14/8/1995', 103) SELECT @PorcentajePAdicionalIndemni= 25 
          SELECT @PrimaAntiguedadAdicional = @Indemnizacion * @PorcentajePAdicionalIndemni / 100
          IF @PorcentajePAdicionalIndemni =50
            EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PAdicionalIndemni', @Empresa, @Personal, @IngresoCincoAnosPrima ,@PrimaAntiguedadAdicional
          ELSE
            EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PAdicionalIndemni2', @Empresa, @Personal,@IngresoCincoAnosPrima , @PrimaAntiguedadAdicional 
        END
      END
    END
  END

  -- Parte Gravable
  SELECT  @ISRBase =0, @IMSSBase =0, @ImpuestoEstatalBase =0, @CedularBase =0,                          @BasePrimaAntiguedad  =0,
                           @BaseIndemnizacion    =0,
                           @BasePreelaborada     =0,
                           @BaseSeguroEducativo  =0,
                           @BaseVacaciones       =0

-- PARA BORRAR TODOS LOS QUE NO SE USAN
    DELETE #Nomina
      FROM #Nomina n
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)
       AND n.Personal = @Personal

  EXEC spNominaGravaEstandarpanama @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, @FechaA, @Moneda, @TipoCambio, 
                     @SMZ, @SMZTopeHorasDobles, @SDI, @DiasPeriodo, @DiasMes, @DiasAno, @Antiguedad, @IndemnizacionTope,@SueldoMensual,
                     @ISRBase OUTPUT, @IMSSBase OUTPUT, @ImpuestoEstatalBase OUTPUT, @CedularBase OUTPUT,
                     @Ok OUTPUT, @OkRef OUTPUT

  EXEC spNominaGravaPanama @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, 
                           @FechaA, @Moneda, @TipoCambio, 
                           @BasePrimaAntiguedad  OUTPUT,
                           @BaseIndemnizacion    OUTPUT,
                           @BasePreelaborada     OUTPUT,
                           @BaseSeguroEducativo  OUTPUT,
                           @BaseVacaciones       OUTPUT,
    	                   @Ok				           OUTPUT,
			               @OkRef				         OUTPUT, @BaseXIII OUTPUT

  -- Totaliza Percepciones antes de Impuestos
  SELECT @PercepcionBruta = 0.0
  SELECT @PercepcionBruta = @PercepcionBruta + ISNULL(SUM(d.Importe), 0.0) 
    FROM #Nomina d 
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion' 
   WHERE d.Personal = @Personal AND d.Movimiento = 'Percepcion' 
  
  --IF (SELECT ISNULL(SUM(Cantidad), 0) FROM #Nomina WHERE NominaConcepto= '324' AND Personal = @Personal) < @Diasperiodo
  
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/Base', 		@Empresa, @Personal, @Importe = @IMSSBase
  --IF (SELECT ISNULL(SUM(Cantidad), 0) FROM #Nomina WHERE NominaConcepto= '324' AND Personal = @Personal ) < @Diasperiodo
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR GR/Base', 	        @Empresa, @Personal, @Importe = @CedularBase


  IF @NomTipo IN ('NORMAL', 'AJUSTE', 'FINIQUITO', 'LIQUIDACION', 'AGUINALDO', 'VACACIONES') 
  BEGIN
    -- IMSS
    SELECT @SSEmpleado    	=    @IMSSBase * (@SSEmpleadoPct        / 100.0),
           @SSPatron      	=    @IMSSBase * (@SSPatronPct          / 100.0),
           @SEEmpleado    	=   (@BaseSeguroEducativo - ( SELECT ISNULL(SUM(Importe),0) FROM #Nomina WHERE Personal = @Personal and nominaconcepto='190'  and id=@id))* (  @SEEmpleadoPct        / 100.0),
           @SEPatron      	=   (@BaseSeguroEducativo - ( SELECT ISNULL(SUM(Importe),0) FROM #Nomina WHERE Personal = @Personal and nominaconcepto='190'  and id=@id )) * (@SEPatronPct          / 100.0),
           @RiesgoProfesional	=  @IMSSBase  * ( @RiesgoProfesionalPct / 100.0)

    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SS/Empleado',       @Empresa, @Personal, /*@DiasTrabajados*/@BaseSeguroEducativo, @SSEmpleado,@Cuenta = @AcreedorIMSS,  @Vencimiento = @IMSSVencimiento
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SS/Patron',         @Empresa, @Personal, @Importe = @SSPatron, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimiento
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'RiesgoProfesional', @Empresa, @Personal, @Importe = @RiesgoProfesional, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimiento
    IF @NomTipo NOT IN ('AGUINALDO')
    BEGIN
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SE/Empleado',       @Empresa, @Personal, @DiasTrabajados, @SEEmpleado,@Cuenta = @AcreedorIMSS,  @Vencimiento = @IMSSVencimiento
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SE/Patron',         @Empresa, @Personal, @Importe = @SEPatron, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimiento
    END ELSE
    BEGIN  --  en el MES XII NO SE DESCUENTA SE
      SELECT @SEEmpleado = 0,
               @SEPatron = 0
    END
    -- Provisiones
    IF @NomTipo IN ('NORMAL', 'AJUSTE') 
    BEGIN
      SELECT @CalcImporte = @PrimaVacacional / @DiasAno * @DiasNaturales
      --EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Vacaciones', @Empresa, @Personal, @Importe = @CalcImporte
      SELECT @CalcImporte = (@DiasAguinaldo*@SueldoDiario/@DiasAno)*@DiasNaturales
--      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Aguinaldo',  @Empresa, @Personal, @Importe = @CalcImporte
      IF (@SMZ*@SMZPrimaAntiguedad) < @SueldoDiario
      SELECT @CalcImporte = (@DiasPrimaAntiguedad*@SMZ*@SMZPrimaAntiguedad*@Antiguedad)/@DiasAno*@DiasNaturales
      ELSE
         SELECT @CalcImporte =(@DiasPrimaAntiguedad*@SueldoDiario*@Antiguedad)/@DiasAno*@DiasNaturales
--      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Antiguedad', @Empresa, @Personal, @Importe = @CalcImporte
    END
  END
  SELECT @DiasPeriodo=isNULL(@DiasPeriodo,0)

  -- Baje esta parte por que necesito el SE para el calculo de ISR

  -- ISR  
  EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Sueldo',   @PrimerDiaAno, @FechaA, NULL, NULL, @DiasAcumulados OUTPUT
  EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Aguinaldo',   @PrimerDiaAno, @FechaA, NULL,@AcumuladoAguinaldo OUTPUT, @AcumuladoDiasMesXII OUTPUT
  EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'VacacionesTomadas',   @PrimerDiaAno, @FechaA, NULL, NULL, @AcumuladoDiasVacaciones  OUTPUT
  EXEC spNominaClaveInternaEstaNomina @Personal, 'Vacaciones', @VacacionesTomadas OUTPUT


  SELECT @DiasAcumulados = @DiasAcumulados + @AcumuladoDiasMesXII + @AcumuladoDiasVacaciones-@VacacionesTomadas
  EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Vacaciones',   @PrimerDiaAno, @FechaA, NULL, NULL, @VacacionesTomadas  OUTPUT
  SELECT @DiasAcumulados = @DiasAcumulados - @VacacionesTomadas


  EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base', @PrimerDiaAno, @FechaA, NULL, @ISRBaseAcumulado OUTPUT, NULL, @Estatus='Borrador'
  EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/ISR',      @PrimerDiaAno, @FechaA, NULL, @ISRAcumulado OUTPUT, NULL,@Estatus='Borrador'
  EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'SE/Empleado',   @PrimerDiaAno, @FechaA, NULL, @AcumuladoSE OUTPUT, @DiasAcumuladosSE OUTPUT,@Estatus='Borrador'

  IF @Sueldomensual / 2.0 > @IsrBase SELECT @TipoCalculoISR = 'Mensual'

  IF @TipoCalculoISR = 'Anual/Mensual'
    IF @FechaAlta > = @PrimerDiaAnoReal + 9 
      SELECT @TipoCalculoISR = 'Mensual'
    ELSE
      SELECT @TipoCalculoISR = 'Anual'
  IF @SueldoMensual <= 859.0
      SELECT @TipoCalculoISR = 'Mensual'

  IF @NomTipo = 'AGUINALDO'
      SELECT @TipoCalculoISR = 'Anual'

  IF @NomTipo in('Finiquito','Liquidacion')
  BEGIN
    IF @UsaIndemnizacion = 0 SELECT @Indemnizacion = 0
    IF @UsaPrima = 0 SELECT @PrimaAntiguedad = 0, @PrimaAntiguedadAdicional = 0
    IF @PAdicionalIndemni = 0 SELECT @PrimaAntiguedadAdicional = 0

    EXEC spISRLiquidacionPanama @Empresa, @Personal, @ISRTabla, @Antiguedad, @Indemnizacion, @PrimaAntiguedad, @PrimaAntiguedadAdicional, @ISRLiquidacion OUTPUT

    SELECT @TipoCalculoISR = 'Anual'


    --EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base',      @PrimerDiaAno, @FechaA, NULL, @ISRBaseAcumulado OUTPUT, NULL
  SELECT @ISRBaseAcumulado=SUM(ISNULL(CASE WHEN D.MOVIMIENTO='DEDUCCION'THEN D.IMPORTE*-1 ELSE D.IMPORTE END,0))
    FROM Nomina n, NominaD d, MovTipo mt
   WHERE n.ID = d.ID
     AND n.Estatus in('CONCLUIDO')
     AND n.Empresa = @EMPRESA
     AND n.FechaA BETWEEN @PrimerDiaAno and @FechaA AND mt.Clave IN ('NOM.N', 'NOM.NE') 
     AND n.Mov = mt.Mov
     AND mt.Modulo = 'NOM'
     AND d.Personal = @PERSONAL
     AND d.NominaConcepto IN(SELECT NominaConcepto FROM NominaConcepto WHERE GravaISR='SI' )


    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'SE/Empleado',   @PrimerDiaAno, @FechaA, NULL, @AcumuladoSE OUTPUT, @DiasAcumuladosSE OUTPUT
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/ISR',       @PrimerDiaAno, @FechaA, NULL, @ISRAcumulado OUTPUT, NULL

    SELECT @AcumuladoSE      = @AcumuladoSE + @SEEmpleado
    SELECT @ISRBaseAcumulado = @ISRBaseAcumulado - (
                                      @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                   + (@MontoNoGravableDependientes * @CantidadDependientes)
                                   +  @AcumuladoSE )
    SELECT @ISRBaseAcumulado = @ISRBaseAcumulado + @ISRBase
    EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseAcumulado, @ISRProyectado OUTPUT
    SELECT @ISR = @ISRProyectado - @ISRAcumulado  
    IF @ISR < 0 SELECT @ISR = 0
  END ELSE 
  BEGIN
    IF @TipoCalculoISR = 'Anual' 
    BEGIN -- caso para cuando tienen todo el a�o ISR BASE ANUAL
      SELECT @SEEmpleadoAnualizado = (@SueldoMensual  + @ImporteComisiones  ) * 12.0 * @SEEmpleadoPct / 100.0
      SELECT @ISRBaseAcumulado =     (@SueldoMensual  + @ImporteComisiones + @ImportePrimProd ) * 13.0    
      SELECT @ISRBaseAcumulado = @ISRBaseAcumulado - (
                                        @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                     + (@MontoNoGravableDependientes * @CantidadDependientes)
                                     +  @SEEmpleadoAnualizado )
      EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseAcumulado, @ISRProyectado OUTPUT
      IF @NomTipo = 'AGUINALDO'
        SELECT @ISRProyectado = (@ISRProyectado / 13.0) / 3.0
      ELSE
        SELECT @ISRProyectado = (@ISRProyectado / 13.0) / 2.0
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base', @PrimerDiaAno, @FechaA, NULL,      @ISRBaseAcumulado OUTPUT, NULL
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'SE/Empleado',   @PrimerDiaAno, @FechaA, NULL, @AcumuladoSE OUTPUT, @DiasAcumuladosSE OUTPUT
      IF @FechaA > @UltimoPago AND @NomTipo = 'AGUINALDO' 
        EXEC spPeriodosPlanillaFaltantes  @Personal, @PeriodoTipo, @UltimoPago, 0, @Periodos OUTPUT    --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd                                      
      ELSE
        EXEC spPeriodosPlanillaFaltantes  @Personal, @PeriodoTipo, @FechaA, 0, @Periodos OUTPUT    --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd
      IF @NomTipo <> 'AGUINALDO'
        SELECT @Periodos = @Periodos + 1
      SELECT @ISRBaseAcumulado = @ISRBaseAcumulado + (@SueldoMensual + @ImporteComisiones + @ImportePrimProd ) * (@Periodos / 2.0)
      SELECT @AcumuladoSE      = @AcumuladoSE + (( @SueldoMensual + @ImporteComisiones  ) * (@Periodos/2.0) * @SEEmpleadoPct / 100.0)
      EXEC spPeriodosXIIIFaltan @Personal, @PeriodoTipo, @FechaA, 0, @Periodos  OUTPUT --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd      
      SELECT @ISRBaseAcumulado = @ISRBaseAcumulado + ((@SueldoMensual + @ImporteComisiones ) * @Periodos)
      SELECT @ISRBaseAcumulado= @ISRBaseAcumulado - (
                                       @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                    + (@MontoNoGravableDependientes * @CantidadDependientes)
                                    +  @AcumuladoSE )
      EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseAcumulado, @ISR1 OUTPUT
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base', @PrimerDiaAno, @FechaA, NULL, @ISRBaseAcumulado OUTPUT, NULL
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'SE/Empleado',   @PrimerDiaAno, @FechaA, NULL, @AcumuladoSE OUTPUT, @DiasAcumuladosSE OUTPUT
      IF @FechaA > @UltimoPago AND @NomTipo = 'AGUINALDO' 
        EXEC spPeriodosPlanillaFaltantes  @Personal, @PeriodoTipo, @UltimoPago, 0, @Periodos OUTPUT   --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd                                     
      ELSE
        EXEC spPeriodosPlanillaFaltantes  @Personal, @PeriodoTipo, @FechaA, 0, @Periodos OUTPUT    --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd
      SELECT @ISRBaseAcumulado = @ISRBaseAcumulado 
                               + @ISRBase 
                               + ( @SueldoMensual + @ImporteComisiones + @ImportePrimProd ) * ((@Periodos)/2.0)
      SELECT @AcumuladoSE = @AcumuladoSE 
                          + (@BaseSeguroEducativo * @SEEmpleadoPct / 100.0)
                          + ((@SueldoMensual + @ImporteComisiones) * @Periodos/2.0 * @SEEmpleadoPct / 100.0)
      EXEC spPeriodosXIIIFaltan @Personal, @PeriodoTipo, @FechaA, 0,  --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd
                         @Periodos  OUTPUT
      IF @NomTipo = 'AGUINALDO' -- hay que quitar el actual
        SELECT @Periodos = @Periodos - 0.3333
      SELECT @ISRBaseAcumulado = @ISRBaseAcumulado + (@SueldoMensual + @ImporteComisiones) * @Periodos
      SELECT @ISRBaseAcumulado = @ISRBaseAcumulado - (
                                       @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                    + (@MontoNoGravableDependientes * @CantidadDependientes)
                                    +  @AcumuladoSE )
      EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseAcumulado, @ISR2 OUTPUT
      SELECT @ISR = @ISRProyectado + dbo.fnMayor((@ISR2-@ISR1),0) 

    END
    ELSE  BEGIN --ISR BASE MENSUAL
      IF DAY(@FechaA) = 15 OR @NomTipo='AGUINALDO' -- para la primer quincena 
      BEGIN
       IF  @NomTipo='AGUINALDO' 
           SELECT @SEEmpleadoAnualizado = ( @ISRBase * 3 )* 12.0  * @SEEmpleadoPct        / 100.0
       ELSE              
           SELECT @SEEmpleadoAnualizado = ((@SueldoMensual/2) + @BaseSeguroEducativo) * 12.0  * @SEEmpleadoPct        / 100.0


       IF  @NomTipo='AGUINALDO' 
         SELECT @ISRBaseAcumulado = ( @ISRBase * 3 ) * 13.0 
                                   - (
                                        @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                     + (@MontoNoGravableDependientes * @CantidadDependientes)
                                     +  @SEEmpleadoAnualizado
                                     )

       ELSE
         SELECT @ISRBaseAcumulado =  ( (@SueldoMensual/2.0)+@ISRBASE ) * 13.0 
                                   - (
                                        @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                     + (@MontoNoGravableDependientes * @CantidadDependientes)
                                     +  @SEEmpleadoAnualizado
                                     )
 
       EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseAcumulado, @ISRProyectado OUTPUT

       IF  @NomTipo='AGUINALDO' 
         SELECT @ISRBaseAcumulado = ( @ISRBase * 3 ) * 13.0 
       ELSE
         SELECT @ISRBaseAcumulado = ( @ISRBase + ( @SueldoMensual/2.0)) * 13.0 

       IF  @NomTipo='AGUINALDO' 
         IF ((( @ISRBaseAcumulado-@ISRProyectado) <= 10400.0)  AND  (@ISRProyectado  > 0 )) 
           SELECT @ISR = dbo.fnMayor((@ISRProyectado - dbo.fnMayor( 10400.0-(@ISRBaseAcumulado - @ISRProyectado) , 0)) /13.0  / 3.0,0)
         ELSE 
           SELECT @ISR = @ISRProyectado / 13.0  / 3.0
       ELSE
         IF ((( @ISRBaseAcumulado-@ISRProyectado) <= 10400.0)  AND  (@ISRProyectado  > 0 )) 
           SELECT @ISR = dbo.fnMayor((@ISRProyectado - dbo.fnMayor( 10400.0-(@ISRBaseAcumulado - @ISRProyectado) , 0)) /13.0  / 2.0,0)
         ELSE 
           SELECT @ISR = @ISRProyectado / 13.0  / 2.0
      END
      ELSE   BEGIN -- cuando es segunda quincena
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base', @PrimerDiaMes, @FechaA, NULL, @ISRBaseAcumulado OUTPUT, NULL,'XIII Mes', @estatus = 'Borrador'
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/ISR',  @PrimerDiaMes, @FechaA, NULL, @ISRAcumuladoMensual OUTPUT, NULL,'XIII Mes', @estatus = 'Borrador'
        SELECT @ISRBaseMes = @ISRBaseAcumulado + @BASESeguroEducativo
        SELECT @SEEmpleadoAnualizado = @ISRBaseMes * 12 * @SEEmpleadoPct        / 100.0
        SELECT @ISRBaseMes = @ISRBaseAcumulado + @ISRBASE
        SELECT @ISRBaseMes     =    @ISRBaseMes * 13 
                                     - (@SEEmpleadoAnualizado
                                     + @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                     + (@MontoNoGravableDependientes * @CantidadDependientes) )

        EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseMes, @ISRProyectado OUTPUT
        SELECT @ISRBaseMes = @ISRBaseAcumulado + @ISRBASE
        SELECT @ISRBaseAcumulado = @ISRBaseMes * 13 

        IF (@ISRBaseAcumulado - @ISRProyectado) <= 10400.0 
          SELECT @ISR = dbo.fnMayor((@ISRProyectado - dbo.fnMayor( 10400.0 -(@ISRBaseAcumulado - @ISRProyectado) , 0)) /13.0,0)
                        -   @ISRAcumuladoMensual
        ELSE 
          SELECT @ISR = dbo.fnMayor(@ISRProyectado / 13.0  -   @ISRAcumuladoMensual, 0)

        IF (@ISRProyectado / 13.0  - @ISRAcumuladoMensual) < 0
           SELECT @ISRCREDITO = (@ISRProyectado / 13.0  -   @ISRAcumuladoMensual) * -1 
      END
    END
  END

  EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Sueldo', @PrimerDiaAno, @FechaA,NULL,NULL, @Cantidad Output, NULL, NULL
  EXEC spPeriodosPlanillaFaltantes  @Personal, @PeriodoTipo, @UltimoPago, 1, @Periodos OUTPUT 
  IF @AjusteAnual ='S' AND @Fechaantiguedad < @PrimerDiaAno AND (@Cantidad/15.0) + @Periodos  > =24
  BEGIN -- caso para cuando tienen todo el a�o ISR BASE ANUAL
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/ISR', @PrimerDiaAno, @UltimoDiaAno, NULL, @ISRAcumulado OUTPUT, NULL

    SELECT @SEEmpleadoAnualizado = (@SueldoMensual  + @ImporteComisiones  ) * 12.0 * @SEEmpleadoPct / 100.0
    SELECT @ISRBaseAcumulado =     (@SueldoMensual  + @ImporteComisiones + @ImportePrimProd ) * 13.0    
    SELECT @ISRBaseAcumulado = @ISRBaseAcumulado - (
                                      @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                   + (@MontoNoGravableDependientes * @CantidadDependientes)
                                   +  @SEEmpleadoAnualizado )
    EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseAcumulado, @ISRProyectado OUTPUT
   

    EXEC SpNominaGravaConceptoAcumuladoFechas  @Empresa, @Personal, @PrimerDiaAno, @UltimoDiaAno, 'GravaISR', @ISRBaseAcumulado Output, NULL

    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'SE/Empleado',   @PrimerDiaAno, @UltimoDiaAno, NULL, @AcumuladoSE OUTPUT, @DiasAcumuladosSE OUTPUT
    IF @FechaA > @UltimoPago AND @NomTipo = 'AGUINALDO' 
      EXEC spPeriodosPlanillaFaltantes  @Personal, @PeriodoTipo, @UltimoPago, 1, @Periodos OUTPUT   --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd                                     
    ELSE
      EXEC spPeriodosPlanillaFaltantes  @Personal, @PeriodoTipo, @FechaA, 1, @Periodos OUTPUT    --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd
    SELECT @ISRBaseAcumulado = @ISRBaseAcumulado 
                             + 0 --@ISRBase 
                             + ( @SueldoMensual + @ImporteComisiones + @ImportePrimProd ) * ((@Periodos)/2.0)
    SELECT @AcumuladoSE = @AcumuladoSE 
                        + 0--(@BaseSeguroEducativ * @SEEmpleadoPct / 100.0)
                        + ((@SueldoMensual + @ImporteComisiones) * @Periodos/2.0 * @SEEmpleadoPct / 100.0)
    EXEC spPeriodosXIIIFaltan @Personal, @PeriodoTipo, @FechaA, 1,  --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd
                       @Periodos  OUTPUT
    IF @NomTipo = 'AGUINALDO' -- hay que quitar el actual
      SELECT @Periodos = @Periodos - 0.3333
    SELECT @ISRBaseAcumulado = @ISRBaseAcumulado + (@SueldoMensual + @ImporteComisiones) * @Periodos
    SELECT @ISRBaseAcumulado = @ISRBaseAcumulado - (
                                     @MontoNoGravablePersonal + @MontoNoGravableConyugue 
                                  + (@MontoNoGravableDependientes * @CantidadDependientes)
                                  +  @AcumuladoSE )

    EXEC spTablaImpuesto @ISRTabla, NULL, '(Sin Periodo)', @ISRBaseAcumulado, @ISR2 OUTPUT

    EXEC spPeriodosXIIIFaltan @Personal, @PeriodoTipo, @FechaA, 1, @PeriodosFaltantes  OUTPUT                              --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd
    EXEC spPeriodosPlanillaFaltantes  @Personal, @PeriodoTipo, @UltimoPago, 1, @Periodos OUTPUT   --- 0= calculo de fechas primer dia a�o, 2= Leido de la bd                                     
    SELECT @PeriodosFaltantes = @PeriodosFaltantes + (@Periodos/2)

    SELECT @ISRProyectado = @ISRProyectado/13.0*@PeriodosFaltantes

    SELECT @PrimerDiaAno = DateADD(year,-1,@PrimerDiaAno)
    SELECT @UltimoDiaAno = DateADD(year,-1,@UltimoDiaAno)
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/AjusteAnual', @PrimerDiaAno, @UltimoDiaAno, NULL, @ISRAcumuladoAnterior OUTPUT, NULL

    SELECT @PrimerDiaAno = DateADD(year,1,@PrimerDiaAno)
    SELECT @UltimoDiaAno = DateADD(year,1,@UltimoDiaAno)
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/AjusteCreditoAnterior', @PrimerDiaAno, @UltimoDiaAno, NULL, @AcumuladoCreditoAnterior OUTPUT, NULL


    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/ISRAjuste',       @PrimerDiaAno, @UltimoDiaAno, NULL, @ISRAcumuladoAjuste OUTPUT, NULL

    SELECT @ISRAjuste = ((@ISR2 - @ISRProyectado) -  (@ISRAcumulado + @ISRAcumuladoAjuste ))

    IF @ISRAjuste > 0
      SELECT @ISRAjuste= @ISRAjuste / @Periodos

 
        
  END ELSE 
    SELECT @ISRAjuste = 0

  BEGIN
    IF @ISRFijoPeriodo > 0  -- por que en panama algunos empleados deciden cuanto les descuenten de renta
      SELECT @ISR = @ISRFijoPeriodo

    IF (@NomTipo  ='Ajuste' AND @ISRBASE  = 0 ) or( EXISTS (SELECT * FROM Personal WHERE Tipo='Jubilado' AND Personal = @Personal))
        SELECT @ISR = 0
    
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') 
    BEGIN
      SELECT @ISR= @ISR + @ISRLiquidacion  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Base',  		@Empresa, @Personal, @Importe = @ISRBaseAcumulado
    END ELSE   
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Base',  		@Empresa, @Personal, @Importe = @ISRBase

    IF @TipoCalculoISR= 'Mensual'
      EXEC   spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/ISR', @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento, @cantidad=1

    IF @TipoCalculoISR='Anual'
     EXEC   spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/ISR',  @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento, @cantidad=2

    SELECT @CedularBase = @CedularBase * @PctISRGR/100.0 
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR GR', @Empresa, @Personal, @Importe = @CedularBase, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento



    IF @ISR < @ISRAjuste
      SELECT @ISRAjuste = @ISR     

    EXEC   spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Ajuste',  @Empresa, @Personal, @Importe = @ISRAjuste, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento

    IF (@ISR - @ISRAjuste) > 0    
      IF  (@ISRAcumuladoAnterior - @AcumuladoCreditoAnterior) > 0 
      BEGIN
        SELECT @CreditoAnterior = dbo.fnMenor(@ISRAcumuladoAnterior - @AcumuladoCreditoAnterior,@ISR - @ISRAjuste)
        EXEC   spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/AjusteCreditoAnterior',  @Empresa, @Personal, @Importe = @CreditoAnterior, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento
      END
  END

  IF  @NomTipo in('NORMAL','VACACIONES') 
  BEGIN
    -- SINDICATO 
    SELECT @SindicatoImporte = 0
    IF @SindicatoPr > 0 AND @SindicatoFrecuencia='FIN MES' AND @EsFinMes=1
    BEGIN
      IF @SindicatoMetodo= 'TOTAL DEVENGADO'
         SELECT @SindicatoImporte= (@PercepcionBruta-@FaltasImporte) * @SindicatoPr / 100.0
      ELSE
         SELECT @SindicatoImporte= @SueldoMensual * @SindicatoPr / 100.0
    END  ELSE
    IF @Sindicato$ > 0 AND @SindicatoFrecuencia='INICIO MES' AND @EsFinMes=0
      IF @SindicatoMetodo= 'TOTAL DEVENGADO'
         SELECT @SindicatoImporte= (@PercepcionBruta-@FaltasImporte)  * @SindicatoPr / 100.0
      ELSE
         SELECT @SindicatoImporte= @SueldoMensual * @SindicatoPr / 100.0
    ELSE 
      IF @Sindicatopr > 0     
      IF @SindicatoMetodo= 'TOTAL DEVENGADO'
         SELECT @SindicatoImporte= @PercepcionBruta * @SindicatoPr / 100.0
      ELSE
         SELECT @SindicatoImporte= @SueldoMensual * @SindicatoPr / 100.0 / 2.0 
    IF @NomTipo='VACACIONES' 
      SELECT @SindicatoImporte =@SindicatoImporte * ROUND(DATEDIFF(dd, @Incidenciad, @IncidenciaA) / 15.0, 0) --- por que es cada quincena

    IF EXISTS(SELECT * FROM Personal  WHERE Personal = @Personal AND ISNULL(NULLIF(ISNULL(Sindicato,''),'Ninguno'),'(Confianza)') <> '(Confianza)')
    BEGIN
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Sindicato', @Empresa, @Personal, @Importe = @SindicatoImporte, @Cuenta = @SindicatoAcreedorPr,  @Vencimiento = @IMSSVencimiento
      IF @Sindicato$ > 0  
      BEGIN
        SELECT @SindicatoImporte=        @Sindicato$
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Sindicato', @Empresa, @Personal, @Importe = @SindicatoImporte, @Cuenta = @SindicatoAcreedor$,  @Vencimiento = @IMSSVencimiento
      END
    END
  END 

  -- Pension Alimenticia 'PensionA/SueldoBruto','PensionA/SueldoNeto'
  SELECT @CalcImporte = (@PensionASueldoBruto / 100.0) * @PercepcionBruta 
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor
  SELECT @CalcImporte = (@PensionASueldoNeto / 100.0)* (@PercepcionBruta-ISNULL(@ISR, 0.0) - ISNULL(@IMSSObrero, 0.0)) + @PensionA
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto',  @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor

  SELECT @CalcImporte = (@PensionASueldoBruto2 / 100.0) * @PercepcionBruta
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor2
  SELECT @CalcImporte = (@PensionASueldoNeto2 / 100.0)*(@PercepcionBruta - ISNULL(@ISR, 0.0) - ISNULL(@IMSSObrero, 0.0))+ @PensionA2
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto',  @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor2

  SELECT @CalcImporte = (@PensionASueldoBruto3 / 100.0)* @PercepcionBruta
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor3
  SELECT @CalcImporte = (@PensionASueldoNeto3/100.0)*(@PercepcionBruta-ISNULL(@ISR, 0.0) - ISNULL(@IMSSObrero, 0.0))+ + @PensionA3
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto',  @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor3

  SELECT @PersonalPercepciones = 0.0, @PersonalDeducciones = 0.0
  SELECT @PersonalPercepciones = ISNULL(SUM(d.Importe), 0.0)
    FROM #Nomina d 
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'
   WHERE d.Personal = @Personal AND d.Movimiento = 'Percepcion'

  SELECT @PersonalDeducciones = ISNULL(SUM(d.Importe), 0.0)
    FROM #Nomina d 
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Deduccion'
   WHERE d.Personal = @Personal AND d.Movimiento = 'Deduccion'

  SELECT @PersonalNeto = @PersonalPercepciones - @PersonalDeducciones

  -- Cuentas por Cobrar (Cxc/Faltantes Caja/Faltantes Inv/Etc.)
  IF @NomCxc IN ('PARCIALES', 'COMPLETAS') AND @NomTipo <> 'AJUSTE'
  BEGIN
    SELECT @ConSueldoMinimo = 1 
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') AND @FiniquitoNetoEnCeros = 0 SELECT @ConSueldoMinimo = 0
    IF @PersonalNeto > @SueldoMinimo OR @ConSueldoMinimo = 0
      EXEC spNominaCxc @NomCxc, @NomTipo, @Empresa, @Sucursal, @ID, @Personal, @Cliente, @IncidenciaD, @IncidenciaA, @Moneda, @TipoCambio, @ConSueldoMinimo, @SueldoMinimo, @PersonalNeto OUTPUT, @Ok OUTPUT, @OkRef OUTPUT
  END

-- PARA BORRAR TODOS LOS QUE NO SE USAN
  DELETE #Nomina
    FROM #Nomina n
    JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto
   WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)
     AND n.Personal = @Personal

    
  SELECT @Calc = @SueldoVariable / 12.0
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ProvisionMesXIII', @Empresa, @Personal, @Importe = @calc
  SELECT @Calc = @BaseVacaciones / 11.0	
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ProvisionVacaciones', @Empresa, @Personal, @Importe = @calc
  SELECT @Calc = @BasePrimaAntiguedad / 52.0	
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ProvisionPrimaAntiguedad', @Empresa, @Personal, @Importe = @calc
  SELECT @Calc = @BaseIndemnizacion * .0654
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ProvisionIndemnizacion', @Empresa, @Personal,   @Importe = @calc

/*
-- se manda fondo de cesantia que se emite a la entidad adminsitradora del fondo falta clave interna
*/

-- se recalcula por que las cxc
  SELECT @PersonalPercepciones = 0.0, @PersonalDeducciones = 0.0

  SELECT @PersonalPercepciones = ISNULL(SUM(d.Importe), 0.0)
    FROM #Nomina d 
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'
   WHERE d.Personal = @Personal AND d.Movimiento = 'Percepcion'

  SELECT @PersonalDeducciones = ISNULL(SUM(d.Importe), 0.0)
    FROM #Nomina d 
--    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Deduccion'
   WHERE d.Personal = @Personal AND d.Movimiento = 'Deduccion'

  SELECT @PersonalNeto = @PersonalPercepciones - @PersonalDeducciones
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Percepciones', @Empresa, @Personal, @Importe = @PersonalPercepciones
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Deducciones', @Empresa, @Personal, @Importe = @PersonalDeducciones
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Neto', @Empresa, @Personal, @Importe = @PersonalNeto, @Cuenta = @BeneficiarioSueldoNeto, @Beneficiario = @BeneficiarioSueldoNeto 

  IF ISNULL(@PersonalNeto,0) = 0 AND @MovTipo = 'NOM.NE' -- si es especial y su neto es 0 se borra el empleado
     DELETE #Nomina WHERE Personal = @Personal 

IF @NomTipo = 'VACACIONES' AND @FechaIniVacaciones BETWEEN @IncidenciaD AND @IncidenciaA  -- se borra las incidencias de vacaciones si no abarca al menos 8 dias
  BEGIN                                   
    IF (DATEDIFF(dd, @FechaIniVacaciones, @IncidenciaA) + 1) < = 7
      DELETE #Nomina
       FROM #Nomina n
       JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto
      WHERE ISNULL(nc.Especial, '') <> 'Vacaciones' 
        AND n.Personal = @Personal AND ISNULL(INCIDENCIARID,0)<>0
  END

  IF @NomTipo='VACACIONES' AND @FechaFinVacaciones BETWEEN @IncidenciaD AND @IncidenciaA  -- se borra las incidencias de vacaciones si no abarca al menos 8 dias
  BEGIN
    IF (DATEDIFF(dd, @IncidenciaD, @FechaFinVacaciones) + 1) < = 7
      DELETE #Nomina
        FROM #Nomina n
        JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto
       WHERE ISNULL(nc.Especial, '') <> 'Vacaciones' 
         AND n.Personal = @Personal AND ISNULL(INCIDENCIARID,0)<>0
  END 
 

  IF @Ok IS NOT NULL AND @OkRef IS NULL SELECT @OkRef = @Personal
  RETURN
END 
go

