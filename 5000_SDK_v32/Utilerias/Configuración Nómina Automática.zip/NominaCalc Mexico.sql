EXEC xpConfigSQL
SET ANSI_NULLS OFF
GO

GO
/***********************   spNominaCalcMexico    ********************************* esta diferente */
if exists (select * from sysobjects where object_id('dbo.spNominaCalcMexico')=id and type='P') drop procedure dbo.spNominaCalcMexico
GO  

CREATE   PROCEDURE dbo.spNominaCalcMexico  
   @Empresa                        char(5),  
   @FechaTrabajo                   datetime,  
   @Sucursal                       int,  
   @ID                             int,  
   @Moneda                         char(10),  
   @TipoCambio                     float,  
   @Personal                       char(10),  
   @FechaD                         datetime,  
   @FechaA                         datetime,  
   @PeriodoTipo                    varchar(20),  
   @CfgAjusteMensualISR            bit,  
   @CfgSueldoMinimo                varchar(20),  
   @CfgTablaVacaciones             varchar(50),  
   @CfgSubsidioIncapacidadEG       bit,  
   @CfgPrimaDominicalAuto          bit,  
   @CfgISRReglamentoAguinaldo      bit,  
   @CfgISRReglamentoPTU            bit,  
   @CfgISRLiquidacionSueldoMensual varchar(50),  
   @CfgFactorIntegracionAntiguedad varchar(20),  
   @CfgFactorIntegracionTabla      varchar(50),  
   @NomTipo                        varchar(50),  
   @NomCalcSDI                     bit,  
   @NomCxc                         varchar(20),  
   @RepartirDesde                  datetime,  
   @RepartirHasta                  datetime,  
   @RepartirIngresoTope            money,  
   @RepartirIngresoFactor          float,  
   @RepartirDiasFactor             float,  
   @CalendarioEsp                  bit,  
   @IncidenciaD                    datetime,  
   @IncidenciaA                    datetime,  
   @Estacion		                   int,
   @Ok                             int  OUTPUT,  
   @OkRef                          varchar(255) OUTPUT  
AS BEGIN  
  DECLARE  
    @RedondeoMonetarios    int,  
    @Dia                   int,  
    @Mes                   int,  
    @Ano                   int,  
    @Calc                  float,  
    @CalcImporte           money,  
    @FechaDAno             int,  
    @FechaAAno             int,  
    @DescansaDomingos      bit,  
    @LaboraDomingos        bit,  
    @EsInicioMes           bit,  
    @EsFinMes              bit,  
    @EsBimestre            bit,  
    @PrimerDiaMes          datetime,  
    @PrimerDiaMesAnterior  datetime,  
    @PrimerDiaBimestre     datetime,  
    @PrimerDiaBimestreAnterior     datetime,  
    @UltimoDiaBimestreAnterior  datetime,  
    @UltimoDiaMesAnterior  datetime,  
    @UltimoDiaMes          datetime,  
    @PersonalEstatus       varchar(15),  
    @PersonalCtaDinero     varchar(20),  
    @SucursalTrabajo       int,  
    @SucursalTrabajoEstado varchar(50),  
    @Categoria             varchar(50),  
    @Puesto                varchar(50),  
    @Cliente               varchar(10),  
    @Jornada               varchar(20),  
    @JornadaDiasLibres     int,  
    @JornadaHoras          float,  
    @PersonalDiasPeriodo   varchar(20),  
    @ZonaEconomica         varchar(30),  
    @SMZ                   money,  
    @SMZTopeHorasDobles    float,  
    @SMZPrimaAntiguedad    float,  
    @SMDF                  money,  
    @PrimerDiaAno          datetime,  
    @PrimerDiaAno1         datetime,  
    @PrimerDiaAnoAnterior  datetime,  
    @UltimoDiaAno          datetime,  
    @UltimoDiaAnoAnterior  datetime,  
    @FechaAlta             datetime,  
    @FechaBaja             datetime,  
    @FechaAntiguedad         datetime,  
    @FechaAniversario        datetime,  
    @FechaDAntiguedad        datetime,  
    @FechaAAntiguedad        datetime,  
    @UltimoPago              datetime,  
    @EsSocio                 bit,  
    @SDI                     money,  
    @SDINuevo                money,  
    @SueldoPeriodo           money,  
    @SueldoDiario            money,  
    @SueldoMensual           money,  
    @SueldoMensualReglamento money,  
    @DiasMes                 float,  
    @DiasMesTrabajados       float,  
    @DiasBimestre            float,  
    @DiasBimestreTrabajados  float,  
    @DiasAno                 float,  
    @Aguinaldo               money,  
    @AguinaldoAcumulado      money,  
    @DiasAguinaldo           float,  
    @DiasAguinaldoSiguiente  float,  
    @DiasAguinaldoProporcion  float,  
    @DiasAguinaldoSt       varchar(50),  
    @DiasPeriodo           float, 
    @DiasPeriodoSubsidio   float, 
    @DiasHabilesPeriodo    float,
    @DiasPeriodoEstandar   float,  
    @DiasTrabajados        float,  
    @DiasTrabajadosImporte float,  
    @DiasNaturales         float,  
    @FactorAusentismo      float,  
    @DiasNaturalesTrabajados  float,  
    @DiasNaturalesOriginales  float,  
    @DiasNaturalesDiferencia  float,  
    @DiasPrimaAntiguedad   float,  
    @DomingosLaborados     float,  
    @Faltas                float,  
    @FaltasAcumulado       float,  
    @FaltasImporte         money,  
    @Incapacidades         float,  
    @IncapacidadesAcumulado float,  
    @IncapacidadesImporte  money,  
    @ISR                   money,  
    @ISRAcumulado          money,  
    @ISRBruto              money,  
    @ISRVencimiento        datetime,  
    @ISRSubsidio           money,  
    @ISRSubsidioAcumulado  money,  
    @ISRSubsidioPct        float,  
    @ISRSubsidioPctH       float,  
    @ISRCreditoAlSalarioTabla  money,  
    @ISRSubsidioAlEmpleoTabla  money,  
    @ISRCreditoAlSalarioAcumulado money,  
    @ISRSubsidioAlEmpleoAcumulado money,  
    @ISRBase               money,  
    @ISRBaseMes            money,  
    @ISRBaseAcumulado      money,  
    @ISRReglamentoBase     float,  
    @ISRReglamentoFactor   float,  
    @ISRSueldoMensual      money,  
    @ISRSueldoMensualReglamento  money,  
    @ISRLiquidacion        money,  
    @ISRLiquidacionExcento money,  
    @ISRLiquidacionGravable  money,  
    @ISRLiquidacionFactor  float,  
    @ISRLiquidacionBase    float,  
    @ISRAnual              money,  
    @ISRAjuste             money,  
    @ISRAjusteMax          money,  
    @ISRAjusteAnual        money,  
    @SubsidoSueldoMensual  money,  
    @SubsidoSueldoMensualReglamento money,  
    @IMSSBase              money,  
    @IMSSBaseAcumulado     money,  
    @IMSSBaseMes           money,  
    @ImpuestoEstatalBase   money,  
    @CedularBase           money,  
    @AcreedorIMSS          varchar(10),  
    @AcreedorRetiro        varchar(10),  
    @AcreedorISR           varchar(10),  
    @AcreedorInfonavit     varchar(10),  
    @AcreedorFonacot       varchar(10),  
    @AcreedorImpuestoEstatal  varchar(10),  
    @IMSSVencimiento       datetime,  
    @IMSSVencimientoBimestre  datetime,  
    @IMSSObrero            money,  
    @IMSSObreroCV          money,  
    @IMSSObreroSinCV       money,  
    @IMSSPatron            money,  
    @IMSSPatronMensual     money,  
    @IMSSPatronCV          money,  
    @IMSSPatronRetiro      money,  
    @IMSSPatronInfonavit   money,  
    @Antiguedad            float,  
    @AntiguedadFlotante    float,  
    @AntiguedadSiguiente   float,  
    @AntiguedadDia         int,  
    @AntiguedadMes         int,  
    @PrimaDominicalPct     float,  
    @PrimaDominical        money,  
    @PrimaVacacionalPct    float,  
    @Vacaciones            money,  
    @VacacionesTomadas     float,  
    @PrimaAntiguedad       money,  
    @PrimaVacacional       money,  
    @PrimaVacacionalProporcion  money,  
    @PrimaVacacionalTope   money,  
    @PrimaVacacionalExcenta money,  
    @DiasVacaciones        float,  
    @DiasVacacionesProporcion  float,  
    @DiasVacacionesSiguiente  float,  
    @DiasVacacionesAcumulado  float,  
    @FactorIntegracion     float,  
    @ImpuestoEstatal       money,  
    @ImpuestoEstatalPct    float,  
    @ImpuestoEstatalGastoOperacionPct float,  
    @ImpuestoEstatalVencimiento       datetime,  
    @InfonavitObrero          money,  
    @AcumuladoInfonavitObrero money,
    @InfonavitSDI          float,  
    @InfonavitSMGDF        float,  
    @InfonavitImporte      float,  
    @SeguroRiesgoInfonavit money,  
    @PensionASueldoBruto   float,  
    @PensionASueldoBruto2  float,  
    @PensionASueldoBruto3  float,  
    @PensionASueldoNeto    float,  
    @PensionASueldoNeto2   float,  
    @PensionASueldoNeto3   float,  
    @PensionAAcreedor      varchar(10),  
    @PensionAAcreedor2     varchar(10),  
    @PensionAAcreedor3     varchar(10),  
    @PercepcionBruta       money,  
    @CajaAhorro            money,  
    @CajaAhorroDesde       datetime,  
    @CajaAhorroHasta       datetime,  
    @CajaAhorroLiquidacion datetime,  
    @CajaAhorroInteresTotalPct  float,  
    @CajaAhorroAcumulado   money,  
    @CajaAhorroAcumuladoDias float,  
    @CajaAhorroIngresosTopados money,  
    @CajaAhorroDiasTrabajados money,  
    @FondoAhorroFactorAusentismo varchar(10),
    @ValesDespensaFactorAusentismo varchar(10),
    @AyudaFamiliarFactorAusentismo varchar(10),
    @FondoAhorroPct        float,  
    @FondoAhorro           money,  
    @FondoAhorro1           money,  
    @FondoAhorroAnticipoPct float,  
    @FondoAhorroDesde      datetime,  
    @FondoAhorroHasta      datetime,  
    @FondoAhorroLiquidacion datetime,  
    @FondoAhorroInteresTotal money,  
    @FondoAhorroInteresTotalPct float,  
    @FondoAhorroDiasAcumulado float,  
    @FondoAhorroAcumulado  money,  
    @FondoAhorroAcumuladoDias  float,  
    @FondoAhorroPatronAcumulado  money,  
    @FondoAhorroPatronAcumuladoDias float,  
    @FondoAhorroAnticipoAcumulado  money,  
    @FondoAhorroPrestamoAcumulado  money,  
    @FondoAhorroAnticipoAcumuladoDias float,  
    @FondoAhorroIngresosTopados  money,  
    @FondoAhorroDiasTrabajados  money,  
    @EsAniversario         bit,  
    @OtorgarDiasVacacionesAniversario bit,  
    @OtorgarPrimaVacacionalAniversario bit,
    @OtorgarPrimaVacacionalAguinaldo   bit,
    @TieneValesDespensa    bit,  
    @ValesDespensaPct      float,  
    @ValesDespensaImporte  money,  
    @ValesDespensaImportePension  money,  
    @ValesDespensa         money,  
    @PremioPuntualidadPct  float,  
    @AyudaTransportePct	   float,    
    @PremioAsistenciaPct   float,  
    @PersonalNeto          money,  
    @PersonalPercepciones  money,  
    @PersonalDeducciones   money,  
    @SueldoMinimo          money,  
    @IndemnizacionPct      float,  
    @Indemnizacion         money,  
    @IndemnizacionTope     money,  
    @Indemnizacion3Meses   money,  
    @Indemnizacion20Dias   money,  
    @SueldoVariable        money,  
    @SueldoVariableAcumulado  money,  
    @SueldoVariableDias    float,  
    @SueldoVariablePromedio money,  
    @SueldoVariablePTUDesde datetime,  
    @SueldoVariablePTUHasta datetime,  
    @SueldoVariableAguinaldoDesde datetime,  
    @SueldoVariableAguinaldoHasta datetime,  
    @PTUIngresosTopados    money,  
    @PTUDiasTrabajados     money,  
    @DescuentoISRAjusteAnualPct float,  
    @FiniquitoNetoEnCeros  bit,  
    @ConSueldoMinimo       bit,  
    @SubsidioProporcionalFalta bit,
    @BeneficiarioSueldoNeto  varchar(100),  
    @Contrato              varchar(100),  
    @MaxID                 int,  
    @MaxRID                float,  
    @IncapacidadesD        int,  
    @CuotaSindical         money,  
    @Mov                   varchar(20),  
    @ImporteISR            money,   
    @NuevoImporteISR       money,  
    @ImporteCAS            money,   
    @NuevoImporteCAS       money,  
    @DiasPeriodoMes        int,  
    @DiasMesInfonavit      int,   
    @MesI                  int,   
    @YearI                 int,
    @SDIAnterior           money,
    @SDIVariableDiario     money,
    @SDIBruto              money,
    @FhiAntiguedad         float,
    @FhiAntiguedadSDI      datetime,
    @AntiguedadSDI	   float,
    @DiasAguinaldoSDI			 float,
    @DiasAguinaldoSiguienteSDI	float,
    @AntiguedadSiguienteSDI float,
    @InfonavitDias         int,
    @ImpuestoEstatalExento float,
    @AguinaldoImporte		   money,
    @SueldoDiarioComplemento money,
    @ISRBaseAcumuladoSubsidioEmpleo	float,
    @DiasTrabajadosSubsidioAcumulado float,
    @DiasTrabajadosImporteSubsidio money,
    @AyudaFamiliar                  money,
    @DiasBimestreInfonavit int,
    @TopeFondoAhorro       money,
    @FondoAhorroTipoContrato varchar(20),
    @FondoAhorroEnFiniquito  varchar(2),
    @Plaza varchar(10),
    @PctIncremento float,
    @EsISRReglamento bit,
    @PrestamoFondoAhorroDesde datetime,
    @PrestamoFondoAhorroHasta datetime,
    @FechaInicioDescuentoInfonavit datetime,
    @DiasNaturalesInfonavit  float,
    @FondoAhorroAusentismoAcumulado float,
    @FondoAhorroAusentismoHorasAcumulado float,
    @FechaOrigen datetime,
    @SeguroAuto                 money,
    @SeguroMedico               money,
    @PensionSueldoNeto          money,
    @DESCAUSENTISMOFONDOAHORRO  money,
    @DESCAUSENTIMOAYUDAFAMILIAR	money,
    @DESCAUSENTHORASFONDOAH     money,
    @DESCAUSENTHORASAYUDAFAMIL  money

  SELECT @FechaOrigen = FechaOrigen FROM Nomina WHERE ID = @ID  
  SELECT @Plaza = Plaza FROM Personal WHERE Personal = @Personal
  SELECT @Mov = Mov FROM Nomina WHERE ID = @ID  
  
  SELECT @Mov =LTRIM(RTRIM(@Mov)  )
   
-- /* SOPORTE */ spNominaGenerar 100, 15480, '01/16/2008 00:00:00', '01/31/2008 00:00:00', 'Quincenal', '02/15/2008 00:00:00'
-- select 'pase'

  SELECT @EsInicioMes = 0, @EsFinMes = 0, @EsBimestre = 0, @Incapacidades = 0, @Faltas = 0, @EsAniversario = 0, @DiasNaturalesDiferencia = 0,  
         @ISRBase = 0.0, @IMSSBase = 0.0, @ImpuestoEstatalBase = 0.0, @CedularBase = 0.0,  
         @ISR = 0.0, @IMSSObrero = 0.0, @IMSSPatron = 0.0, @SueldoMinimo = 0.0, @DomingosLaborados = 0.0, @DiasAguinaldo = 0.0, @DiasAguinaldoSiguiente = 0.0,  
         @SueldoVariable = 0.0, @SubsidioProporcionalFalta=0  
  
  SELECT @SucursalTrabajo  = p.SucursalTrabajo,  
         @SucursalTrabajoEstado  = s.Estado,  
         @Categoria    = p.Categoria,  
         @Puesto   = p.Puesto,  
         @Cliente   = p.Cliente,  
         @PersonalEstatus  = p.Estatus,  
         @PersonalCtaDinero  = p.CtaDinero,  
         @SDI     = ISNULL(p.SDI, 0.0),  
         @SueldoDiario   = ISNULL(p.SueldoDiario, 0.0),  
         @FechaAlta    = p.FechaAlta,  
         @FechaAntiguedad  = ISNULL(p.FechaAntiguedad, p.FechaAlta),  
         @FechaBaja   = p.FechaBaja,  
         @Jornada   = p.Jornada,  
         @JornadaHoras   = NULLIF(j.HorasPromedio, 0.0),  
         @PersonalDiasPeriodo  = UPPER(p.DiasPeriodo),  
         @ZonaEconomica   = p.ZonaEconomica,  
         @UltimoPago   = p.UltimoPago,  
         @EsSocio   = ISNULL(p.EsSocio, 0),  
         @DiasPeriodoEstandar   = ISNULL(pt.DiasPeriodo, 0),  
         @DescansaDomingos  = ISNULL(j.Domingo, 0),  
         @IndemnizacionPct  = ISNULL(p.IndemnizacionPct, 100.0),  
         @Contrato   = UPPER(p.TipoContrato)  ,
         @DiasHabilesPeriodo = ISNULL(pt.DiasHabiles, 0),  
         @FactorAusentismo  = ISNULL(j.FactorAusentismo, 0),
         @PctIncremento    = isnull(p.Incremento,0),
         @SueldoDiarioComplemento = ISNULL(SueldoDiarioComplemento,0.0) 
    FROM Personal p  
    LEFT OUTER JOIN PeriodoTipo pt ON pt.PeriodoTipo = p.PeriodoTipo  
    LEFT OUTER JOIN Jornada j ON j.Jornada = p.Jornada  
    LEFT OUTER JOIN Sucursal s ON s.Sucursal = p.SucursalTrabajo  
   WHERE p.Personal = @Personal 
   -- AND p.PeriodoTipo = @PeriodoTipo  

  SELECT @Mov = Mov FROM Nomina WHERE ID = @ID  
  SELECT @Mov =LTRIM(RTRIM(@Mov)  )
     

  IF @FechaA < @FechaAlta and @mov <>'Presupuesto' SELECT @Ok = 45010  
  IF @UltimoPago > @FechaA and @Nomtipo <> 'Impuesto Estatal' and @mov <>'Presupuesto' SELECT @Ok = 45020  
  
  SELECT @DiasNaturalesOriginales = DATEDIFF(day, @FechaD, @FechaA) + 1  
  
  IF @Mov ='PRESUPUESTO' 
   BEGIN
     SELECT @Diasperiodo=30, @DiasPeriodoEstandar=30, @PersonalDiasPeriodo=30, @DiasNaturalesOriginales=30
     
     IF (5000)-(@SueldoDiario * 30.0 * 1.20) > 2  -- si no ha llegado a 5000
       SELECT @SueldoDiario = @SueldoDiario*(1+(@PctIncremento/100.0))
     ELSE 
       SELECT @SueldoDiarioComplemento = ((((@SueldoDiario*1.20)+(@SueldoDiarioComplemento*0.9)) * (1+(@PctIncremento/100.0)))  - (@SueldoDiario*1.20))/0.9
   END
   
  IF @UltimoPago IS NULL SELECT @FechaD = @FechaAlta  
  
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')  
  BEGIN  
    IF @UltimoPago IS NULL SELECT @FechaD = @FechaAlta ELSE SELECT @FechaD = DATEADD(day, 1, @UltimoPago)  
    IF @PersonalEstatus = 'BAJA' SELECT @FechaA = ISNULL(@FechaBaja, @FechaTrabajo) ELSE SELECT @FechaA = FechaOrigen FROM Nomina WHERE ID = @ID  
  END  
  IF @CalendarioEsp = 0 SELECT @IncidenciaD = @FechaD, @IncidenciaA = @FechaA  
    
  SELECT @RedondeoMonetarios = RedondeoMonetarios FROM Version  
  SELECT @SMDF = SueldoMinimo FROM ZonaEconomica WHERE Zona = 'A'  
  SELECT @SMZ = SueldoMinimo FROM ZonaEconomica WHERE Zona = @ZonaEconomica  

  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Mes',      @DiasMes OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Ano',     @DiasAno OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Aguinaldo',    @DiasAguinaldoSt OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Subsidio Acreditable Honorarios',    @ISRSubsidioPct OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Subsidio Acreditable',    @ISRSubsidioPct OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Prima Dominical',    @PrimaDominicalPct OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Prima Vacacional',    @PrimaVacacionalPct OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor SHCP',     @AcreedorISR OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor IMSS',     @AcreedorIMSS OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Retiro',     @AcreedorRetiro OUTPUT  
  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Infonavit',    @AcreedorInfonavit OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Fonacot',    @AcreedorFonacot OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Impuesto Estatal',  @AcreedorImpuestoEstatal OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# SMZ Prima Antiguedad',    @SMZPrimaAntiguedad OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Impuesto Estatal',    @ImpuestoEstatalPct OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'GastosOperacionImpuestoEstatal',  @ImpuestoEstatalGastoOperacionPct OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% SDI Credito Infonavit',    @InfonavitSDI OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# SMGDF Credito Infonavit',  @InfonavitSMGDF OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Credito Infonavit',    @InfonavitImporte OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia',  @PensionAAcreedor OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia 2',  @PensionAAcreedor2 OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Acreedor Pension Alimenticia 3',  @PensionAAcreedor3 OUTPUT  
  --EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Cuenta Pension Alimenticia',    @PensionACuenta  OUTPUT  
  --EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Cuenta Pension Alimenticia 2',  @PensionACuenta2 OUTPUT  
  -- EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Cuenta Pension Alimenticia 3',  @PensionACuenta3 OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Ayuda Familiar Factor Ausentismo(S/N)', @AyudaFamiliarFactorAusentismo OUTPUT  
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Ayuda Familiar',     @AyudaFamiliar OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Vales Despensa Factor Ausentismo(S/N)', @ValesDespensaFactorAusentismo OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Fondo Ahorro Factor Ausentismo(S/N)', @FondoAhorroFactorAusentismo OUTPUT  

  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Fondo Ahorro en el Finiquito(S/N)', @FondoAhorroEnFiniquito OUTPUT 
 
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto',  @PensionASueldoBruto OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto 2', @PensionASueldoBruto2 OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Bruto 3', @PensionASueldoBruto3 OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto',  @PensionASueldoNeto OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto 2',  @PensionASueldoNeto2 OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Pension Alimenticia Sueldo Neto 3',  @PensionASueldoNeto3 OUTPUT  
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Caja de Ahorro',     @CajaAhorro OUTPUT  
  EXEC spPersonalPropValorDMA   @Empresa, NULL,   NULL, NULL, NULL, 'Caja de Ahorro Desde (DD/MM/AAAA)',    @CajaAhorroDesde OUTPUT  
  EXEC spPersonalPropValorDMA   @Empresa, NULL,   NULL, NULL, NULL, 'Caja de Ahorro Hasta (DD/MM/AAAA)',    @CajaAhorroHasta OUTPUT  

  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Fondo de Ahorro',    @FondoAhorroPct OUTPUT  
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Fondo de Ahorro',     @FondoAhorro OUTPUT  
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Tope Fondo de Ahorro',     @TopeFondoAhorro OUTPUT
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Fondo Ahorro Tipo Contrato', @FondoAhorroTipoContrato OUTPUT      
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Anticipo Fondo de Ahorro',   @FondoAhorroAnticipoPct OUTPUT  
  EXEC spPersonalPropValorDMA   @Empresa, NULL,   NULL, NULL, NULL, 'Fondo de Ahorro Desde (DD/MM/AAAA)',    @FondoAhorroDesde OUTPUT  
  EXEC spPersonalPropValorDMA   @Empresa, NULL,   NULL, NULL, NULL, 'Fondo de Ahorro Hasta (DD/MM/AAAA)',    @FondoAhorroHasta OUTPUT
  EXEC spPersonalPropValorDMA   @Empresa, NULL,   NULL, NULL, NULL, 'Prestamo Fondo de Ahorro Desde (DD/MM/AAAA)',    @PrestamoFondoAhorroDesde OUTPUT  
  EXEC spPersonalPropValorDMA   @Empresa, NULL,   NULL, NULL, NULL, 'Prestamo Fondo de Ahorro Hasta (DD/MM/AAAA)',    @PrestamoFondoAhorroHasta OUTPUT
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# SMZ Tope Horas Dobles',    @SMZTopeHorasDobles OUTPUT  

  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Dias Vacaciones Aniversario (S/N)', @OtorgarDiasVacacionesAniversario OUTPUT  
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Prima Vacacional Aniversario (S/N)', @OtorgarPrimaVacacionalAniversario OUTPUT  
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Prima Vacacional Tipo Aguinaldo (S/N)', @OtorgarPrimaVacacionalAguinaldo OUTPUT  
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Vales Despensa (S/N)',   @TieneValesDespensa OUTPUT  
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'SubsidioProporcionalAusentismo(S/N)', @SubsidioProporcionalFalta OUTPUT
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Vales Despensa % Sueldo',   @ValesDespensaPct OUTPUT  
  EXEC spPersonalPropValorMoney @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Vales Despensa Importe',   @ValesDespensaImporte OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Premio Puntualidad',   @PremioPuntualidadPct OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Ayuda Transporte',     @AyudaTransportePct   OUTPUT    
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Premio Asistencia',   @PremioAsistenciaPct OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '# Dias Prima Antiguedad',    @DiasPrimaAntiguedad OUTPUT  
  EXEC spPersonalPropValorDMA   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Sueldo Variable PTU Desde (DD/MM/AAAA)',  @SueldoVariablePTUDesde OUTPUT  

  EXEC spPersonalPropValorDMA   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Sueldo Variable PTU Hasta (DD/MM/AAAA)',  @SueldoVariablePTUHasta OUTPUT  
  EXEC spPersonalPropValorDMA   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Sueldo Variable Aguinaldo Desde (DD/MM/AAAA)', @SueldoVariableAguinaldoDesde OUTPUT  
  EXEC spPersonalPropValorDMA   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Sueldo Variable Aguinaldo Hasta (DD/MM/AAAA)', @SueldoVariableAguinaldoHasta OUTPUT  
 

   EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '% Desc ISR Ajuste Anual (Sueldo Dias Trabajados)', @DescuentoISRAjusteAnualPct OUTPUT  
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Labora Domingos (S/N)',   @LaboraDomingos OUTPUT  
  EXEC spPersonalPropValorBit   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Finiquito Neto en Ceros (S/N)',  @FiniquitoNetoEnCeros OUTPUT  
  EXEC spPersonalPropValor      @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Beneficiario Sueldo Neto',   @BeneficiarioSueldoNeto OUTPUT  
  EXEC spPersonalPropValorFloat @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Seguro Riesgo Infonavit',  @SeguroRiesgoInfonavit OUTPUT    
--/* INTELISIS */ spNominaGenerar 100, 1885, '05/26/2008 00:00:00', '06/08/2008 00:00:00', 'Catorcenal', '06/02/2008 00:00:00'
 
 EXEC spPersonalPropValorDMA   @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, 'Fecha Inicio Descuento', @FechaInicioDescuentoInfonavit OUTPUT  
  
--/* INTELISIS */ spNominaGenerar 100, 1885, '05/26/2008 00:00:00', '06/08/2008 00:00:00', 'Catorcenal', '06/02/2008 00:00:00'
  
  EXEC spNominaCalculaDiasMes  @FechaD, @FechaA, @DiasPeriodoMes OUTPUT  
  IF @FechaAntiguedad > @SueldoVariablePTUDesde SELECT @SueldoVariablePTUDesde = @FechaAntiguedad  
  IF @FechaAntiguedad > @SueldoVariableAguinaldoDesde SELECT @SueldoVariableAguinaldoDesde = @FechaAntiguedad  



  IF @PeriodoTipo='CONFIDENCIAL'
    SELECT @PeriodoTipo = 'QUINCENAL' 

  SELECT @Dia = DAY(@FechaA), @Mes = MONTH(@FechaA), @Ano = YEAR(@FechaA)  
  EXEC spIntToDateTime 1, 1, @Ano, @PrimerDiaAno OUTPUT  
  EXEC spIntToDateTime 31, 12, @Ano, @UltimoDiaAno OUTPUT  
  EXEc SPDiasMes @Mes,@Ano,@Dia OUTPUT

  SELECT @Dia = DAY(@FechaA), @Mes = MONTH(@FechaA), @Ano = YEAR(@FechaA)
  EXEc SPDiasMes @Mes,@Ano,@Dia OUTPUT
  EXEC spIntToDateTime @DIA, @MEs, @Ano, @UltimoDiaMes OUTPUT  
  
  SELECT @Dia = DAY(@FechaA), @Mes = MONTH(@FechaA), @Ano = YEAR(@FechaA)  
  
  SELECT @PrimerDiaAnoAnterior = DATEADD(year, -1, @PrimerDiaAno),  
         @UltimoDiaAnoAnterior = DATEADD(year, -1, @UltimoDiaAno)  
  SELECT @PrimerDiaAno1 = @PrimerDiaAno

  IF @OtorgarPrimaVacacionalAguinaldo = 1 
  BEGIN
    IF @FechaAntiguedad < @PrimerDiaAno 
      SELECT  @PrimerDiaAno1  = @PrimerDiaAno
    ELSE
      SELECT  @PrimerDiaAno1  = @FechaAntiguedad
  END ELSE 
    SELECT @PrimerDiaAno1 = case when @FechaAntiguedad > @PrimerDiaAno then @FechaAntiguedad else @PrimerDiaAno END

  IF ISNUMERIC(@DiasAguinaldoSt) = 1  
	  SELECT @DiasAguinaldo = CONVERT(float, @DiasAguinaldoSt), @DiasAguinaldoSiguiente = CONVERT(float, @DiasAguinaldoSt),  @DiasAguinaldoSDI = CONVERT(float, @DiasAguinaldoSt), @DiasAguinaldoSiguienteSDI = CONVERT(float, @DiasAguinaldoSt)

  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')  
    SELECT @SueldoMinimo = 0.0  
  ELSE  
  IF @CfgSueldoMinimo = 'OFICIAL'  
    SELECT @SueldoMinimo = @SMDF * @DiasMes * 1.3  
  IF @FechaAlta > @FechaD SELECT @FechaD = @FechaAlta  
  SELECT @DiasNaturales = DATEDIFF(day, @FechaD, @FechaA) + 1  
  SELECT @DiasNaturalesDiferencia = @DiasNaturalesOriginales - @DiasNaturales  
  SELECT @DiasPeriodo = @DiasNaturales  
  
--spNominaGenerar 450, 10, '14/04/2008 00:00:00', '27/04/2008 00:00:00', 'Catorcenal', '21/04/2008 00:00:00'

  IF @NomTipo = 'NORMAL'  
  BEGIN  
    IF @PersonalDiasPeriodo = 'DIAS PERIODO'  
      SELECT @DiasPeriodo = @DiasPeriodoEstandar - @DiasNaturalesDiferencia  
    ELSE  
    IF @PersonalDiasPeriodo = 'DIAS JORNADA'  
    BEGIN  
      EXEC spJornadaDiasLibres @Jornada, @FechaD, @FechaA, @JornadaDiasLibres OUTPUT  
	    SET @JornadaDiasLibres = 0
      SELECT @DiasPeriodo = dbo.fnMayor(0, @DiasNaturales - @JornadaDiasLibres)  
    END  
  END  
 
  EXEC spFechaAniversario @FechaAntiguedad, @FechaA, @FechaAniversario OUTPUT  

  /* Para que pague la quincena de maximo 15 dias y no de 16 */  
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') AND @PeriodoTipo IN ('QUINCENAL', 'MENSUAL','CONFIDENCIAL') 
     AND (SELECT dbo.fnEsFinMes(@FechaA)) = 0  
    SELECT @DiasPeriodo = @DiasNaturales  
  
  SELECT @DiasMes = NULLIF(@DiasMes, 0), @DiasMesTrabajados = NULLIF(@DiasMesTrabajados, 0), @DiasBimestre = NULLIF(@DiasBimestre, 0),  
         @DiasBimestreTrabajados = NULLIF(@DiasBimestreTrabajados, 0), @DiasAno = NULLIF(@DiasAno, 0),  
         @DiasPeriodo = NULLIF(@DiasPeriodo, 0), @DiasTrabajados = NULLIF(@DiasTrabajados, 0), @DiasNaturales = NULLIF(@DiasNaturales, 0),  
         @DiasNaturalesTrabajados = NULLIF(@DiasNaturalesTrabajados, 0), @DiasNaturalesOriginales = NULLIF(@DiasNaturalesOriginales, 0),  
         @DiasNaturalesDiferencia = NULLIF(@DiasNaturalesDiferencia, 0)  
  
  SELECT @Antiguedad = dbo.fnAntiguedad(@FechaAntiguedad, @FechaA)  

  IF @OtorgarPrimaVacacionalAguinaldo = 1
    IF @NomTipo in( 'Normal', 'Prima Vacacional', 'SDI') AND YEAR(@Antiguedad) < YEAR(@FechaA) AND @OtorgarPrimaVacacionalAguinaldo = 1
      SELECT @Antiguedad = YEAR(@UltimoDiaano) - YEAR(@FechaAntiguedad)  

  IF @OtorgarPrimaVacacionalAguinaldo = 1
    IF @NomTipo in( 'Normal', 'Prima Vacacional', 'SDI') AND YEAR(@Antiguedad) = YEAR(@FechaA) AND @OtorgarPrimaVacacionalAguinaldo = 1
      SELECT @Antiguedad = dbo.fnAntiguedad(@FechaAntiguedad, @UltimoDiaAno)  
  
  IF @OtorgarPrimaVacacionalAguinaldo = 1
    IF @NomTipo in( 'Finiquito', 'Liquidacion') AND YEAR(@Antiguedad) < YEAR(@FechaA) AND @OtorgarPrimaVacacionalAguinaldo = 1
      SELECT @Antiguedad = YEAR(@FechaA) - YEAR(@FechaAntiguedad)    
  
  IF @OtorgarPrimaVacacionalAguinaldo = 1
    IF @NomTipo in( 'Finiquito', 'Liquidacion') AND YEAR(@Antiguedad) = YEAR(@FechaA) AND @OtorgarPrimaVacacionalAguinaldo = 1
      SELECT @Antiguedad = dbo.fnAntiguedad(@FechaAntiguedad, @FechaA)  
    
 
  SELECT @AntiguedadSiguiente = dbo.fnAntiguedad(@FechaAntiguedad, @FechaA) + 1  
  SELECT @AntiguedadFlotante = dbo.fnAntiguedadFloat(@FechaAntiguedad, @FechaA)  
  SELECT @AntiguedadDia = DAY(@FechaAntiguedad), @AntiguedadMes = MONTH(@FechaAntiguedad), @FechaDAno = YEAR(@FechaD), @FechaAAno = YEAR(@FechaA)  
  EXEC   spIntToDateTime @AntiguedadDia, @AntiguedadMes, @FechaDAno, @FechaDAntiguedad OUTPUT  
  EXEC   spIntToDateTime @AntiguedadDia, @AntiguedadMes, @FechaAAno, @FechaAAntiguedad OUTPUT  
  EXEC   spTablaNum @CfgTablaVacaciones, @Antiguedad, @DiasVacaciones OUTPUT  
  EXEC   spTablaNum @CfgTablaVacaciones, @AntiguedadSiguiente, @DiasVacacionesSiguiente OUTPUT  
  IF @Antiguedad > 0 AND (@FechaDAntiguedad BETWEEN @FechaD AND @FechaA OR @FechaAAntiguedad BETWEEN @FechaD AND @FechaA)  
    SELECT @EsAniversario = 1  
    
  IF ISNULL(@DiasPeriodo, 0) = 0  SELECT @DiasNaturales = 0, @DiasPeriodo = 0  
  
  IF ISNUMERIC(@DiasAguinaldoSt) = 0  
  BEGIN  
    EXEC spTablaNum @DiasAguinaldoSt, @Antiguedad, @DiasAguinaldo OUTPUT  
    EXEC spTablaNum @DiasAguinaldoSt, @AntiguedadSiguiente, @DiasAguinaldoSiguiente OUTPUT  
  END  
  
  SELECT @IndemnizacionTope = @SMZ * 90 * ROUND(@AntiguedadFlotante, 0)  
  SELECT @PrimaVacacional = @SueldoDiario * @DiasVacaciones * (@PrimaVacacionalPct/100.0)  
  
  IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')  
  BEGIN  
    IF @OtorgarPrimaVacacionalAguinaldo = 0
    BEGIN 
      SELECT @DiasVacacionesProporcion = @DiasVacacionesSiguiente * dbo.fnAntiguedadFloat(@FechaAniversario, @FechaA)  
      SELECT @PrimaVacacionalProporcion = @SueldoDiario * @DiasVacacionesProporcion * (@PrimaVacacionalPct/100.0)  
    END 
    IF @OtorgarPrimaVacacionalAguinaldo = 1
    BEGIN
      SELECT @DiasVacacionesProporcion = @DiasVacaciones/*Siguiente*/ * dbo.fnAntiguedadFloat(@PrimerDiaAno1, @FechaA)  
      SELECT @PrimaVacacionalProporcion = @SueldoDiario * @DiasVacacionesProporcion * (@PrimaVacacionalPct/100.0)  
    END
    
  END  
 
  -- Aguinaldo  
  IF @NomTipo = 'AGUINALDO'  
  BEGIN
    IF @PUESTO IN('Vendedor(a)','Vendedor Viajero')
    BEGIN
      SELECT @SueldoVariableDias = DATEDIFF(day, @SueldoVariableAguinaldoDesde, @SueldoVariableAguinaldoHasta) + 1  
      EXEC spNominaSueldoVariableAcumuladoFechas @Empresa, @Personal, @SueldoVariableAguinaldoDesde, @SueldoVariableAguinaldoHasta, @SueldoVariableAcumulado OUTPUT  
    END ELSE
      SELECT @SueldoVariableDias = 0

    IF @FechaAntiguedad < @PrimerDiaAno1    
      SELECT @DiasAguinaldoProporcion = DATEDIFF(DAY,@PrimerDiaAno1,@UltimoDiaAno) + 1
    ELSE
	    SELECT @DiasAguinaldoProporcion = DATEDIFF(DAY, @FechaAntiguedad,@UltimoDiaAno) + 1

    SELECT @DiasAguinaldoProporcion = ISNULL((@DiasAguinaldoProporcion / @DiasAno) * (@DiasAguinaldo - ISNULL(@FaltasAcumulado,0)),0)
    SELECT @SueldoVariablePromedio = @SueldoVariableAcumulado / NULLIF(@SueldoVariableDias, 0)  
    SELECT @Aguinaldo = (@SueldoDiario + ISNULL(@SueldoVariablePromedio, 0.0)) * @DiasAguinaldoProporcion
    SELECT @AguinaldoImporte = @Aguinaldo
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Aguinaldo', @Empresa, @Personal, @DiasAguinaldoProporcion, @Aguinaldo  
  END ELSE  
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') AND @FechaA >= @PrimerDiaAno  
    BEGIN  
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Aguinaldo', @PrimerDiaAno, @FechaA, NULL, @AguinaldoAcumulado OUTPUT, NULL  
      SELECT @DiasAguinaldoProporcion = @DiasAguinaldoSiguiente * dbo.fnAntiguedadFloat(@PrimerDiaAno1, @FechaA)  
      SELECT @Aguinaldo = (@SueldoDiario * @DiasAguinaldoProporcion) - @AguinaldoAcumulado  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Aguinaldo', @Empresa, @Personal, @DiasAguinaldoProporcion, @Aguinaldo  
    END  
  -- PTU  
  IF @NomTipo = 'PTU'  
  BEGIN  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'DiasTrabajados', @RepartirDesde, @RepartirHasta, NULL, @DiasTrabajadosImporte OUTPUT, @DiasTrabajados OUTPUT  
    IF @DiasTrabajados>=60  
    BEGIN  
      SELECT @PTUIngresosTopados = dbo.fnMenor(@DiasTrabajadosImporte, @RepartirIngresoTope) * @RepartirIngresoFactor  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PTU/IngresosTopados', @Empresa, @Personal, @DiasTrabajados, @PTUIngresosTopados  
  
      SELECT @PTUDiasTrabajados = @DiasTrabajados * @RepartirDiasFactor  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PTU/DiasTrabajados', @Empresa, @Personal, @DiasTrabajados, @PTUDiasTrabajados  
  
      SELECT @CalcImporte = @PTUIngresosTopados + @PTUDiasTrabajados  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PTU', @Empresa, @Personal, @DiasTrabajados, @CalcImporte  
    END  
  END  
  IF @NomTipo = 'PRESTAMO FONDO AHORR'
  BEGIN
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 'FondoAhorro',                 @PrestamoFondoAhorroDesde, @PrestamoFondoAhorroHasta, NULL, @FondoAhorroAcumulado OUTPUT, @FondoAhorroAcumuladoDias OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 'FondoAhorro/Patron',          @PrestamoFondoAhorroDesde, @PrestamoFondoAhorroHasta, NULL, @FondoAhorroPatronAcumulado OUTPUT, @FondoAhorroPatronAcumuladoDias OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 'FondoAhorro/Anticipo',        @PrestamoFondoAhorroDesde, @PrestamoFondoAhorroHasta, NULL, @FondoAhorroAnticipoAcumulado OUTPUT, @FondoAhorroAnticipoAcumuladoDias OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 'FondoAhorro/Prestamo',        @PrestamoFondoAhorroDesde, @PrestamoFondoAhorroHasta, NULL, @FondoAhorroPrestamoAcumulado OUTPUT, @FondoAhorroAnticipoAcumuladoDias OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 'FondoAhorro/Ausentismo',      @PrestamoFondoAhorroDesde, @PrestamoFondoAhorroHasta, NULL, @FondoAhorroAusentismoAcumulado OUTPUT,  NULL
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 'FondoAhorro/AusentismoHoras', @PrestamoFondoAhorroDesde, @PrestamoFondoAhorroHasta, NULL, @FondoAhorroAusentismoHorasAcumulado OUTPUT, NULL
    
-- select * from cfgnominaconcepto  where nominaconcepto in ('208')
    SELECT @FondoAhorroAcumulado = ISNULL(@FondoAhorroAcumulado,0) + ISNULL(@FondoAhorroPatronAcumulado,0) - (ISNULL(@FondoAhorroAnticipoAcumulado,0) + ISNULL(@FondoAhorroPrestamoAcumulado,0)- ISNULL(@FondoAhorroAusentismoAcumulado,0)*2.0 - ISNULL(@FondoAhorroAusentismoHorasAcumulado,0)*2.0)
    
    IF ISNULL(@FondoAhorroAnticipoPct,0.0) > 0.0
    BEGIN
      SELECT @FondoAhorro = @FondoAhorroAcumulado * @FondoAhorroAnticipoPct / 100.0
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/Prestamo', @Empresa, @Personal,@FondoAhorroAcumuladoDias, @FondoAhorro  
    END
    
  END
  -- LIQUIDACION FONDO AHORRO   o LIQUIDACION
  IF @NomTipo in( 'LIQUIDACION FONDO AHORRO')  OR ((@NomTipo IN('FINIQUITO')) AND (@FondoAhorroEnFiniquito = 'S'))
  BEGIN  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 	'DiasTrabajados',       @RepartirDesde,    @RepartirHasta,    NULL, @DiasTrabajadosImporte OUTPUT, @DiasTrabajados OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 	'FondoAhorro',          @FondoAhorroDesde, @FondoAhorroHasta, NULL, @FondoAhorroAcumulado OUTPUT, @FondoAhorroAcumuladoDias OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 	'FondoAhorro/Anticipo', @FondoAhorroDesde, @FondoAhorroHasta, NULL, @FondoAhorroAnticipoAcumulado OUTPUT, @FondoAhorroAnticipoAcumuladoDias OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal,  'FondoAhorro/Prestamo',  @FondoAhorroDesde, @FondoAhorroHasta, NULL, @FondoAhorroPrestamoAcumulado OUTPUT, @FondoAhorroAnticipoAcumuladoDias OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal, 	'FondoAhorro/Patron',   @FondoAhorroDesde, @FondoAhorroHasta, NULL, @FondoAhorroPatronAcumulado OUTPUT, @FondoAhorroPatronAcumuladoDias OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal,  'FondoAhorro/Ausentismo',      @FondoAhorroDesde, @FondoAhorroHasta, NULL, @FondoAhorroAusentismoAcumulado OUTPUT,  NULL
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, 	@Personal,  'FondoAhorro/AusentismoHoras', @FondoAhorroDesde, @FondoAhorroHasta, NULL, @FondoAhorroAusentismoHorasAcumulado OUTPUT, NULL
    SELECT @FondoAhorroPatronAcumulado = @FondoAhorroPatronAcumulado  + ISNULL(@FondoAhorroAusentismoHorasAcumulado, 0) + ISNULL(@FondoAhorroAusentismoAcumulado, 0)
    SELECT @FondoAhorroAcumulado       = @FondoAhorroAcumulado        + ISNULL(@FondoAhorroAusentismoHorasAcumulado, 0) + ISNULL(@FondoAhorroAusentismoAcumulado, 0)
    EXEC spNominaAgregarClaveInterna 			@Ok OUTPUT, @OkRef OUTPUT,'FondoAhorro/Liquidacion',         @Empresa, @Personal, @FondoAhorroAcumuladoDias, @FondoAhorroAcumulado  
    EXEC spNominaAgregarClaveInterna 			@Ok OUTPUT, @OkRef OUTPUT,'FondoAhorro/Liquidacion/Patron',  @Empresa, @Personal, @FondoAhorroPatronAcumuladoDias, @FondoAhorroPatronAcumulado  
    
    SELECT @FondoAhorroAnticipoAcumulado =  (isnull(@FondoAhorroAnticipoAcumulado,0) + isnull(@FondoAhorroPrestamoAcumulado,0)) 
    
    IF ISNULL(@FondoAhorroAnticipoPct,0.0) > 0.0
       EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/Liquidacion/Anticipo',@Empresa, @Personal, @FondoAhorroPatronAcumuladoDias, @FondoAhorroAnticipoAcumulado  
  
    SELECT @FondoAhorroIngresosTopados = dbo.fnMenor(@DiasTrabajadosImporte, @RepartirIngresoTope) * @RepartirIngresoFactor  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/IngresosTopados',     @Empresa, @Personal, @DiasTrabajados, @FondoAhorroIngresosTopados  
   
    SELECT @FondoAhorroDiasTrabajados = @DiasTrabajados * @RepartirDiasFactor  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/DiasTrabajados',      @Empresa, @Personal, @DiasTrabajados, @FondoAhorroDiasTrabajados  
  
    -- EXEC spCalculaAnticipoFondoAhorro @Empresa, @Personal, @FondoAhorro OUTPUT  

	--  IF ISNULL(@FondoAhorro,0.0)> 0.0
	--	  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/Anticipo', @Empresa, @Personal,@FondoAhorroAcumuladoDias, @FondoAhorro  
  
    SELECT @CalcImporte = @FondoAhorroIngresosTopados + @FondoAhorroDiasTrabajados  
	
	  IF ISNULL(@CalcImporte,0.0)> 0.0
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/Liquidacion/Interes', @Empresa, @Personal, @DiasTrabajados, @CalcImporte  
  END  
  
  
  -- LIQUIDACION CAJA AHORRO  
  IF @NomTipo = 'LIQUIDACION CAJA AHORRO'  
  BEGIN  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal,       'DiasTrabajados',           @RepartirDesde,   @RepartirHasta,   NULL, @DiasTrabajadosImporte OUTPUT, @DiasTrabajados OUTPUT  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal,       'CajaAhorro',               @CajaAhorroDesde, @CajaAhorroHasta, NULL, @CajaAhorroAcumulado OUTPUT, @CajaAhorroAcumuladoDias OUTPUT  
    EXEC spNominaAgregarClaveInterna         @Ok OUTPUT, @OkRef OUTPUT, 'CajaAhorro/Liquidacion',   @Empresa,         @Personal,               @CajaAhorroAcumuladoDias, @CajaAhorroAcumulado  
  
    SELECT @CajaAhorroIngresosTopados = dbo.fnMenor(@DiasTrabajadosImporte, @RepartirIngresoTope) * @RepartirIngresoFactor  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'CajaAhorro/IngresosTopados',   @Empresa, @Personal, @DiasTrabajados, @CajaAhorroIngresosTopados  
  
    SELECT @CajaAhorroDiasTrabajados = @DiasTrabajados * @RepartirDiasFactor  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'CajaAhorro/DiasTrabajados',   @Empresa, @Personal, @DiasTrabajados, @CajaAhorroDiasTrabajados  
  
    SELECT @CalcImporte = @CajaAhorroIngresosTopados + @CajaAhorroDiasTrabajados  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'CajaAhorro/Liquidacion/Interes',  @Empresa, @Personal, @DiasTrabajados, @CalcImporte  
  END  
    
  SELECT @SueldoMensual = @SueldoDiario * @DiasMes  
  SELECT @PrimerDiaMes = DATEADD(day, 1-DAY(@FechaA), @FechaA)
  if @NomTipo IN('FINIQUITO', 'liquidacion')  
    SELECT @PrimerDiaMes = DATEADD(day, 1-DAY(@FechaOrigen), @FechaOrigen)  

  SELECT @PrimerDiaMesAnterior = DATEADD(month, -1, @PrimerDiaMes)  
  SELECT @UltimoDiaMesAnterior = DATEADD(day, -1, @PrimerDiaMes)  
  SELECT @ISRVencimiento = DATEADD(day, 16, DATEADD(month, 1, @PrimerDiaMes))  
  SELECT @IMSSVencimiento = @ISRVencimiento, 
         @IMSSVencimientoBimestre = @ISRVencimiento, 
         @ImpuestoEstatalVencimiento = @ISRVencimiento  
  IF MONTH(@FechaA) % 2 <> 0 SELECT @IMSSVencimientoBimestre = DATEADD(month, 1, @IMSSVencimientoBimestre)  
 
  
  IF MONTH(@FechaA) <> MONTH(DATEADD(day, @DiasNaturalesOriginales, @FechaA))  
  BEGIN  
    IF MONTH(@FechaA)= 2 AND DAY(@FechaA) = 15 AND @PeriodoTipo = 'Quincenal' 
      SELECT @EsFinMes = 0   
    ELSE 
      SELECT @EsFinMes = 1    
  END  
  
  IF (MONTH(@PrimerDiaMes) % 2) = 0  
    SELECT  @PrimerDiaBimestre = DATEADD(month, -1, @PrimerDiaMes) 
  ELSE
    SELECT  @PrimerDiaBimestre =  @PrimerDiaMes 

  IF @EsFinMes = 1
  BEGIN 
    IF MONTH(@FechaA) % 2 = 0 
      SELECT @EsBimestre = 1, @PrimerDiaBimestre = DATEADD(month, -1, @PrimerDiaMes)  
    SELECT @PrimerDiaBimestre = Convert(DateTime, dbo.fnMayor(Convert(FLOAT,@PrimerDiaBimestre), Convert(FLOAT,@FechaAntiguedad)))  
    IF MONTH(@FechaA) % 2 = 0 SELECT @EsBimestre = 1
  END
  
  IF DAY(@FechaA) = 15 AND @PeriodoTipo = 'Quincenal' SELECT @EsFinMes = 0

  IF  @PeriodoTipo = 'CATORCENAL'
  BEGIN
    IF MONTH(@FechaA) <> MONTH(DATEADD(DAY,-3,DATEADD(day, @DiasNaturalesOriginales, @FechaA)))
      SELECT @EsFinMes = 1  
    ELSE  
      SELECT @EsFinMes = 0    
  END    

  IF @CfgAjusteMensualISR = 0   
    SELECT @EsFinMes = 0 
  
--  SELECT @DiasBimestre = DATEDIFF(day, @PrimerDiaBimestre, @FechaA) + 1
--    IF @PrimerDiaMes BETWEEN @FechaD AND @FechaA SELECT @EsInicioMes = 1
  
  SELECT @DiasBimestre = ISNULL(dbo.fnDiasBimestre(@FechaA),1)
  
  IF MONTH(@FechaA) % 2 = 0 
    SELECT @EsBimestre = 1
    
  
   SELECT @EsFinMes = 0
--SDI INICIO
  
  IF @NomTipo in ('Finiquito', 'Liquidacion') 
     SELECT @EsFinMes = 1

/*  EXEC spNominaMexicoCalcSdi @Empresa,@SucursalTrabajo, @Categoria, @Puesto, @Personal, @NomTipo, @EsSocio, @SDI, @DiasNaturales,@Incapacidades, @Faltas, @SMDF, 
		   @EsBimestre, @NomCalcSDI, @PrimerDiaBimestre, @FechaA, @DiasAguinaldoSiguienteSDI, @DiasAguinaldoSDI, @PrimaVacacionalPct, @DiasVacacionesSiguiente, @DiasAno,
		   @DiasVacaciones, @AntiguedadSDI, @DiasBimestre, @DiasBimestreTrabajados, @SueldoDiario, @SDIAnterior, @SDIVariableDiario, @SDINuevo, @FechaAntiguedad, @SDIBruto,
		   @FhiAntiguedad, @ISRLiquidacionGravable, @CfgFactorIntegracionAntiguedad, @FaltasAcumulado OUTPUT, @IncapacidadesAcumulado	OUTPUT, @FactorIntegracion	OUTPUT,
		   @IMSSObrero	OUTPUT,  @IMSSObreroCV	OUTPUT, @IMSSPatron	OUTPUT, @IMSSPatronMensual	OUTPUT, @IMSSPatronCV	OUTPUT, @IMSSPatronRetiro	OUTPUT,
		   @IMSSPatronInfonavit	OUTPUT, @IMSSBase	OUTPUT,  @IMSSBaseMes	OUTPUT, @IMSSBaseAcumulado	OUTPUT, @IMSSObreroSinCV	OUTPUT, @Ok	OUTPUT, @CfgFactorIntegracionTabla	OUTPUT, @OkRef	OUTPUT*/
		   
--FIN SDI

-- IMPUESTO ESTATAL INICIO

  IF @NomTipo='IMPUESTO ESTATAL'
  BEGIN
	  EXEC spNominaMexicoImpuestoEstatal @Empresa,@SucursalTrabajo,@Personal,@NomTipo, @DiasNaturales   ,@SMZ,@PrimerDiaBimestre, @PrimerDiaMes,
         @SucursalTrabajoEstado,@ImpuestoEstatalExento,@ImpuestoEstatalBase,@ImpuestoEstatal,@PersonalPercepciones,@FechaA,@FechaD,@ImpuestoEstatalPct,
         @ImpuestoEstatalGastoOperacionPct,@AcreedorImpuestoEstatal,@ImpuestoEstatalVencimiento,@CalcImporte,@Estacion,@ID,@Ok OUTPUT,@OkRef OUTPUT
	END

  IF @NomTipo='LIQUIDACION FONDO AHORRO'
  BEGIN  
    INSERT #Nomina (  
             Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)  
    SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)  
      FROM IncidenciaD d  
      JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'  
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'  
     WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL 

    INSERT #Nomina (  
            Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)  
    SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)  
      FROM IncidenciaD d  
      JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'  
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento <> 'Percepcion'  
     WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL 
  END
-- FIN IMPUESTO ESTATAL
-- SUELDO COMPLEMETARIO
  IF @NomTipo='SUELDO COMPLEMENTO'
	BEGIN
    SELECT @DiasNaturalesTrabajados = dbo.fnMayor(0, @DiasPeriodo - @Faltas )  
    SELECT @DiasTrabajados = @DiasPeriodo - @Faltas  
  	EXEC  spNominaSueldoComplemento @Empresa, @Personal, @NomTipo, @DiasNaturalesTrabajados, @DiasVacaciones, @EsAniversario, @Faltas, @Antiguedad,
  	      @OtorgarPrimaVacacionalAniversario, @OtorgarDiasVacacionesAniversario, @TipoCambio, @RedondeoMonetarios, 
  	      @FechaA, @FechaD,  @SueldoDiarioComplemento,@Mov, @Ok, @OkRef 
	END
-- FIN SUELDO COMPLEMENTARIO
-- AGUINALDO COMPLEMETARIO
-- SELECT '@NomTipo'=@NomTipo

  IF @NomTipo='AGUINALDOCOMPLEMENTO'
	BEGIN
    IF @FechaAntiguedad < @PrimerDiaAno    
	    SELECT @DiasAguinaldoProporcion = DATEDIFF(DAY,@PrimerDiaAno,@UltimoDiaAno) +1
    ELSE
	    SELECT @DiasAguinaldoProporcion = DATEDIFF(DAY, @FechaAntiguedad,@UltimoDiaAno)+1
    SELECT @DiasAguinaldoProporcion = isnull((ISNULL(@DiasAguinaldoProporcion,365) / 365.0) * (@DiasAguinaldo-ISNULL(@FaltasAcumulado,0)),0)
    --SELECT @SueldoDiarioComplemento = ISNULL(SueldoDiarioComplemento,0.0) FROM Personal WHERE Personal.Personal = @Personal
    SELECT @Aguinaldo = (@SueldoDiarioComplemento * @DiasAguinaldoProporcion) * 0.90
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Aguinaldo/Complemento', @Empresa, @Personal, @DiasAguinaldoProporcion, @Aguinaldo  
  END
-- FIN SUELDO COMPLEMENTARIO


  IF @NomTipo IN ('SDI', 'NORMAL', 'AJUSTE', 'FINIQUITO', 'LIQUIDACION', 'H.ASIMILABLE', 'PRIMA VACACIONAL','Prestamo Fondo Ahorr','Liquidacion Fondo Ahorro','Liquidacion Caja Ahorro','Aguinaldo')  
  BEGIN  
      -- Horas Extras (Explosion Automatica)  
    IF @NomTipo NOT IN ('LIQUIDACION FONDO AHORRO')  
      EXEC spNominaAgregarHorasExtras @NomTipo, @Empresa, @Personal, @FechaD, @FechaA, @IncidenciaD, @IncidenciaA, @TipoCambio, @Ok OUTPUT, @OkRef OUTPUT  
     -- Incidencias Manuales  
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') 
    BEGIN  
      INSERT #Nomina (  
             Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)  
      SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)  
        FROM IncidenciaD d  
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal 
         AND i.Estatus = 'PENDIENTE'  
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'  
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL  

      INSERT #Nomina (  
             Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)  
      SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)  
        FROM IncidenciaD d  
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal 
         AND i.Estatus = 'PENDIENTE'  
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto  AND nc.Movimiento <> 'Percepcion'  
       WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL 
    END ELSE  
      INSERT #Nomina (  
             Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Referencia,   Fecha,             Cuenta,     Vencimiento,   Cantidad,   Importe)  
      SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, i.Referencia, d.FechaAplicacion, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)  
        FROM IncidenciaD d  
        JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'  
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto 
         AND( RequiereDiasTrabajados  = 0  OR ( RequiereDiasTrabajados  = 1 AND @NomTipo ='AJUSTE' AND nc.Movimiento <> 'Deduccion'))  
         WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL  AND d.FechaAplicacion <= @IncidenciaA  

--spNominaGenerar 101, 1214, '04/14/2008 00:00:00', '04/27/2008 00:00:00', 'Catorcenal', '04/08/2008 00:00:00'
---se borran todos los conceptos que no aplican para este MOV

    DELETE #Nomina    
      FROM #Nomina n    
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto    
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)    
       AND n.Personal = @Personal   and exists(select * from MovEspecificoNomina where MovEspecificoNomina.nominaconcepto= n.NominaConcepto)


  ---se borran todos los conceptos que no aplican para este MOV

    EXEC xpNominaCalcIncidencia @NomTipo, @Empresa, @Personal, @FechaD, @FechaA, @IncidenciaD, @IncidenciaA, @TipoCambio, @Ok OUTPUT, @OkRef OUTPUT  

    -- Faltas   
    SELECT @Faltas = ISNULL(SUM(d.Cantidad), 0), @FaltasImporte = ISNULL(SUM(d.Importe), 0)  
      FROM #Nomina d  
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Faltas'  
     WHERE d.Personal = @Personal  
-- SELECT *FROM NominaConcepto WHERE  ISNULL(Especial,'') = 'Faltas' 
-- CALCULA AYUDA FAMILIAR  
    IF @NomTipo IN ('NORMAL', 'AJUSTE', 'FINIQUITO', 'LIQUIDACION')  
    BEGIN  
      EXEC spCalculaAyudaFamiliar @Empresa, @Personal, @AyudaFamiliar OUTPUT  

      IF ISNULL(@AyudaFamiliar,0) <>0  
      BEGIN
        IF ISNULL(@AyudaFamiliarFactorAusentismo,'N') ='S'
          SELECT  @AyudaFamiliar= @AyudaFamiliar / @DiasPeriodo * (@DiasPeriodo -(ISNULL(@Faltas,0) * @FactorAusentismo))  

        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'AyudaFamiliar', @Empresa, @Personal,@DiasPeriodo, @AyudaFamiliar  
      END    
    END  
   -- Sueldo  
    IF @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION','H.ASIMILABLE','Prima Vacacional')  
    BEGIN  
      EXEC spNominaClaveInternaEstaNomina @Personal, 'Vacaciones', @VacacionesTomadas OUTPUT  
      SELECT @VacacionesTomadas = isnull(@VacacionesTomadas,0)  
      SELECT @DiasPeriodo = @DiasPeriodo -  @VacacionesTomadas  
      SELECT @SueldoPeriodo = @SueldoDiario * @DiasPeriodo  

      SELECT @Plaza = Plaza from personal where personal = @Personal
      IF @mov = 'presupuesto'
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Sueldo', @Empresa, @Personal, @DiasPeriodo, @SueldoPeriodo , @referencia =@Plaza 
      ELSE
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Sueldo', @Empresa, @Personal, @DiasPeriodo, @SueldoPeriodo 
        
      EXEC spCalculaValesDespensa @Empresa, @Personal, @ValesDespensa OUTPUT  
      IF ISNULL(@ValesDespensa,0) <> 0  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ValesDespensa', @Empresa, @Personal, @DiasPeriodo, @ValesDespensa        
      EXEC spCalculaCuotaSindical  @Empresa, @Personal, @FechaD, @FechaA, @Mov, @CuotaSindical OUTPUT        
      IF  ISNULL(@CuotaSindical ,0)<>0.0  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'CuotaSindical', @Empresa, @Personal, @DiasPeriodo, @CuotaSindical  
      SELECT @DiasPeriodo = @DiasPeriodo +  @VacacionesTomadas  
    END   
    
  
   -- Incapacidades  
    SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)  
      FROM #Nomina d  
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'  
     WHERE d.Personal = @Personal  
  
    WHILE @Incapacidades > @DiasPeriodo AND @Incapacidades > 0 AND @PersonalEstatus='ALTA'  
    BEGIN  
      SELECT @MaxID = ISNULL(MAX (IncidenciaID), 0), @MaxRID= ISNULL(MAX (IncidenciaRID), 0)  
        FROM #Nomina d  
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'  
       WHERE d.Personal = @Personal  
  
      DELETE #Nomina WHERE IncidenciaID = @Maxid AND IncidenciaRID=@MaxRid  
      SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)  
        FROM #Nomina d  
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'  
       WHERE d.Personal = @Personal  
    END  

    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Incapacidades', @FechaD, @FechaA, NULL, NULL, @IncapacidadesD OUTPUT  
  
    WHILE (@Incapacidades+@IncapacidadesD) > @DiasPeriodo and (@Incapacidades+@IncapacidadesD) > 0  and (@IncapacidadesD <= @DiasPeriodo) AND @PersonalEstatus='ALTA'  
    BEGIN  
      SELECT @MaxID = ISNULL(MAX (IncidenciaID), 0), @MaxRID= ISNULL(MAX (IncidenciaRID), 0)  
        FROM #Nomina d  
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'  
       WHERE d.Personal = @Personal   
      DELETE #Nomina WHERE IncidenciaID = @Maxid AND IncidenciaRID=@MaxRid  
      SELECT @Incapacidades = ISNULL(SUM(d.Cantidad), 0), @IncapacidadesImporte = ISNULL(SUM(d.Importe), 0)  
        FROM #Nomina d  
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND ISNULL(nc.Especial,'') = 'Incapacidades'  
       WHERE d.Personal = @Personal  
    END  

    --IF @NomTipo<>'SUELDO COMPLEMENTO'
	 -- BEGIN
	  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Faltas', @Empresa, @Personal, @Faltas, @FaltasImporte  
	 -- END  
	  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Incapacidades', @Empresa, @Personal, @Incapacidades, @IncapacidadesImporte  
	  
	  
	  IF @SubsidioProporcionalFalta = 1
             SELECT @DiasPeriodoSubsidio = (@DiasPeriodo - @Incapacidades) - (@Faltas * ( @DiasPeriodo/@DiasHabilesPeriodo ))  
    ELSE  
      SELECT @DiasPeriodoSubsidio = (@DiasPeriodo - @Incapacidades) - @Faltas  
    
    SELECT @SueldoVariable = ISNULL(SUM(d.Importe), 0)  
      FROM #Nomina d  
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.SueldoVariable = 1  
     WHERE d.Personal = @Personal  
  
    IF @NomTipo = 'AJUSTE'  
    BEGIN  
      EXEC spNominaClaveInternaEstaNomina @Personal, 'Sueldo', @DiasNaturales OUTPUT  
      SELECT @DiasPeriodo = @DiasNaturales  
    END  
  
    EXEC spNominaClaveInternaEstaNomina @Personal, 'Vacaciones', @VacacionesTomadas OUTPUT  
    SELECT @Calc = -@VacacionesTomadas  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @Calc  
  
    SELECT @DiasNaturalesTrabajados = dbo.fnMayor(0, @DiasNaturales - @Faltas - @Incapacidades)  
    SELECT @DiasTrabajados = @DiasPeriodo - @Incapacidades - @Faltas  
--SELECT @DiasPeriodo , @Incapacidades , @Faltas
    IF @NomTipo NOT IN ('AJUSTE','LIQUIDACION FONDO AHORRO') AND @DiasTrabajados<0.0 SELECT @DiasTrabajados = 0.0  
    SELECT @DiasTrabajadosImporte = (@SueldoDiario*@DiasPeriodo) + @SueldoVariable - @FaltasImporte - @IncapacidadesImporte  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasPeriodo',   @Empresa, @Personal, @DiasPeriodo  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasNaturales',   @Empresa, @Personal, @DiasNaturales  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasTrabajados',   @Empresa, @Personal, @DiasTrabajados, @DiasTrabajadosImporte  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasTrabajadosSubsidio',   @Empresa, @Personal, @DiasPeriodoSubsidio, 0  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/SDI',   @Empresa, @Personal, @Importe = @SDI  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/SueldoDiario',  @Empresa, @Personal, @Importe = @SueldoDiario  
    
    IF @DiasTrabajados > 0  
    BEGIN  
     IF @NomTipo NOT IN ('FINIQUITO', 'LIQUIDACION', 'AJUSTE', 'SDI', 'LIQUIDACION FONDO AHORRO')  
     BEGIN  
       INSERT #Nomina (  
              Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Referencia,   Cuenta,     Vencimiento,   Cantidad,   Importe)  
       SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, i.Referencia, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)  
         FROM IncidenciaD d  
         JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'  
         JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND RequiereDiasTrabajados = 1   
        WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion <= @IncidenciaA   
      END  
   
     IF @NomTipo  IN ('AJUSTE')  
       INSERT #Nomina (  
              Personal,  IncidenciaID, IncidenciaRID, NominaConcepto,   Referencia,   Cuenta,     Vencimiento,   Cantidad,   Importe)  
       SELECT @Personal, d.ID,         d.RID,         d.NominaConcepto, i.Referencia, i.Acreedor, i.Vencimiento, d.Cantidad, ROUND(d.Saldo*(i.TipoCambio/NULLIF(@TipoCambio, 0.0)), @RedondeoMonetarios)  
         FROM IncidenciaD d  
         JOIN Incidencia i ON i.ID = d.ID AND i.Empresa = @Empresa AND i.Personal = @Personal AND i.Estatus = 'PENDIENTE'  
         JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND  RequiereDiasTrabajados  = 1 AND nc.Movimiento = 'Deduccion'  
        WHERE NULLIF(d.Saldo, 0.0) IS NOT NULL AND d.FechaAplicacion <= @IncidenciaA   
   
    END  
    
    --- ojo le arregle por la prima dominical no aplica para los nuevos  
    IF @CfgPrimaDominicalAuto = 1 AND (@DescansaDomingos = 1 OR @LaboraDomingos = 1) AND @NomTipo = 'NORMAL'  
    BEGIN  
      IF @FechaAlta <= @IncidenciaA  
      BEGIN  
        EXEC spNominaDomingosLaborados @Empresa, @Personal, @FechaD, @FechaA, @IncidenciaD, @IncidenciaA, @DomingosLaborados OUTPUT  
        SELECT @PrimaDominical = Round(@DomingosLaborados * Round((@SueldoDiario * Round( (@PrimaDominicalPct/100.0) ,2)),2),2)  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaDominical', @Empresa, @Personal, @DomingosLaborados, @PrimaDominical  
      END  
    END 
     
    IF @NomTipo in('NORMAL', 'PRIMA VACACIONAL','SDI')
    BEGIN ---- 0 -1
      IF @OtorgarDiasVacacionesAniversario = 0 AND @OtorgarPrimaVacacionalAniversario = 0  
      BEGIN  
        EXEC spNominaClaveInternaEstaNomina @Personal, 'Vacaciones', @DiasVacaciones OUTPUT  
        IF @DiasVacaciones > 0  
        BEGIN  
          SELECT @PrimaVacacionalPct = CASE WHEN ISNUMERIC(Valor)=1 THEN   
                 CONVERT(tinyint,Valor)  ELSE NULL END  
            FROM PersonalPropValor  
           WHERE Cuenta = @Empresa  
             AND Rama = 'EMP'  
             AND Propiedad = '% Prima Vacacional'  
          IF @PrimaVacacionalPct IS NULL  
           EXEC spTablaNum 'PRIMA VACACIONAL', @Antiguedad, @PrimaVacacionalPct OUTPUT  
        END  
        IF @OtorgarDiasVacacionesAniversario = 0
          IF  @OtorgarPrimaVacacionalAguinaldo = 1 AND ISNULL(@DiasVacaciones,0) = 0 
          BEGIN 
            IF ISNULL(@DiasVacaciones,0) = 0 
              EXEC spTablaNum 'VACACIONES', @Antiguedad, @DiasVacaciones OUTPUT  
  		      IF YEAR(@FechaA) = YEAR(@FechaAntiguedad)
  		      BEGIN
              SELECT @DiasVacaciones = 0.0 + @DiasVacaciones * (DATEDIFF(day, @PrimerDiaAno1, @UltimoDiaAno)+1.0)/@DiasAno
              SELECT @DiasAguinaldoSiguienteSDI = 0.0+ @DiasAguinaldoSiguienteSDI* (( DATEDIFF(day, @FechaAntiguedad, @UltimoDiaAno)+1.0)/ (DATEDIFF(day, @PrimerDiaAno1, @UltimoDiaAno)+1.0))
              SELECT @DiasAguinaldoSDI = @DiasAguinaldoSDI * (( DATEDIFF(day, @FechaAntiguedad, @UltimoDiaAno)+1.0) / (DATEDIFF(day, @PrimerDiaAno1, @UltimoDiaAno)+1.0))
            END
          END   
        SELECT @PrimaVacacional = @SueldoDiario * @DiasVacaciones * (@PrimaVacacionalPct / 100.0)  
      END       
      IF (@OtorgarPrimaVacacionalAguinaldo = 1 AND @NomTipo='PRIMA VACACIONAL') 
--     OR (@NomTipo='Normal' AND  @OtorgarPrimaVacacionalAguinaldo = 0 )
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaVacacional', @Empresa, @Personal, @DiasVacaciones, @PrimaVacacional  
    END  

    EXEC spNominaMexicoCalcSdi @Empresa,@SucursalTrabajo, @Categoria, @Puesto, @Personal, @NomTipo, @EsSocio, @SDI, @DiasNaturales,@Incapacidades, @Faltas, @SMDF, 
		   @EsBimestre, @NomCalcSDI, @PrimerDiaBimestre, @FechaA, @DiasAguinaldoSiguienteSDI, @DiasAguinaldoSDI, @PrimaVacacionalPct, @DiasVacacionesSiguiente, @DiasAno,
		   @DiasVacaciones, @AntiguedadSDI, @DiasBimestre, @DiasBimestreTrabajados, @SueldoDiario, @SDIAnterior, @SDIVariableDiario, @SDINuevo, @FechaAntiguedad, @SDIBruto,
		   @FhiAntiguedad, @ISRLiquidacionGravable, @CfgFactorIntegracionAntiguedad, @FaltasAcumulado OUTPUT, @IncapacidadesAcumulado	OUTPUT, @FactorIntegracion	OUTPUT,
		   @IMSSObrero	OUTPUT,  @IMSSObreroCV	OUTPUT, @IMSSPatron	OUTPUT, @IMSSPatronMensual	OUTPUT, @IMSSPatronCV	OUTPUT, @IMSSPatronRetiro	OUTPUT,
		   @IMSSPatronInfonavit	OUTPUT, @IMSSBase	OUTPUT,  @IMSSBaseMes	OUTPUT, @IMSSBaseAcumulado	OUTPUT, @IMSSObreroSinCV	OUTPUT, @Ok	OUTPUT, @CfgFactorIntegracionTabla	OUTPUT, @OkRef	OUTPUT
--FIN SDI
    
    IF @NomTipo = 'NORMAL' AND @EsAniversario = 1  
    BEGIN  

      IF @OtorgarDiasVacacionesAniversario = 1  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @DiasVacaciones  

      IF @OtorgarPrimaVacacionalAniversario = 1  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaVacacional', @Empresa, @Personal, @DiasVacaciones, @PrimaVacacional  

    END ELSE  
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION')  
    BEGIN  
      IF @OtorgarPrimaVacacionalAguinaldo = 0 
      BEGIN 
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'DiasVacaciones', @FechaAntiguedad, @FechaA, NULL, NULL, @DiasVacacionesAcumulado OUTPUT  
        SELECT @Calc = -@DiasVacacionesAcumulado  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @Calc  
        SELECT @Vacaciones = @SueldoDiario * (@DiasVacacionesProporcion + @DiasVacacionesAcumulado)  
        Select @DiasVacacionesProporcion= @DiasVacacionesProporcion + @DiasVacacionesAcumulado  
         EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Vacaciones', @Empresa, @Personal, @DiasVacacionesProporcion, @Vacaciones  
        SELECT @DiasVacacionesProporcion =  @DiasVacacionesProporcion - @DiasVacacionesAcumulado   
-- SELECT @PrimaVacacionalProporcion = @SueldoDiario * @DiasVacacionesProporcion * (@PrimaVacacionalPct/100.0)  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaVacacional', @Empresa, @Personal, @DiasVacacionesProporcion, @PrimaVacacionalProporcion  
      END ELSE 
      BEGIN
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'DiasVacaciones', @FechaAntiguedad, @FechaA, NULL, NULL, @DiasVacacionesAcumulado OUTPUT  

        SELECT @Calc = -@DiasVacacionesAcumulado  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'DiasVacaciones', @Empresa, @Personal, @Calc  

        SELECT @Vacaciones = @SueldoDiario * (@DiasVacacionesProporcion + @DiasVacacionesAcumulado)  
        SELECT @DiasVacacionesProporcion= @DiasVacacionesProporcion + @DiasVacacionesAcumulado  
EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Vacaciones', @Empresa, @Personal, @DiasVacacionesProporcion, @Vacaciones  

-- spNominaGenerar 100, 1677, '05/12/2008 00:00:00', '05/25/2008 00:00:00', 'Catorcenal', '05/19/2008 00:00:00'
-- select * from cfgnominaconcepto where nominaconcepto ='101'


        SELECT @DiasVacacionesProporcion =  @DiasVacacionesProporcion - @DiasVacacionesAcumulado   
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaVacacional', @Empresa, @Personal, @DiasVacacionesProporcion, @PrimaVacacionalProporcion  
      END  
    END  
  
    IF @TieneValesDespensa = 1  AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')  --AND @EsFinMes = 1 QUE SEA UN APROPIEDAD
    BEGIN  
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Faltas', @PrimerDiaMes, @FechaA, NULL, NULL, @FaltasAcumulado OUTPUT  
      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Incapacidades', @PrimerDiaMes, @FechaA, NULL, NULL, @IncapacidadesAcumulado OUTPUT  
      SELECT @DiasMesTrabajados = dbo.fnMayor(0, @DiasMes - @Faltas - @FaltasAcumulado - @Incapacidades - @IncapacidadesAcumulado)  
      SELECT @ValesDespensaImporte = @ValesDespensaImporte + (@SueldoDiario*@DiasMesTrabajados*(@ValesDespensaPct/100.0))  
      IF ISNULL(@ValesDespensaImporte,0) <>0  
      BEGIN
         IF ISNULL(@ValesDespensaFactorAusentismo,'NO') = 'S'
            SELECT @ValesDespensaImporte = @ValesDespensaImporte / @DiasPeriodo * ( @DiasPeriodo -(@Faltas * @FactorAusentismo))
         IF @NomTipo IN ('NORMAL')
           EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ValesDespensa', @Empresa, @Personal, @Importe = @ValesDespensaImporte  

      END
    END  
    IF @PremioPuntualidadPct > 0.0 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')  
    BEGIN  
      SELECT @CalcImporte = @DiasTrabajados*@SueldoDiario*(@PremioPuntualidadPct/100.0)  
      IF @Jornada in('Horario Completo') 
        SELECT @CalcImporte =@CalcImporte 
      IF @Contrato in ('TIEMPO DETERMINADO','TIEMPO INDETERMINADO') 
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PremioPuntualidad', @Empresa, @Personal, @DiasTrabajados, @CalcImporte  
    END  
-- INI Ayuda transporte  ----------------------------------------------------------------
    IF @AyudaTransportePct > 0.0 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')    
    BEGIN    
        SELECT @DiasTrabajados = @DiasTrabajados + @VacacionesTomadas
        SELECT @CalcImporte = @DiasTrabajados*@SueldoDiario*(@AyudaTransportePct/100.0)    
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'AyudaTransporte', @Empresa, @Personal, @DiasTrabajados, @CalcImporte    
        SELECT @DiasTrabajados = @DiasTrabajados - @VacacionesTomadas
    END    
-- FIN Ayuda transporte  ----------------------------------------------------------------
    IF @PremioAsistenciaPct > 0.0 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')  
    BEGIN  
      SELECT @CalcImporte = @DiasTrabajados*@SueldoDiario*(@PremioAsistenciaPct/100.0)  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PremioAsistencia', @Empresa, @Personal, @DiasTrabajados, @CalcImporte  
    END  
  
    IF @NomTipo IN ('NORMAL')  
    BEGIN  
      IF NULLIF(@CajaAhorro, 0.0) IS NOT NULL AND ((@FechaD BETWEEN @CajaAhorroDesde AND @CajaAhorroHasta) OR (@FechaA BETWEEN @CajaAhorroDesde AND @CajaAhorroHasta))  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'CajaAhorro', @Empresa, @Personal, @Importe = @CajaAhorro  
    END  
  
    IF @NomTipo IN ('NORMAL', 'AJUSTE') AND ABS(@DiasTrabajados) > 0  

    BEGIN  
      SELECT @FondoAhorro1 = ISNULL(@FondoAhorro, 0.0) + ((@FondoAhorroPct/100)*@SueldoDiario*@DiasPeriodo+1)

      IF  @FondoAhorro1 < (@SMZ * 10.0 * @DiasPeriodoEstandar * 0.13)
      BEGIN
        IF @FondoAhorroFactorAusentismo = 'S' 
             SELECT @FondoAhorro = ISNULL(@FondoAhorro, 0.0) + ((@FondoAhorroPct/100)* @SueldoDiario * (@DiasPeriodo - (@Faltas * @FactorAusentismo)) ) 
        ELSE   
          SELECT @FondoAhorro = ISNULL(@FondoAhorro, 0.0) + ((@FondoAhorroPct/100)* @SueldoDiario * @DiasPeriodo )
        
      END ELSE 
        IF @FondoAhorroFactorAusentismo = 'S'   
          SELECT @FondoAhorro =  (@SMZ * 10.0 * @DiasPeriodoEstandar * 0.13 ) / @Diasperiodo *(@DiasPeriodo - (@Faltas * @FactorAusentismo)) 
        ELSE
          SELECT @FondoAhorro =  (@SMZ * 10.0 * @DiasPeriodoEstandar * 0.13 ) / @Diasperiodo *(@DiasPeriodo /*- (@Faltas)*/) 
        
      IF NULLIF(@FondoAhorro, 0.0) IS NOT NULL AND ((@FechaD BETWEEN @FondoAhorroDesde AND @FondoAhorroHasta) OR (@FechaA BETWEEN @FondoAhorroDesde AND @FondoAhorroHasta))  
      BEGIN  
        IF ISNULL(NULLIF(@TopeFondoAhorro, 0), 0) > 0  
          IF @FondoAhorro > @TopeFondoAhorro 
            SELECT @FondoAhorro = @TopeFondoAhorro

        IF RTRIM(@FondoAhorroTipoContrato) <> '' 
          IF @Contrato <> @FondoAhorroTipoContrato
            SELECT @FondoAhorro = 0
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro',      @Empresa, @Personal, @DiasPeriodo, @FondoAhorro  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/Patron',          @Empresa, @Personal, @DiasPeriodo, @Importe = @FondoAhorro  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/PatronPercepcion', @Empresa, @Personal, @DiasPeriodo, @Importe = @FondoAhorro  
        SELECT @CalcImporte = (@FondoAhorro*2)*(@FondoAhorroAnticipoPct/100.0)  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'FondoAhorro/Anticipo', @Empresa, @Personal, @Importe = @CalcImporte  
--select @diastrabajados,@FondoAhorro  
--spNominaGenerar 14504, 877, '03/03/2008 00:00:00', '03/16/2008 00:00:00', 'Catorcenal', '03/11/2008 00:00:00'
      END  
    END  
 
    IF @CfgSubsidioIncapacidadEG = 1 AND @NomTipo IN ('NORMAL', 'FINIQUITO', 'LIQUIDACION')  
      IF @Contrato='PERMANENTE'  
        EXEC spNominaSubsidioIncapacidadEG @Empresa, @Personal, @SueldoDiario, @SDI, @Ok OUTPUT, @OkRef OUTPUT  
  END  
     
  IF @NomTipo = 'FINIQUITO' AND @AntiguedadFlotante >= 15.0  
  BEGIN  
    SELECT @PrimaAntiguedad = dbo.fnMenor(@SueldoDiario, @SMZ * 2.0) * 12.0 * @AntiguedadFlotante  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaAntiguedad/15Anos', @Empresa, @Personal, @AntiguedadFlotante, @PrimaAntiguedad  
  END  
   
  IF @NomTipo = 'LIQUIDACION'  
  BEGIN   
    SELECT @Indemnizacion3Meses = @SDI * 90  
    IF @IndemnizacionPct = 100.0  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Indemnizacion/3Meses', @Empresa, @Personal, 90, @Indemnizacion3Meses  
    SELECT @Indemnizacion20Dias = @SDI * 20 * @AntiguedadFlotante  
      
    IF @IndemnizacionPct = 100.0  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Indemnizacion/20Dias', @Empresa, @Personal, @AntiguedadFlotante, @Indemnizacion20Dias  
    SELECT @PrimaAntiguedad = dbo.fnMenor(@SueldoDiario, @SMZ * 2.0) * 12.0 * @AntiguedadFlotante  
      
    IF @IndemnizacionPct = 100.0  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PrimaAntiguedad', @Empresa, @Personal, @AntiguedadFlotante, @PrimaAntiguedad  
    SELECT @Indemnizacion = (@Indemnizacion3Meses + @Indemnizacion20Dias + @PrimaAntiguedad) * (@IndemnizacionPct/100.0)  
  
    IF @IndemnizacionPct <> 100.0  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Indemnizacion', @Empresa, @Personal, @AntiguedadFlotante, @Indemnizacion  
  END  


  
  
  DELETE #Nomina    
      FROM #Nomina n    
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto    
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)    
       AND n.Personal = @Personal   and exists(select * from MovEspecificoNomina where MovEspecificoNomina.nominaconcepto= n.NominaConcepto)
  

  IF @NomTipo NOT IN ('AJUSTE ANUAL','SDI','IMPUESTO ESTATAL','LIQUIDACION FONDO AHORRO','SUELDO COMPLEMENTO')
  BEGIN  
    EXEC spNominaGrava @Empresa, @Sucursal, @ID, @Personal, @SucursalTrabajoEstado, @FechaD, @FechaA, @Moneda, @TipoCambio,  
                       @SMZ, @SMZTopeHorasDobles, @SDI, @DiasPeriodo, @DiasMes, @DiasAno, @Antiguedad, @IndemnizacionTope,   
                       @ISRBase OUTPUT, @IMSSBase OUTPUT, @ImpuestoEstatalBase OUTPUT, @CedularBase OUTPUT,  
                       @Ok OUTPUT, @OkRef OUTPUT  
--5SELECT @ISRBase,@IndemnizacionTope
-- spNominaGenerar 1, 380, '16/03/2008 00:00:00', '31/03/2008 00:00:00', 'Quincenal', '25/03/2008 00:00:00'

    SELECT @PercepcionBruta = 0.0  
    SELECT @PercepcionBruta = @PercepcionBruta + ISNULL(SUM(d.Importe), 0.0)  
      FROM #Nomina d  
      JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'  
     WHERE d.Personal = @Personal  
--select @PercepcionBruta

    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Base',   @Empresa, @Personal, @Importe = @ISRBase  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/Base',   @Empresa, @Personal, @Importe = @IMSSBase  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ImpuestoEstatal/Base', @Empresa, @Personal, @Importe = @ImpuestoEstatalBase  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Cedular/Base',  @Empresa, @Personal, @Importe = @CedularBase  
    SELECT @EsIsrReglamento = 0
    SELECT @EsIsrReglamento = isnull(EsIsrReglamento,0) FROM MovTipo WHERE  Modulo = 'NOM' AND Mov = @Mov

    IF  (@CfgAjusteMensualISR = 1 AND @EsFinMes = 1) 
        OR @NomTipo IN ('FINIQUITO', 'LIQUIDACION', 'AGUINALDO', 'PTU', 'Prima Vacacional')  
        OR (@EsIsrReglamento = 1)
    BEGIN  
      IF (@NomTipo = 'AGUINALDO' AND @CfgISRReglamentoAguinaldo = 1) 
         OR (@NomTipo = 'PTU' AND @CfgISRReglamentoPTU = 1)  
         OR (@NomTipo = 'Prima Vacacional' AND @CfgISRReglamentoAguinaldo = 1)  
         OR (@EsIsrReglamento = 1)
      BEGIN  
        SELECT @SueldoMensualReglamento=0  
        if @MOV='BONO'
          SELECT @ISRReglamentoBase = @ISRBase / 90.0 * 30.4  
        ELSE 
          SELECT @ISRReglamentoBase = @ISRBase / 365.0 * 30.4  
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR', @PrimerDiaMesAnterior, @UltimoDiaMesAnterior, NULL, @SueldoMensualReglamento OUTPUT, NULL  
        SELECT @SueldoMensualReglamento = @SueldoMensual+ @ISRReglamentoBase  
        EXEC spTablaImpuesto 'ISR',     NULL, 'MENSUAL', @SueldoMensual, @ISRSueldoMensual OUTPUT
        SELECT @ISRSueldoMensual = @ISRSueldoMensual 
        EXEC spTablaImpuesto 'ISR',     NULL, 'MENSUAL', @SueldoMensualReglamento, @ISRSueldoMensualReglamento OUTPUT  
        SELECT @ISRReglamentoFactor = (@ISRSueldoMensualReglamento - @ISRSueldoMensual) / NULLIF(@ISRReglamentoBase, 0.0)  
        SELECT @ISR = @ISRBase * @ISRReglamentoFactor  
      END ELSE  
      BEGIN  
        IF @NomTipo IN ('AGUINALDO','PTU','Prima Vacacional')
        BEGIN
          EXEC spTablaImpuesto 'ISR',     NULL, 'MENSUAL', @ISRBase, @ISRSueldoMensual OUTPUT  
          SELECT @ISRSueldoMensual = @ISRSueldoMensual --- (@SubsidoSueldoMensual*@ISRSubsidioPct/100.0)  
          EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR', @Empresa, @Personal, @Importe = @ISRSueldoMensual, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
        END
        IF @NomTipo NOT IN ('AGUINALDO','PTU','Prima Vacacional')
        BEGIN
          IF @EsFinMEs = 0 
          BEGIN 
            EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base',             @PrimerDiaMes, @FechaA, NULL, @ISRBaseAcumulado OUTPUT, NULL  
            EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR',                  @PrimerDiaMes, @FechaA, NULL, @ISRAcumulado OUTPUT, NULL  
	        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/SubsidioAlEmpleo', @PrimerDiaMes, @FechaA, NULL, @ISRSubsidioAlEmpleoAcumulado OUTPUT, NULL  
	      END ELSE  
	      BEGIN
	        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base',             @PrimerDiaMes, @UltimoDiaMes, NULL, @ISRBaseAcumulado OUTPUT, NULL  
            EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR',                  @PrimerDiaMes, @UltimoDiaMes, NULL, @ISRAcumulado OUTPUT, NULL  
	        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/SubsidioAlEmpleo', @PrimerDiaMes, @UltimoDiaMes, NULL, @ISRSubsidioAlEmpleoAcumulado OUTPUT, NULL  
	      END  
          SELECT @DiasTrabajadosSubsidioAcumulado = ISNULL(@DiasTrabajadosSubsidioAcumulado, 0)   
          SELECT @ISRBaseAcumulado = ISNULL(@ISRBaseAcumulado, 0)   
          SELECT @ISRBaseMes = @ISRBaseAcumulado + @ISRBase  
          IF  @NomTipo = 'H.ASIMILABLE' -- ojo que aplica aqui  
          BEGIN   
            EXEC spNominaISRSubsidioAlEmpleoProporcional	@DiasPeriodo,	@DiasPeriodoSubsidio, @DiasMes ,@ISRBaseMes, @ISR	OUTPUT,	@ISRSubsidioAlEmpleoTabla		OUTPUT,	@ISRBruto	OUTPUT
            SELECT @ISR = @ISRBruto 
            SELECT @ISR = ROUND(@ISR,2) --, @ISRSubsidioAlEmpleo =ROUND(@ISRSubsidioAlEmpleo,2), @ISRBruto =ROUND(@ISRBruto,2)  --, @ISRSubsidio = ROUND(@ISRSubsidio,2)
            SELECT @ISR = @ISR - @ISRAcumulado , @ISRCreditoAlSalarioTabla = 0 --, @ISRSubsidio = @ISRSubsidio - @ISRSubsidioAcumulado  
          END ELSE  
          BEGIN
            EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'DiasTrabajadosSubsidio', @PrimerDiaMes, @FechaA, NULL, @DiasTrabajadosImporteSubsidio OUTPUT, @DiasTrabajadosSubsidioAcumulado OUTPUT
            SELECT @DiasTrabajadosSubsidioAcumulado = ISNULL(@DiasTrabajadosSubsidioAcumulado, 0)   
            SELECT @ISRBaseAcumulado = @ISRBaseAcumulado + @ISRBase
            SELECT @DiasTrabajadosSubsidioAcumulado =  isnull(@DiasPeriodoSubsidio,0) +  isnull(@DiasTrabajadosSubsidioAcumulado ,0)
-- spNominaGenerar 100, 1724, '05/26/2008 00:00:00', '06/08/2008 00:00:00', 'Catorcenal', '05/20/2008 00:00:00'

            EXEC spNominaISRSubsidioAlEmpleoProporcional	@DIASPERIODOMES,	@DiasTrabajadosSubsidioAcumulado, @DiasMes,@ISRBaseAcumulado, @ISR	OUTPUT,	@ISRSubsidioAlEmpleoTabla	OUTPUT,	@ISRBruto	OUTPUT, @esfinmes

            SELECT @ISR=ROUND(@ISR,2),@ISRSubsidioAlEmpleoTabla =ROUND(@ISRSubsidioAlEmpleoTabla,2), @ISRBruto =ROUND(@ISRBruto,2) -- , @ISRSubsidio = ROUND(@ISRSubsidio,2) 
          END  
        END
      END  
    END ELSE  -- cuando no es fin de mes
    BEGIN
      IF  @NomTipo = 'H.ASIMILABLE'  
      BEGIN  
        EXEC spNominaISRSubsidioAlEmpleoProporcional	@DiasPeriodo,	@DiasPeriodoSubsidio, @DiasMes ,@ISRBase, @ISR	OUTPUT,	@ISRSubsidioAlEmpleoTabla	OUTPUT,	@ISRBruto	OUTPUT
        SELECT @ISR = ROUND(@ISRBruto,2) 
        SELECT @ISRCreditoAlSalarioTabla = 0    
      END ELSE       
      IF @PeriodoTipo = 'SEMANAL'  
      BEGIN  
         EXEC spNominaISRSubsidioAlEmpleoProporcional	@DiasPeriodo,	@DiasPeriodoSubsidio, @DiasMes ,@ISRBase, @ISR	OUTPUT,	@ISRSubsidioAlEmpleoTabla	OUTPUT,	@ISRBruto	OUTPUT
      END ELSE  
      BEGIN  
        SELECT @DiasTrabajadosSubsidioAcumulado = ISNULL(@DiasTrabajadosSubsidioAcumulado, 0)   
        SELECT @ISRBaseAcumulado = ISNULL(@ISRBaseAcumulado, 0)   
        EXEC spNominaISRSubsidioAlEmpleoProporcional	@DiasPeriodo,	@DiasPeriodoSubsidio, @DiasMes ,@ISRBase, @ISR	OUTPUT,	@ISRSubsidioAlEmpleoTabla	OUTPUT,	@ISRBruto	OUTPUT
      END  
    END
    IF @ISR < 0.0  
    BEGIN  
      IF @EsFinMes = 1  
      BEGIN     
        SELECT @NuevoImporteISR = 0  
        SELECT @NuevoImporteISR = @ISRAcumulado * -1  
        IF @NuevoImporteISR <> 0   
        BEGIN  
  		    IF @PeriodoTipo = 'SEMANAL'  
		      BEGIN  
            EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR', @Empresa, @Personal, @Importe = @NuevoImporteISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
            EXEC spNominaISRSubsidioAlEmpleoProporcional	@DiasMES,	@DiasTrabajadosSubsidioAcumulado, @DiasMes ,@ISRBaseMEs, @ISR	OUTPUT,	@ISRSubsidioAlEmpleoTabla	OUTPUT,	@ISRBruto	OUTPUT
		      END ELSE 
		      BEGIN
-- spNominaGenerar 100, 1724, '05/26/2008 00:00:00', '06/08/2008 00:00:00', 'Catorcenal', '05/20/2008 00:00:00'
-- select @ISR
            EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR', @Empresa, @Personal, @Importe = @NuevoImporteISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
            EXEC spNominaISRSubsidioAlEmpleoProporcional	@DiasMes,	@DiasTrabajadosSubsidioAcumulado, @DiasMes ,@ISRBaseMes, @ISR	OUTPUT,	@ISRSubsidioAlEmpleoTabla	OUTPUT,	@ISRBruto	OUTPUT
	        END  
  	    END  
    ---AJUSTE DE CREDITO AL SALARIO
    -- AJUSTE DE SubsidioAlEmpleo
	      SELECT @ISR = @ISR - @ISRSubsidioAlEmpleoAcumulado
	      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/SubsidioAlEmpleo', @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
      END ELSE  
      BEGIN  
	      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/SubsidioAlEmpleo', @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
      END  
    END ELSE  
    BEGIN 
      IF @EsFinMes=1  AND @NomTipo <> 'Prima Vacacional' and @EsISrReglamento <>1
      BEGIN  
        SELECT @NuevoImporteCAS=0  
        SELECT @NuevoImporteCAS = @ISRSubsidioAlEmpleoAcumulado * -1  
        IF @NuevoImporteCAS<>0   
        BEGIN  
          IF @PeriodoTipo = 'SEMANAL'  
          BEGIN  
             EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/SubsidioAlEmpleo', @Empresa, @Personal, @Importe = @NuevoImporteCAS, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento 
          END ELSE  
          IF (@NomTipo = 'AGUINALDO' AND @CfgISRReglamentoAguinaldo = 0 ) OR (@NomTipo <> 'AGUINALDO')
          BEGIN
	        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/SubsidioAlEmpleo', @Empresa, @Personal, @Importe = @NuevoImporteCAS, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento 
            EXEC spNominaISRSubsidioAlEmpleoProporcional	@DiasMes,	@DiasTrabajadosSubsidioAcumulado, @DiasMes ,@ISRBaseMes, @ISR	OUTPUT,	@ISRSubsidioAlEmpleoTabla	OUTPUT,	@ISRBruto	OUTPUT
          END  
        END

        IF @NuevoImporteCAS = 0  
        BEGIN  
          SELECT @NuevoImporteISR=0  
          SELECT @NuevoImporteISR = @ISRAcumulado   
          IF @NuevoImporteISR <> 0   
          BEGIN  
            SELECT @ISR = @ISR - @NuevoImporteISR  
            EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR', @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
          END ELSE 
            begin
            EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR', @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
            end
        END ELSE 
        BEGIN  
          EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR', @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
        END          
      END ELSE  
      BEGIN  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR', @Empresa, @Personal, @Importe = @ISR, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
      END  
    END  
    
    IF  @NomTipo NOT IN ('SDI','LIQUIDACION FONDO AHORRO')
    BEGIN 
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Bruto',               @Empresa, @Personal, @Importe = @ISRBruto  
	  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/SubsidioAlEmpleoTabla', @Empresa, @Personal, @Importe = @ISRSubsidioAlEmpleoTabla  
	 END
  END  
    
  IF @NomTipo = 'NORMAL'   
  BEGIN  
    SELECT @ISRAjuste = 0.0  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/AjusteAnual', @FechaAlta, @FechaA, NULL, @ISRAjusteAnual OUTPUT, NULL   
    IF @ISRAjusteAnual < 0.0 AND @ISR > 0.0   SELECT @ISRAjuste = dbo.fnMenor(ABS(@ISRAjusteAnual), @ISR)  
    IF @ISRAjusteAnual > 0.0  
    BEGIN  
      EXEC spPersonalPropValorMONEY @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, '$ Descuento quincenal por ISR Ajuste anual',   @ISRAjusteMax OUTPUT  
      SELECT @ISRAjuste = dbo.fnMenor(@ISRAjusteAnual, @ISRAjusteMax) * -1.0  
    END  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/AjusteAnual', @Empresa, @Personal, @Importe = @ISRAjuste  
    SELECT @CalcImporte =0-- -@ISRAjuste tenemos que adecuar esto porque lo ise para que en bayon jo salga el ajuste anual********************* abanos 
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Ajuste', @Empresa, @Personal, @Importe = @CalcImporte,@Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento, @Mov='CXP'  
  END  
   
  IF @NomTipo = 'LIQUIDACION'  
  BEGIN  
    IF @CfgISRLiquidacionSueldoMensual = 'SUELDO MENSUAL'  
      SELECT @ISRLiquidacionBase = @SueldoMensual  
    ELSE  
	      EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base', @PrimerDiaMesAnterior, @UltimoDiaMesAnterior, NULL, @ISRLiquidacionBase OUTPUT, NULL  

--spNominaGenerar 104, 1237, '04/14/2008 00:00:00', '04/27/2008 00:00:00', 'Catorcenal', '04/08/2008 00:00:00'
    EXEC spNominaISRSubsidioAlEmpleoProporcional	30.4,	30.4, 30.4 ,@ISRLiquidacionBase, @ISRLiquidacion OUTPUT,	NULL,	NULL  
    SELECT  @ISRLiquidacion= dbo.fnMayor(0,@ISRLiquidacion)
--spNominaGenerar 450, 1092, '03/31/2008 00:00:00', '04/13/2008 00:00:00', 'Catorcenal', '04/02/2008 00:00:00'

    SELECT @ISRLiquidacionFactor = @ISRLiquidacion / @ISRLiquidacionBase  
    EXEC spNominaTope @Indemnizacion, @IndemnizacionTope, @ISRLiquidacionExcento OUTPUT, @ISRLiquidacionGravable OUTPUT  
    SELECT @ISRLiquidacion = @ISRLiquidacionGravable * @ISRLiquidacionFactor  

-- select @ISRLiquidacionFactor,@ISRLiquidacion , @ISRLiquidacionBase,@ISRLiquidacionGravable
    IF @ISRLiquidacion<0  
      SELECT @ISRLiquidacion=0  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Liquidacion', @Empresa, @Personal, @Importe = @ISRLiquidacion, @Cuenta = @AcreedorISR, @Vencimiento = @ISRVencimiento  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Indemnizacion/Exento', @Empresa, @Personal, @Importe = @ISRLiquidacionExcento  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Indemnizacion/Gravable', @Empresa, @Personal, @Importe = @ISRLiquidacionGravable  
  END  
  -- select * from cfgnominaconcepto where claveinterna='ISR/Liquidacion'
  -- select * from nominaconcepto where nominaconcepto='204'
  IF @NomTipo IN ('NORMAL', 'AJUSTE', 'FINIQUITO', 'LIQUIDACION')  
  BEGIN  
  --- imss  
    IF @EsSocio = 0 
    BEGIN  
      EXEC spNominaIMSS @Empresa, @SucursalTrabajo, @Categoria, @Puesto, @Personal, @SDI, @DiasNaturales, @Incapacidades, @Faltas, @SMDF, 1,  
                        @IMSSObrero OUTPUT, @IMSSObreroCV OUTPUT,  
                        @IMSSPatron OUTPUT, @IMSSPatronMensual OUTPUT, @IMSSPatronCV OUTPUT, @IMSSPatronRetiro OUTPUT, @IMSSPatronInfonavit OUTPUT  
      SELECT @IMSSObreroSinCV = @IMSSObrero-@IMSSObreroCV  
      -- Recalcular SDI Bimestral  
      IF @EsBimestre = 1 AND @NomCalcSDI = 1  
      BEGIN  
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'IMSS/Base',      @PrimerDiaBimestre, @FechaA, NULL, @IMSSBaseAcumulado OUTPUT, NULL  
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Faltas',         @PrimerDiaBimestre, @FechaA, NULL, NULL, @FaltasAcumulado OUTPUT  
        EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Incapacidades',  @PrimerDiaBimestre, @FechaA, NULL, NULL, @IncapacidadesAcumulado OUTPUT  
         
        SELECT @IMSSBaseMes = @IMSSBaseAcumulado + @IMSSBase  
        SELECT @FactorIntegracion = NULL  
       
        IF @CfgFactorIntegracionAntiguedad = 'SIGUIENTE'  
          SELECT @FactorIntegracion = 1+((@DiasAguinaldoSiguiente+((@PrimaVacacionalPct/100.0)*@DiasVacacionesSiguiente))/@DiasAno)  
        ELSE  
        IF @CfgFactorIntegracionAntiguedad = 'ACTUAL'   
          SELECT @FactorIntegracion = 1+((@DiasAguinaldo+((@PrimaVacacionalPct/100.0)*@DiasVacaciones))/@DiasAno)  
        ELSE  
        IF @CfgFactorIntegracionAntiguedad = 'TABLA'  
          EXEC spTablaNum @CfgFactorIntegracionTabla, @Antiguedad, @FactorIntegracion OUTPUT  
              
        SELECT @DiasBimestre = DATEDIFF(day, @PrimerDiaBimestre, @FechaA) + 1  
        SELECT @DiasBimestreTrabajados = dbo.fnmenor(@DiasBimestre, @DiasBimestre - ISNULL(@FaltasAcumulado, 0.0) - ISNULL(@IncapacidadesAcumulado, 0.0) - @Faltas - @Incapacidades)  
        SELECT @SDINuevo = dbo.fnMayor(dbo.fnMenor(@SueldoDiario * @FactorIntegracion + (@IMSSBaseMes / @DiasBimestreTrabajados), 25*@SMDF),@SMDF*1.0452)  
      
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SDI', @Empresa, @Personal, @DiasBimestreTrabajados, @SDINuevo  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SDI/Factor', @Empresa, @Personal, @FactorIntegracion  
      END  
      IF @NomTipo <> 'H.ASIMILABLE'  
      BEGIN  
        IF ISNULL(@DiasTrabajados,0) <> 0  or @Mov='Presupuesto'  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/Obrero', @Empresa, @Personal, @DiasTrabajados, @IMSSObrero, @Vencimiento = @IMSSVencimiento, @Cuenta = @AcreedorIMSS  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/ObreroCV', @Empresa, @Personal, @Importe = @IMSSObreroCV, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimientoBimestre  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/ObreroSinCV', @Empresa, @Personal, @Importe = @IMSSObreroSinCV, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimiento  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/Patron', @Empresa, @Personal, @Importe = @IMSSPatron,   @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimiento  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'IMSS/PatronCV', @Empresa, @Personal, @Importe = @IMSSPatronCV, @Cuenta = @AcreedorIMSS, @Vencimiento = @IMSSVencimientoBimestre  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Retiro/Patron', @Empresa, @Personal, @Importe = @IMSSPatronRetiro,  @Cuenta = @AcreedorRetiro, @Vencimiento = @IMSSVencimientoBimestre  
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Infonavit/Patron', @Empresa, @Personal, @Importe = @IMSSPatronInfonavit, @Cuenta = @AcreedorInfonavit, @Vencimiento = @IMSSVencimientoBimestre  
      END  
    END  
   -- Infonavit Obrero  
    SELECT @MesI  = DATEPART(MONTH, @FechaD)  
    SELECT @YearI = DATEPART(YEAR, @FechaD)  
    EXEC  spDiasMes @MesI, @YearI,@DiasMesInfonavit output  
    SELECT @InfonavitObrero = NULL  
    SELECT @InfonavitDias = ISNULL(@DiasPeriodo,0)- isnull(@Incapacidades,0)- isnull(@Faltas,0)
    
    IF @NomTipo = 'Ajuste'
    BEGIN
      SELECT @PersonalPercepciones = ISNULL(SUM(d.Importe), 0.0)  
        FROM #Nomina d  
        JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'  
       WHERE d.Personal = @Personal  
      SELECT @InfonavitObrero = (@InfonavitSDI/100.0) * @PersonalPercepciones
-- spNominaGenerar 450, 1062, '03/31/2008 00:00:00', '04/13/2008 00:00:00', 'Catorcenal', '04/01/2008 00:00:00'

    END ELSE
    BEGIN 
    SELECT @DiasNaturalesInfonavit =  dbo.FnMenor(ABS(datediff (day, @FechaInicioDescuentoInfonavit,@FechaA))+1, @DiasNaturalesTrabajados)

    SELECT  @AcumuladoInfonavitObrero =NULL
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Infonavit/Obrero',  @PrimerDiaAnoAnterior, @Fechaa, NULL,  @AcumuladoInfonavitObrero OUTPUT, NULL
/*select @PrimerDiaAnoAnterior
select * from nominad where nominaconcepto='208' and personal ='0730'
select * from cfgnominaconcepto where claveinterna='Infonavit/Obrero'
select * from nominaconcepto where nominaconcepto='208'*/
    IF NULLIF(@AcumuladoInfonavitObrero,0) = NULL
      SELECT @DiasNaturalesInfonavit = datediff (day,  @FechaInicioDescuentoInfonavit,@FechaA)+1
    SELECT @AcumuladoInfonavitObrero = 0
--select isnull(@DiasNaturalesInfonavit,0)
--  spNominaGenerar 450, 1075, '03/31/2008 00:00:00', '04/13/2008 00:00:00', 'Catorcenal', '04/01/2008 00:00:00'
-- 

      IF NULLIF(@InfonavitSDI, 0.0) IS NOT NULL 
      BEGIN

        IF @PeriodoTipo = 'Catorcenal'
        BEGIN 
          EXEC spNominaBuscarDiasBimestre  @FechaA ,'Catorcenal', 4, @FechaD    ,  @FechaA    ,  @DiasBimestreInfonavit  output
          select @DiasBimestreInfonavit=70.0 -- ojo
          SELECT @UltimoDiaBimestreAnterior = DATEADD(day, -1, @PrimerDiaBimestre)
          SELECT @PrimerDiaBimestreAnterior = DATEADD(month, -2, @UltimoDiaBimestreAnterior)
          WHILE isnull(day(@PrimerDiaBimestreAnterior),1) <> 1
            SELECT @PrimerDiaBimestreAnterior =DATEADD(day,1,@PrimerDiaBimestreAnterior)
          EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'Infonavit/Obrero',  @PrimerDiaBimestreAnterior, @UltimoDiaBimestreAnterior, NULL,  @AcumuladoInfonavitObrero OUTPUT, NULL, 'NOMINA'
          SELECT @InfonavitObrero =  ((((@InfonavitSDI/100.0) * @SDI * @DiasBimestreInfonavit) - @AcumuladoInfonavitObrero) / @DiasBimestreInfonavit) * @DiasNaturalesInfonavit ---@DiasNaturalesTrabajados
        END ELSE
        BEGIN
--select isnull(@DiasNaturalesInfonavit,0)
          SELECT @InfonavitObrero = (@InfonavitSDI/100.0) * @SDI * @DiasNaturalesInfonavit -- @DiasNaturalesTrabajados 

        END
      END
      ELSE BEGIN	  
        IF @InfonavitDias > 0
        BEGIN
          IF @PeriodoTipo = 'Catorcenal'
          BEGIN
              EXEC spNominaBuscarDiasBimestre  @FechaA ,'Catorcenal', 4, @FechaD    ,  @FechaA    ,  @DiasBimestreInfonavit  output
              SELECT @DiasBimestreInfonavit = 70.0-- ojo
              SELECT @InfonavitObrero = ISNULL(@InfonavitObrero,0.0) + (((@InfonavitSMGDF*@SMDF)*2)/ISNULL(@DiasBimestreInfonavit, 1)) * @DiasNaturalesInfonavit
              
              -- IF @PERSONAL='171'
              -- SELECT @DIASNATURALESTRABAJADOS,ISNULL(@InfonavitObrero,0.0), @InfonavitSMGDF, @SMDF, ISNULL(@DiasBimestreInfonavit, 1) , @DiasNaturalesInfonavit
              -- spNominaGenerar 100, 1944, '05/26/2008 00:00:00', '06/08/2008 00:00:00', 'Catorcenal', '06/02/2008 00:00:00'
          END    
          ELSE  
          IF NULLIF(@InfonavitSMGDF, 0.0) IS NOT NULL 
	          SELECT @InfonavitObrero = ISNULL(@InfonavitObrero,0.0) + (((@InfonavitSMGDF*@SMDF)*2)/ISNULL(dbo.fnDiasBimestre(@FechaA),1)) * @DiasNaturalesInfonavit
-- select @InfonavitSMGDF
          SELECT @InfonavitObrero = ISNULL(@InfonavitObrero,0.0)
        END ELSE
          IF NULLIF(@InfonavitSMGDF, 0.0) IS NOT NULL 
            SELECT @InfonavitObrero = 0
      END
  
      IF NULLIF(@InfonavitImporte, 0.0) IS NOT NULL  
        SELECT @InfonavitObrero = ISNULL(@InfonavitObrero,0) + @InfonavitImporte  
  
      IF @PeriodoTipo = 'QUINCENAL'  
        SELECT @SeguroRiesgoInfonavit = ISNULL(@SeguroRiesgoInfonavit,0)/4  
      ELSE IF @PeriodoTipo = 'MENSUAL'   
        SELECT @SeguroRiesgoInfonavit = ISNULL(@SeguroRiesgoInfonavit,0)/2  
      ELSE IF @PeriodoTipo = 'SEMANAL'  
        SELECT @SeguroRiesgoInfonavit = ISNULL(@SeguroRiesgoInfonavit,0)/16  
      ELSE IF @PeriodoTipo = 'Catorcenal'  
		--select @DiasNaturalesInfonavit =56
        SELECT @SeguroRiesgoInfonavit = (ISNULL(@SeguroRiesgoInfonavit,0)/ @DiasBimestreInfonavit) *  @DiasNaturalesInfonavit --@DiasNaturalesTrabajados

      IF ISNULL(@InfonavitObrero,0) <> 0   
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SeguroRiesgoInfonavit', @Empresa, @Personal, @Importe = @SeguroRiesgoInfonavit  
    END 
-- select @InfonavitObrero  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Infonavit/Obrero', @Empresa, @Personal, @Importe = @InfonavitObrero  
    
--    select  @DiasNaturalesInfonavit,@InfonavitObrero  
  -- Provisiones      
    IF @NomTipo IN ('NORMAL', 'AJUSTE')  
    BEGIN  
      SELECT @CalcImporte = @PrimaVacacional/@DiasAno*@DiasNaturales  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Vacaciones', @Empresa, @Personal, @Importe = @CalcImporte,@cantidad=@diasvacaciones  
      SELECT @CalcImporte = (@DiasAguinaldo*@SueldoDiario/@DiasAno)*@DiasNaturales  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Aguinaldo', @Empresa, @Personal, @Importe = @CalcImporte  
      IF (@SMZ*@SMZPrimaAntiguedad) < @SueldoDiario  
        SELECT @CalcImporte = (@DiasPrimaAntiguedad*@SMZ*@SMZPrimaAntiguedad*@Antiguedad)/@DiasAno*@DiasNaturales  
      ELSE  
        SELECT @CalcImporte =(@DiasPrimaAntiguedad*@SueldoDiario*@Antiguedad)/@DiasAno*@DiasNaturales  
      EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Provision/Antiguedad', @Empresa, @Personal, @Importe = @CalcImporte  
    END  
  END  

  IF @NomTipo = 'AJUSTE ANUAL'  
  BEGIN  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/Base', @PrimerDiaAnoAnterior, @UltimoDiaAnoAnterior, NULL, @ISRBaseAcumulado OUTPUT, NULL  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR', @PrimerDiaAnoAnterior, @UltimoDiaAnoAnterior, NULL, @ISRAcumulado OUTPUT, NULL  
    --EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/CreditoAlSalario', @PrimerDiaAnoAnterior, @UltimoDiaAnoAnterior, NULL, @ISRCreditoAlSalarioAcumulado OUTPUT, NULL  
    EXEC spNominaClaveInternaAcumuladoFechas @Empresa, @Personal, 'ISR/SubsidoAlEmpleo', @PrimerDiaAnoAnterior, @UltimoDiaAnoAnterior, NULL, @ISRSubsidioAlEmpleoAcumulado OUTPUT, NULL  
    EXEC spNominaISRAnual @ISRBaseAcumulado, @ISRSubsidioPct, @ISRAnual OUTPUT  
    -- SELECT @ISRAjusteAnual = @ISRAnual - @ISRAcumulado + @ISRCreditoAlSalarioAcumulado  
    SELECT @ISRAjusteAnual = @ISRAnual - @ISRAcumulado + @ISRSubsidioAlEmpleoAcumulado  
    IF @ISRAjusteAnual < 0.0  
    BEGIN  
      --SELECT @ISRAjusteAnual = @ISRAjusteAnual + @ISRCreditoAlSalarioAcumulado  
      SELECT @ISRAjusteAnual = @ISRAjusteAnual + @ISRSubsidioAlEmpleoAcumulado  
      IF @ISRAjusteAnual > 0.0 SELECT @ISRAjusteAnual = 0.0  
    END  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/BaseAcumAnual',   @Empresa, @Personal, @Importe = @ISRBaseAcumulado  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/AcumAnual',   @Empresa, @Personal, @Importe = @ISRAcumulado  
    --EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/CreditoAlSalarioAcumAnual',@Empresa, @Personal, @Importe = @ISRCreditoAlSalarioAcumulado  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/SubsidioAlEmpleoAcumAnual',@Empresa, @Personal, @Importe = @ISRSubsidioAlEmpleoAcumulado  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/Anual',           @Empresa, @Personal, @Importe = @ISRAnual  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ISR/AjusteAnual',   @Empresa, @Personal, @Importe = @ISRAjusteAnual  
  END	ELSE  
    SELECT @PercepcionBruta = 0.0  
  SELECT @PercepcionBruta = @PercepcionBruta + ISNULL(SUM(d.Importe), 0.0)  
    FROM #Nomina d  
    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'  
   WHERE d.Personal = @Personal  
  IF ISNULL(@PensionASueldoBruto,0)<>0 OR ISNULL(@PensionASueldoNeto,0) <> 0 OR
     ISNULL(@PensionASueldoBruto2,0)<>0 OR ISNULL(@PensionASueldoNeto2,0) <> 0 OR
     ISNULL(@PensionASueldoBruto3,0)<>0 OR ISNULL(@PensionASueldoNeto3,0) <> 0
  BEGIN 
    SELECT @CalcImporte = (@PensionASueldoBruto/100.0) * @PercepcionBruta  
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor  
 	  IF @Nomtipo in('PRESTAMO FONDO AHORR')--, 'LIQUIDACION FONDO AHORRO')
      SELECT @CalcImporte = (@PensionASueldoNeto/100.0)*(@PercepcionBruta)---ISNULL(@ISR, 0.0)  - ISNULL(@FondoAhorro,0)- isnull (@FondoAhorroPrestamoAcumulado,0))   
--    lo cambie      SELECT @CalcImporte = (@PensionASueldoNeto/100.0)*(@PercepcionBruta-ISNULL(@ISR, 0.0)  )       
  	ELSE
 	    IF @Nomtipo in('LIQUIDACION FONDO AHORRO')--, 'LIQUIDACION FONDO AHORRO')
        SELECT @CalcImporte = (@PensionASueldoNeto/100.0)*(@PercepcionBruta-ISNULL(@ISR, 0.0)  - ISNULL(@FondoAhorro,0)- isnull (@FondoAhorroPrestamoAcumulado,0))    
--      lo cambie      SELECT @CalcImporte = (@PensionASueldoNeto/100.0)*(@PercepcionBruta-ISNULL(@ISR, 0.0)  )   
      ELSE BEGIN
/*      AQUI ESTA LO QUE LE MODIFIQUE ANGEL BC*/
	      SELECT @ValesDespensaImportePension = (@PensionASueldoNeto/100.0)*(case when @nomtipo in('Normal')then @ValesDespensaImporte else 0 end )
        EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ValesDespensaPension', @Empresa, @Personal, @Importe = @ValesDespensaImportePension
        EXEC spNominaClaveInternaEstaNomina @Personal, 'DESCAUSENTISMOFONDOAHORRO',             NULL,  @DESCAUSENTISMOFONDOAHORRO OUTPUT  
        EXEC spNominaClaveInternaEstaNomina @Personal, 'DESCAUSENTIMOAYUDAFAMILIAR',            NULL,  @DESCAUSENTIMOAYUDAFAMILIAR OUTPUT  
        EXEC spNominaClaveInternaEstaNomina @Personal, 'DESCAUSENTHORASFONDOAH',                NULL,  @DESCAUSENTHORASFONDOAH OUTPUT  
        EXEC spNominaClaveInternaEstaNomina @Personal, 'DESCAUSENTHORASAYUDAFAMIL',             NULL,  @DESCAUSENTHORASAYUDAFAMIL OUTPUT
        SELECT @CalcImporte = (@PensionASueldoNeto/100.0)* (ISNULL(@PercepcionBruta ,0.0)
                         - ISNULL(@ISR, 0.0)  
                         - ISNULL(@FondoAhorro,0)
                         - ISNULL(@FondoAhorroPrestamoAcumulado,0)
                         - ISNULL(@DESCAUSENTISMOFONDOAHORRO,0) 
                         - ISNULL(@DESCAUSENTIMOAYUDAFAMILIAR,0) 
                         - ISNULL(@DESCAUSENTHORASFONDOAH,0) 
                         - ISNULL(@DESCAUSENTHORASAYUDAFAMIL,0) 
                         - ISNULL(@Faltasimporte,0) )   
       
        IF @NomTipo IN ('NORMAL')
        BEGIN  
          SELECT @Calc = (@PensionASueldoNeto/100.0) * (@ValesDespensaImporte) * -1
          EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'ValesDespensa', @Empresa, @Personal, @Importe = @Calc    
        END
      END
    IF 'ESTADISTICA' <> (SELECT Movimiento 
                           FROM NominaConcepto, CfgNominaConcepto 
                          WHERE NominaConcepto.NominaConcepto  = cfgNominaConcepto.NominaConcepto   
                            AND Cfgnominaconcepto.Claveinterna = 'IMSS/Obrero' 
                       )
    SELECT @CalcImporte =  @CalcImporte  - ISNULL(@IMSSObrero, 0.0)
	  SELECT @CalcImporte =  dbo.fnMayor(0,@CalcImporte) 
  	EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor  
  	SELECT @CalcImporte = (@PensionASueldoBruto2/100.0)*@PercepcionBruta  
	  SELECT @CalcImporte =  dbo.fnMayor(0,@CalcImporte) 
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor2  
    SELECT @CalcImporte = (@PensionASueldoNeto2/100.0)*(@PercepcionBruta-ISNULL(@IMSSObrero, 0.0)- ISNULL(@FondoAhorro,0))  
    IF 'ESTADISTICA' <> (SELECT Movimiento 
                           FROM NominaConcepto, CfgNominaConcepto 
                          WHERE NominaConcepto.NominaConcepto  = cfgNominaConcepto.NominaConcepto   
                            AND Cfgnominaconcepto.Claveinterna = 'IMSS/Obrero' 
                        )
      SELECT @CalcImporte =  @CalcImporte  - ISNULL(@IMSSObrero, 0.0)

    SELECT @CalcImporte =  dbo.fnMayor(0,@CalcImporte) 
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor2  
    SELECT @CalcImporte = (@PensionASueldoBruto3/100.0)*@PercepcionBruta  

    SELECT @CalcImporte =  dbo.fnMayor(0,@CalcImporte) 
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoBruto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor3  
    SELECT @CalcImporte = (@PensionASueldoNeto3/100.0)*(@PercepcionBruta-ISNULL(@ISR, 0.0)- ISNULL(@FondoAhorro,0)) 

    IF 'ESTADISTICA' <> (SELECT Movimiento 
                           FROM NominaConcepto, CfgNominaConcepto 
                          WHERE NominaConcepto.NominaConcepto  = cfgNominaConcepto.NominaConcepto   
                            AND Cfgnominaconcepto.Claveinterna = 'IMSS/Obrero' 
                        )
      SELECT @CalcImporte =  dbo.fnmayor(0,@CalcImporte  - ISNULL(@IMSSObrero, 0.0))
    SELECT @CalcImporte =  dbo.fnMayor(0,@CalcImporte) 
    EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'PensionA/SueldoNeto', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor3  
  END  


---se borran todos los conceptos que no aplican para este MOV
    DELETE #Nomina    
      FROM #Nomina n    
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto    
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)    
       AND n.Personal = @Personal   and exists(select * from MovEspecificoNomina where MovEspecificoNomina.nominaconcepto= n.NominaConcepto)

  SELECT @PersonalPercepciones = 0.0, @PersonalDeducciones = 0.0  

  SELECT @PersonalPercepciones = ISNULL(SUM(d.Importe), 0.0)  
    FROM #Nomina d  
    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'  
   WHERE d.Personal = @Personal  

 	SELECT @PersonalDeducciones = ISNULL(SUM(d.Importe), 0.0)  
    FROM #Nomina d  
    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Deduccion'  
   WHERE d.Personal = @Personal  

  
  SELECT @PersonalNeto = @PersonalPercepciones - @PersonalDeducciones  

  IF  @NomCxc IN ('PARCIALES', 'COMPLETAS') 
 AND (@NomTipo NOT IN ('AJUSTE', 'AJUSTE ANUAL') OR  @PersonalEstatus = 'Baja') 
 AND @Ok IS NULL
  BEGIN  
    SELECT @ConSueldoMinimo = 1  
    IF @NomTipo IN ('FINIQUITO', 'LIQUIDACION') AND @FiniquitoNetoEnCeros = 0 SELECT @ConSueldoMinimo = 0  
    IF @PersonalNeto > @SueldoMinimo OR @ConSueldoMinimo = 0  
      EXEC spNominaCxc @NomCxc, @NomTipo, @Empresa, @Sucursal, @ID, @Personal, @Cliente, @FechaD, @FechaA, @Moneda, @TipoCambio, @ConSueldoMinimo, @SueldoMinimo, @PersonalNeto OUTPUT, @Ok OUTPUT, @OkRef OUTPUT  
  END  

  DELETE #Nomina    
      FROM #Nomina n    
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto    
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)    
       AND n.Personal = @Personal   and exists(select * from MovEspecificoNomina where MovEspecificoNomina.nominaconcepto= n.NominaConcepto)

  SELECT @PersonalPercepciones = 0.0, @PersonalDeducciones = 0.0  

  SELECT @PersonalPercepciones = ISNULL(SUM(d.Importe), 0.0)  
    FROM #Nomina d  
    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Percepcion'  
   WHERE d.Personal = @Personal  

 	SELECT @PersonalDeducciones = ISNULL(SUM(d.Importe), 0.0)  
    FROM #Nomina d  
    JOIN NominaConcepto nc ON nc.NominaConcepto = d.NominaConcepto AND nc.Movimiento = 'Deduccion'  
   WHERE d.Personal = @Personal  
  SELECT @PersonalNeto = @PersonalPercepciones - @PersonalDeducciones  
--spNominaGenerar 100, 15094, '01/16/2008 00:00:00', '01/31/2008 00:00:00', 'Quincenal', '01/25/2008 00:00:00'
  SELECT @PersonalDeducciones = @PersonalPercepciones - @PersonalNeto  
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Percepciones', @Empresa, @Personal, @Importe = @PersonalPercepciones  
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Deducciones', @Empresa, @Personal, @Importe = @PersonalDeducciones  
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'Personal/Neto', @Empresa, @Personal, @Importe = @PersonalNeto, @Beneficiario = @BeneficiarioSueldoNeto  
---se borran todos los conceptos que no aplican para este MOV

  EXEC spNominaClaveInternaEstaNomina @Personal, 'SEGURODEAUTO',                NULL,  @SeguroAuto OUTPUT  
  EXEC spNominaClaveInternaEstaNomina @Personal, 'SEGURODEGASTOSMEDICOSMAYORES', NULL, @SeguroMedico OUTPUT  
  EXEC spNominaClaveInternaEstaNomina @Personal, 'PensionA/SueldoNeto', NULL, @PensionSueldoNeto OUTPUT  
  SELECT @CalcImporte = @PensionSueldoNeto + @SeguroAuto + @SeguroMedico
  EXEC spNominaAgregarClaveInterna @Ok OUTPUT, @OkRef OUTPUT, 'SumaSegurosyPensionesalim', @Empresa, @Personal, @Importe = @CalcImporte, @Cuenta = @PensionAAcreedor  
      

    DELETE #Nomina    
      FROM #Nomina n    
      JOIN NominaConcepto nc ON nc.NominaConcepto = n.NominaConcepto    
     WHERE nc.NominaConcepto NOT IN(SELECT MovEspecificoNomina.NominaConcepto FROM MovEspecificoNomina WHERE MovEspecificoNomina.MovEspecificoNomina = @Mov)    
       AND n.Personal = @Personal   and exists(select * from MovEspecificoNomina where MovEspecificoNomina.nominaconcepto= n.NominaConcepto)
--- select pase 
  IF @Ok IS NOT NULL AND @OkRef IS NULL SELECT @OkRef = @Personal  
--select 'pasefin spnominacalc'
  RETURN  
END
GO
