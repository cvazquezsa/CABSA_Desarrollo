IF EXISTS (SELECT name FROM sysobjects  WHERE name = 'spRegistroOk' and type = 'P') DROP PROCEDURE spRegistroOk
GO
CREATE PROCEDURE spRegistroOk
                                   @Cual            varchar(20),
                                   @Registro        varchar(20)
WITH ENCRYPTION
AS BEGIN
  SELECT "Ok" = CONVERT(bit, 1)
  RETURN
END
GO
