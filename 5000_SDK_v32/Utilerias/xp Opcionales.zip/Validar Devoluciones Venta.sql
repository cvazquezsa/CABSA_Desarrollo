/**************** spReferenciaEnMovMovID ****************/
if exists (select * from sysobjects where id = object_id('dbo.spReferenciaEnMovMovID') and type = 'P') drop procedure dbo.spReferenciaEnMovMovID
GO             
CREATE PROCEDURE spReferenciaEnMovMovID
		  	@Referencia 	varchar(50),
		  	@Mov 		varchar(20)	OUTPUT,
			@MovID  	varchar(20)	OUTPUT
WITH ENCRYPTION
AS BEGIN
  DECLARE
    @Ultp	int,
    @p		int
  SELECT @Mov = NULL, @MovID = NULL, @Ultp = 0
  SELECT @Referencia = NULLIF(RTRIM(@Referencia), '')
  
  SELECT @p = CHARINDEX(' ', @Referencia)
  WHILE @p > 0
  BEGIN
    SELECT @Ultp = @p
    SELECT @p = CHARINDEX(' ', @Referencia, @p+1)
  END
  SELECT @Mov = RTRIM(SUBSTRING(@Referencia, 1, @Ultp-1)), @MovID = RTRIM(SUBSTRING(@Referencia, @Ultp+1, LEN(@Referencia)))
  RETURN
END
GO


/**************** xpInvVerificar ****************/
if exists (select * from sysobjects where id = object_id('dbo.xpInvVerificar') and sysstat & 0xf = 4) drop procedure dbo.xpInvVerificar
GO             
CREATE PROCEDURE xpInvVerificar
    		   @ID                		int,
		   @Accion			char(20),
		   @Base			char(20),
    		   @Empresa	      		char(5),
		   @Usuario			char(10),
    		   @Modulo	      		char(5),
    		   @Mov	  	      		char(20),
    		   @MovID             		varchar(20),
    		   @MovTipo     		char(20),
    		   @MovMoneda	      		char(10),
    		   @MovTipoCambio	 	float,
     	    	   @Estatus	 	      	char(15),
     	    	   @EstatusNuevo	      	char(15),
		   @FechaEmision		datetime,

		   @Ok				int		OUTPUT,
		   @OkRef			varchar(255)	OUTPUT
AS BEGIN
  DECLARE 
    @Contacto		char(10),
    @Referencia		varchar(50),
    @RefMov 		varchar(20), 
    @RefMovID 		varchar(20)

  IF @Accion IN ('AFECTAR', 'VERIFICAR') 
  BEGIN
    IF @MovTipo = 'VTAS.D'
    BEGIN
      SELECT @Contacto = Cliente, @Referencia = NULLIF(RTRIM(Referencia), '') FROM Venta WHERE ID = @ID
      IF @Referencia IS NULL 
        SELECT @Ok = 20915 
      ELSE BEGIN
        EXEC spReferenciaEnMovMovID @Referencia, @RefMov OUTPUT, @RefMovID OUTPUT  
        IF NOT EXISTS(SELECT * FROM Venta e, MovTipo mt WHERE e.Empresa = @Empresa AND e.Cliente = @Contacto AND e.Mov = @RefMov AND e.MovID = @RefMovID AND e.Estatus = 'CONCLUIDO' AND mt.Modulo = @Modulo AND mt.Mov = e.Mov AND mt.Clave IN ('VTAS.F', 'VTAS.N'))
          SELECT @Ok = 20915 
      END
    END 
  END
  RETURN
END
GO


/**************** xpInvVerificarDetalle ****************/
if exists (select * from sysobjects where id = object_id('dbo.xpInvVerificarDetalle') and sysstat & 0xf = 4) drop procedure dbo.xpInvVerificarDetalle
GO             
CREATE PROCEDURE xpInvVerificarDetalle
    		   @ID                		int,
		   @Accion			char(20),
		   @Base			char(20),
    		   @Empresa	      		char(5),
		   @Usuario			char(10),
    		   @Modulo	      		char(5),
    		   @Mov	  	      		char(20),
    		   @MovID             		varchar(20),
    		   @MovTipo     		char(20),
    		   @MovMoneda	      		char(10),
    		   @MovTipoCambio	 	float,
     	    	   @Estatus	 	      	char(15),
     	    	   @EstatusNuevo	      	char(15),
		   @FechaEmision		datetime,

		   @Renglon			float,
		   @RenglonSub			int,
		   @Articulo			char(20),
                   @Cantidad		        float,
		   @Importe			money,
                   @ImporteNeto			money,
		   @Impuestos			money,
		   @ImpuestosNetos		money,

		   @Ok				int		OUTPUT,
		   @OkRef			varchar(255)	OUTPUT
AS BEGIN
  DECLARE 
    @Referencia		varchar(50),
    @SubCuenta		varchar(50),
    @CantidadDev	float,
    @CantidadFacturada	float,
    @RefMov 		varchar(20), 
    @RefMovID 		varchar(20)

  IF @Accion IN ('AFECTAR', 'VERIFICAR') 
  BEGIN
    IF @MovTipo = 'VTAS.D'
    BEGIN
      SELECT @Referencia = Referencia FROM Venta  WHERE ID = @ID
      SELECT @SubCuenta  = SubCuenta  FROM VentaD WHERE ID = @ID AND Renglon = @Renglon AND RenglonSub = @RenglonSub

      EXEC spReferenciaEnMovMovID @Referencia, @RefMov OUTPUT, @RefMovID OUTPUT  

      SELECT @CantidadFacturada = SUM(Cantidad) 
        FROM VentaD d, Venta e, MovTipo mt
       WHERE mt.Modulo = @Modulo AND mt.Mov = e.Mov AND e.ID = d.ID AND e.Empresa = @Empresa AND mt.Clave IN ('VTAS.F', 'VTAS.N') AND ISNULL(e.OrigenTipo, '') <> 'VMOS' AND e.Mov = @RefMov AND e.MovID = @RefMovID AND e.Estatus = 'CONCLUIDO' AND d.Articulo = @Articulo AND ISNULL(d.SubCuenta, '') = ISNULL(@SubCuenta, '')

      SELECT @CantidadDev = SUM(Cantidad) 
        FROM VentaD d, Venta e 
       WHERE e.ID = d.ID AND e.Empresa = @Empresa AND e.Mov = @Mov AND e.Referencia = @Referencia AND (e.Estatus = 'CONCLUIDO' OR e.ID = @ID) AND d.Articulo = @Articulo AND ISNULL(d.SubCuenta, '') = ISNULL(@SubCuenta, '')

     IF ISNULL(@CantidadDev, 0) > ISNULL(@CantidadFacturada, 0)
        SELECT @Ok = 20010, @OkRef = 'Excede a lo Facturado ('+RTRIM(@Articulo)+' '+ISNULL(RTRIM(@SubCuenta), '')+')'
    END
  END
  RETURN
END
GO
