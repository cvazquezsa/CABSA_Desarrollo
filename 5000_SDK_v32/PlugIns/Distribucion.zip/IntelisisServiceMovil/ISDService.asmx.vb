﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient

Imports Microsoft.VisualBasic
Imports System.Security
Imports System.Security.Cryptography


' Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la siguiente línea.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://intelisis.com/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class ISDService
  Inherits System.Web.Services.WebService

  Dim ConexionABaseGeneral As String = "Persist Security Info=True;User ID=" & ConfigurationSettings.AppSettings("Usuario") & ";Initial Catalog=" & ConfigurationSettings.AppSettings("BD") & ";Data Source=" & ConfigurationSettings.AppSettings("Servidor") & ";Password=" & ConfigurationSettings.AppSettings("Password") & ";"

  <WebMethod()> _
  Public Function Servicio(ByVal XML As String, ByVal user As String, ByVal passw As String) As String
    If XML.ToString.Contains("Delete") Then
      Servicio = "No se permiten Delete.."
      Exit Function
    End If
    If XML.ToString.Contains("Select") Then
      Servicio = "No se permiten Select.."
      Exit Function
    End If
    If XML.ToString.Contains("Create") Then
      Servicio = "No se permiten Create.."
      Exit Function
    End If
    If XML.ToString.Contains("Drop") Then
      Servicio = "No se permiten Drop.."
      Exit Function
    End If

    If XML.ToString.Contains("Truncate") Then
      Servicio = "No se permiten Truncate.."
      Exit Function
    End If

    Dim sSql As String = ""
    Dim Resultado As String = ""
    Dim Temp As String = ""
    Dim oConn As New SqlClient.SqlConnection
    Dim oCommand As New SqlClient.SqlCommand
    Dim vobj As New Security()

    Try
      'sSql = "Set nocount on Declare @Resultado Varchar(max)," _
      '       & "@Ok int," _
      '       & "@OkRef varchar(255)," _
      '       & "@Id int " _
      '       & "Exec SpIntelisisService '" + user + "','" + passw + "','" + XML + "',@Resultado output,@Ok Output,@OkRef Output,1,0,@Id Output,1 Select @Resultado as 'Resultado'"

      'sSql = "Set nocount on Declare @Resultado Varchar(max)," _
      '        & "@Ok int," _
      '        & "@OkRef varchar(255)," _
      '        & "@Id int " _
      '        & "Exec SpIntelisisService '" + user + "','" + passw + "','" + XML + "',@Resultado output,@Ok Output,@OkRef Output,1,0,@Id Output Select @Resultado as 'Resultado'"

      sSql = "Set nocount on Declare @Resultado Varchar(max)," _
             & "@Ok int," _
             & "@OkRef varchar(255)," _
             & "@Id int " _
             & "Exec SpIntelisisService '" + user + "','" + passw + "','" + XML + "',@Resultado output,@Ok Output,@OkRef Output,1,0,@Id Output,0 Select @Resultado as 'Resultado'"



      oConn.ConnectionString = ConexionABaseGeneral
      oConn.Open()
      oCommand.CommandTimeout = 100000
      If oConn.State = ConnectionState.Open Then
        oCommand.Connection = oConn
        oCommand.CommandText = sSql
      End If
      Dim rsDatos As SqlClient.SqlDataReader = oCommand.ExecuteReader()
      'Resultado = "voy a entrar"
      'Resultado = Resultado + rsDatos.GetValue(0)
      Do While rsDatos.Read()
        Temp = Replace(rsDatos.Item(0).ToString(), "/>", "/>" + Chr(13))
        Resultado = Resultado + Temp '+ ";"
        'Resultado = rsDatos.Item(0).ToString().Replace("<?xml version=""1.0"" encoding=""windows-1252""?>", "")
        'Resultado = Resultado + rsDatos.Item(0).ToString()
      Loop
      'Loop While rsDatos.NextResult()
      'Resultado = Resultado + " sali"
      rsDatos.Close()
      oConn.Close()
      'Catch ex As Exception
      '   Resultado = ex.Message.ToString

    Catch SqlEx As SqlException
      Dim myError As SqlError
      'Debug.WriteLine("Errors Count:" & SqlEx.Errors.Count)
      For Each myError In SqlEx.Errors
        Beep()
        Dim msg As String = String.Format("Inicio de Sesión: {0} - {1}", myError.Number, myError.Message)

        Resultado = msg

        'MsgBox(msg, MsgBoxStyle.Critical)

        'MsgBox("Inicio de Sesión:" & myError.Number.ToString & " - " & myError.Message, , "Excepcion")
      Next
      ' MsgBox("Se ha perdido la conexion con el servidor, por favor vuelva a intentarlo", , "Error")
    End Try

    Servicio = Resultado

  End Function

  <WebMethod()> _
 Public Function IsConnect() As Boolean
    Try
      Return True
    Catch ex As Exception
      Return False
    End Try
  End Function
End Class


Public Class Security
  Public Function ObtenerMd5(ByVal pass As String) As String
    pass = UCase(pass)
    Dim md5 As MD5 = MD5CryptoServiceProvider.Create()
    Dim dataMd5() As Byte = md5.ComputeHash(Encoding.Default.GetBytes(pass))
    Dim sb As StringBuilder = New StringBuilder()
    Dim i As Integer
    For i = 0 To dataMd5.Length - 1 Step i + 1
      sb.AppendFormat("{0:x2}", dataMd5(i))
    Next
    Return sb.ToString()
  End Function
End Class
