/****** AgendaEstacion ******/
if exists (select * from sysobjects where id = object_id('dbo.AgendaEstacion') and type = 'U')
  drop table AgendaEstacion
GO
CREATE TABLE dbo.AgendaEstacion (
	EstacionTrabajo	int		NOT NULL,
	ID		int		NOT NULL 	IDENTITY (1,1),
	Tipo		varchar(20)	NULL,
	Asunto		varchar(255)	NULL,
	Ubicacion	varchar(255)	NULL,
	ColorEtiqueta	int		NULL,
	FechaD		datetime	NULL,
	FechaA		datetime	NULL,
	DiaCompleto	bit 		NULL	DEFAULT (0),
	Recordar	bit		NULL,
	RecordarMinutos	int		NULL,
	RecordarFecha	datetime	NULL,
	Estado		varchar(100)	NULL,
	Mensaje		text		NULL,

  CONSTRAINT priAgendaEstacion PRIMARY KEY CLUSTERED (EstacionTrabajo, ID)
)
GO
