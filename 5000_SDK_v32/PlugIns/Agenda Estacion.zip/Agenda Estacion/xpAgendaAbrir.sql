/**************** xpAgendaAbrir ****************/
if exists (select * from sysobjects where id = object_id('dbo.xpAgendaAbrir') and type = 'P') 
  drop procedure dbo.xpAgendaAbrir
GO
CREATE PROCEDURE xpAgendaAbrir
                  @EstacionTrabajo	int
WITH ENCRYPTION
AS BEGIN
  DECLARE
    @Ok 	int,
    @OkRef	varchar(255),
    @OkDesc	varchar(255),
    @OkTipo	varchar(50)		-- INFORMACION, ERROR, ADVERTENCIA,

  SELECT @Ok = NULL, @OkRef = NULL, @OkDesc = NULL, @OkTipo = NULL
  SELECT "Ok" = @Ok, "OkRef" = @OkRef, "OkDesc" = @OkDesc, "OkTipo" = @OkTipo
  RETURN
END
GO

-- EXEC xpAgendaAbrir @EstacionTrabajo = 59



/**************** xpAgendaAceptar ****************/
if exists (select * from sysobjects where id = object_id('dbo.xpAgendaAceptar') and type = 'P') 
  drop procedure dbo.xpAgendaAceptar
GO
CREATE PROCEDURE xpAgendaAceptar
                  @EstacionTrabajo	int
WITH ENCRYPTION
AS BEGIN
  DECLARE
    @Ok 	int,
    @OkRef	varchar(255),
    @OkDesc	varchar(255),
    @OkTipo	varchar(50)		-- INFORMACION, ERROR, ADVERTENCIA,

  SELECT @Ok = NULL, @OkRef = NULL, @OkDesc = NULL, @OkTipo = NULL
  SELECT "Ok" = @Ok, "OkRef" = @OkRef, "OkDesc" = @OkDesc, "OkTipo" = @OkTipo
  RETURN
END
GO

-- EXEC xpAgendaAceptar @EstacionTrabajo = 59



/**************** xpAgendaCancelar ****************/
if exists (select * from sysobjects where id = object_id('dbo.xpAgendaCancelar') and type = 'P') 
  drop procedure dbo.xpAgendaCancelar
GO
CREATE PROCEDURE xpAgendaCancelar
                  @EstacionTrabajo	int
WITH ENCRYPTION
AS BEGIN
  DECLARE
    @Ok 	int,
    @OkRef	varchar(255),
    @OkDesc	varchar(255),
    @OkTipo	varchar(50)		-- INFORMACION, ERROR, ADVERTENCIA,

  SELECT @Ok = NULL, @OkRef = NULL, @OkDesc = NULL, @OkTipo = NULL
  SELECT "Ok" = @Ok, "OkRef" = @OkRef, "OkDesc" = @OkDesc, "OkTipo" = @OkTipo
  RETURN
END
GO

-- EXEC xpAgendaCancelar @EstacionTrabajo = 59

/**************** xpAgendaCerrar ****************/
if exists (select * from sysobjects where id = object_id('dbo.xpAgendaCerrar') and type = 'P') 
  drop procedure dbo.xpAgendaCerrar
GO
CREATE PROCEDURE xpAgendaCerrar
                  @EstacionTrabajo	int
WITH ENCRYPTION
AS BEGIN
  DECLARE
    @Ok 	int,
    @OkRef	varchar(255),
    @OkDesc	varchar(255),
    @OkTipo	varchar(50)		-- INFORMACION, ERROR, ADVERTENCIA,

  SELECT @Ok = NULL, @OkRef = NULL, @OkDesc = NULL, @OkTipo = NULL
  SELECT "Ok" = @Ok, "OkRef" = @OkRef, "OkDesc" = @OkDesc, "OkTipo" = @OkTipo
  RETURN
END
GO

-- EXEC xpAgendaCerrar @EstacionTrabajo = 59
